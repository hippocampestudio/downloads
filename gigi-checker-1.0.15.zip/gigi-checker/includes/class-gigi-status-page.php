<?php
/**
 * Gigi_Status_Page — page d'état dans l'admin WP (Outils → Gigi Checker).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	public static function register(): void {
		add_management_page(
			'Gigi Checker — État',
			'Gigi Checker',
			'update_plugins',
			'gigi-checker-status',
			[ self::class, 'render' ]
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		// ---- Sauvegarde de l'URL personnalisée -------------------------
		if (
			isset( $_POST['gigi_versions_url'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_url' )
		) {
			$new_url = sanitize_url( trim( wp_unslash( $_POST['gigi_versions_url'] ) ) );
			Gigi_Versions::save_url( $new_url );
			Gigi_Versions::flush_cache();
			echo '<div class="notice notice-success is-dismissible"><p>URL mise à jour. Le cache a été vidé.</p></div>';
		}

		// ---- Sauvegarde du secret de sync à distance -------------------
		if (
			isset( $_POST['gigi_sync_secret'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_sync_secret' )
		) {
			$secret = sanitize_text_field( wp_unslash( $_POST['gigi_sync_secret'] ) );
			update_option( Gigi_Remote_Sync::get_secret_option_name(), $secret );
			echo '<div class="notice notice-success is-dismissible"><p>Secret de synchronisation enregistré.</p></div>';
		}

		// ---- Flotte (maître + liste des sites) --------------------------
		if (
			isset( $_POST['gigi_save_fleet'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_fleet' )
		) {
			$is_master = ! empty( $_POST['gigi_is_master'] );
			Gigi_Fleet::set_is_master( $is_master );
			if ( $is_master && isset( $_POST['gigi_fleet_sites'] ) ) {
				Gigi_Fleet::save_sites( wp_unslash( (string) $_POST['gigi_fleet_sites'] ) );
			}
			echo '<div class="notice notice-success is-dismissible"><p>Configuration de la flotte enregistrée.</p></div>';
		}

		// ---- Sync flotte depuis le maître ------------------------------
		$fleet_sync_results = null;
		if (
			isset( $_POST['gigi_fleet_sync'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_fleet_sync' )
		) {
			if ( ! Gigi_Fleet::is_master() ) {
				echo '<div class="notice notice-error is-dismissible"><p>Seul le site maître peut synchroniser la flotte.</p></div>';
			} else {
				// Appliquer d’abord localement (thème + layout).
				$local_request  = new WP_REST_Request( 'POST', '/gigi-checker/v1/sync' );
				$local_response = Gigi_Remote_Sync::sync_and_apply( $local_request );
				$fleet_sync_results = [
					'local'  => $local_response->get_data(),
					'remote' => Gigi_Fleet::sync_all_remote(),
				];
			}
		}

		// ---- Resync des template parts de layout ---------------------
		if (
			isset( $_POST['gigi_layout_sync'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_sync' )
		) {
			$layout_report = Gigi_Layout_Sync::sync_all();
			$reset_count   = count( $layout_report['reset'] );
			if ( $reset_count > 0 ) {
				printf(
					'<div class="notice notice-success is-dismissible"><p>Layout resynchronisé : %d composant(s) réinitialisé(s) depuis les fichiers du thème (%s).</p></div>',
					$reset_count,
					esc_html( implode( ', ', $layout_report['reset'] ) )
				);
			} else {
				echo '<div class="notice notice-info is-dismissible"><p>Aucune surcharge en base — les template parts utilisent déjà les fichiers du thème.</p></div>';
			}
		}

		// ---- Fetch frais (ignore le cache) -----------------------------
		$remote      = Gigi_Versions::fetch_remote();
		$last_error  = Gigi_Versions::get_last_error();
		$current_url = Gigi_Versions::get_url();
		$slugs       = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];

		echo '<div class="wrap">';
		echo '<h1>Gigi Checker — État</h1>';

		// ---- Connexion au repo distant ----------------------------------
		echo '<h2>Connexion</h2>';
		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			echo '<strong>❌ Échec de connexion</strong><br>';
			printf( 'URL : <code>%s</code><br>', esc_html( $current_url ) );
			printf( 'Erreur : <code>%s</code>', esc_html( $last_error['message'] ) );
			if ( ! empty( $last_error['code'] ) && 'http_error' !== $last_error['type'] ) {
				printf( ' (<code>%s</code>)', esc_html( (string) $last_error['code'] ) );
			}
			echo '</p></div>';
		} elseif ( empty( $remote ) ) {
			echo '<div class="notice notice-error inline"><p>';
			printf( '❌ Impossible de récupérer <code>%s</code>.', esc_html( $current_url ) );
			echo '</p></div>';
		} else {
			echo '<div class="notice notice-success inline"><p>';
			printf( '✅ Connexion OK — <code>%s</code>', esc_html( $current_url ) );
			echo '</p></div>';
		}

		// ---- Configuration de l'URL ------------------------------------
		echo '<h2>URL du fichier versions.json</h2>';
		echo '<p><strong>Par défaut</strong> : Bitbucket puis GitHub automatiquement si Bitbucket est bloqué.</p>';
		echo '<ul style="list-style:disc;margin-left:1.5em">';
		echo '<li><code>' . esc_html( GIGI_VERSIONS_URL ) . '</code> (prioritaire)</li>';
		echo '<li><code>' . esc_html( GIGI_VERSIONS_URL_FALLBACK ) . '</code> (secours)</li>';
		echo '</ul>';
		echo '<p class="description"><strong>À éviter</strong> : <code>cdn.jsdelivr.net/.../versions.json</code> — le CDN met ce fichier en cache très longtemps (versions obsolètes). Les ZIP en <code>gigi-theme-X.X.X.zip</code> sur jsDelivr vont bien.</p>';
		echo '<form method="post">';
		wp_nonce_field( 'gigi_save_url' );
		printf(
			'<input type="url" name="gigi_versions_url" value="%s" class="regular-text" style="width:500px;max-width:100%%">',
			esc_attr( $current_url )
		);
		echo ' <button type="submit" class="button button-primary">Enregistrer et tester</button>';
		echo '</form>';

		// ---- Synchronisation à distance (script update-all-sites) -------
		echo '<h2>Synchronisation à distance</h2>';
		echo '<p>Secret partagé entre tous les sites (requis pour la sync flotte et le script <code>update-all-sites.sh</code>).</p>';
		$sync_secret = get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		echo '<form method="post">';
		wp_nonce_field( 'gigi_save_sync_secret' );
		echo '<input type="password" name="gigi_sync_secret" value="' . esc_attr( $sync_secret ) . '" class="regular-text" style="width:300px" placeholder="Secret partagé (vide = désactivé)" autocomplete="off"> ';
		echo '<button type="submit" class="button button-primary">Enregistrer</button>';
		echo '</form>';

		// ---- Flotte multi-sites ----------------------------------------
		echo '<h2>Flotte multi-sites</h2>';
		$is_master   = Gigi_Fleet::is_master();
		$fleet_sites = Gigi_Fleet::get_sites();
		$textarea    = $fleet_sites
			? Gigi_Fleet::sites_to_textarea( $fleet_sites )
			: Gigi_Fleet::default_sites_textarea();

		echo '<p>Le <strong>site maître</strong> détient la liste des sites et peut déclencher une mise à jour sur toute la flotte. '
			. 'Les satellites n’ont besoin que du même secret partagé.</p>';

		echo '<form method="post" style="margin-bottom:1.5em">';
		wp_nonce_field( 'gigi_save_fleet' );
		echo '<input type="hidden" name="gigi_save_fleet" value="1">';
		echo '<p><label><input type="checkbox" name="gigi_is_master" value="1"' . checked( $is_master, true, false ) . '> '
			. 'Ce site est le <strong>maître</strong> de la flotte</label></p>';

		if ( $is_master || empty( $fleet_sites ) ) {
			echo '<p><label for="gigi_fleet_sites"><strong>Sites de la flotte</strong> (une ligne = <code>Label | https://url</code>)</label></p>';
			printf(
				'<textarea name="gigi_fleet_sites" id="gigi_fleet_sites" rows="6" class="large-text code" style="max-width:640px">%s</textarea>',
				esc_textarea( $textarea )
			);
			echo '<p class="description">Incluez le site maître lui-même. Les URLs sans <code>www</code> / avec <code>www</code> doivent correspondre à l’URL réelle du site.</p>';
		} else {
			echo '<p class="description">Ce site est un satellite — la liste se configure sur le maître.</p>';
		}

		echo '<p><button type="submit" class="button button-primary">Enregistrer la flotte</button></p>';
		echo '</form>';

		if ( $is_master ) {
			if ( empty( $fleet_sites ) ) {
				echo '<div class="notice notice-warning inline"><p>Enregistrez d’abord la liste des sites.</p></div>';
			} else {
				echo '<table class="widefat striped" style="max-width:800px;margin-bottom:1em">';
				echo '<thead><tr><th>Site</th><th>URL</th><th>Rôle</th></tr></thead><tbody>';
				$current = Gigi_Fleet::get_current_site_url();
				foreach ( $fleet_sites as $site ) {
					$role = Gigi_Fleet::urls_match( $site['url'], $current ) ? '⭐ Maître (ce site)' : 'Satellite';
					printf(
						'<tr><td><strong>%s</strong></td><td><code>%s</code></td><td>%s</td></tr>',
						esc_html( $site['label'] ),
						esc_html( $site['url'] ),
						esc_html( $role )
					);
				}
				echo '</tbody></table>';

				echo '<form method="post">';
				wp_nonce_field( 'gigi_fleet_sync' );
				echo '<input type="hidden" name="gigi_fleet_sync" value="1">';
				echo '<button type="submit" class="button button-primary">Mettre à jour toute la flotte maintenant</button>';
				echo '<p class="description">Applique les MAJ Gigi sur ce site, puis appelle <code>/sync</code> sur chaque satellite (même secret requis partout).</p>';
				echo '</form>';
			}
		}

		if ( is_array( $fleet_sync_results ) ) {
			echo '<h3>Résultat de la sync flotte</h3>';
			$local = $fleet_sync_results['local'] ?? [];
			printf(
				'<p><strong>Local</strong> : %s</p>',
				esc_html( is_array( $local ) ? (string) ( $local['message'] ?? wp_json_encode( $local ) ) : '' )
			);
			echo '<table class="widefat striped" style="max-width:900px">';
			echo '<thead><tr><th>Satellite</th><th>HTTP</th><th>Résultat</th></tr></thead><tbody>';
			foreach ( $fleet_sync_results['remote'] ?? [] as $row ) {
				if ( ! empty( $row['error'] ) && '' === ( $row['url'] ?? '' ) ) {
					printf(
						'<tr><td colspan="3" style="color:#d63638">%s</td></tr>',
						esc_html( $row['error'] )
					);
					continue;
				}
				$ok    = ! empty( $row['ok'] );
				$color = $ok ? 'green' : '#d63638';
				$msg   = $row['error'] ?? '';
				if ( ! $msg && is_array( $row['body'] ?? null ) ) {
					$msg = (string) ( $row['body']['message'] ?? wp_json_encode( $row['body'] ) );
				} elseif ( ! $msg && is_string( $row['body'] ?? null ) ) {
					$msg = $row['body'];
				}
				printf(
					'<tr><td><strong>%s</strong><br><small><code>%s</code></small></td><td>%d</td><td style="color:%s">%s %s</td></tr>',
					esc_html( $row['label'] ?? '' ),
					esc_html( $row['url'] ?? '' ),
					(int) ( $row['http_code'] ?? 0 ),
					esc_attr( $color ),
					$ok ? '✅' : '❌',
					esc_html( (string) $msg )
				);
			}
			echo '</tbody></table>';
		}

		// ---- Layout synchronisé (template parts) -----------------------
		echo '<h2>Layout synchronisé</h2>';
		echo '<p>Header, footer et navigation sont définis dans <code>gigi-theme/parts/</code>. '
			. 'Si quelqu’un les modifie dans l’éditeur de site, WordPress enregistre une copie en base qui masque le fichier du thème. '
			. 'Après une MAJ du thème, les surcharges listées ci-dessous sont automatiquement supprimées.</p>';

		$layout_status = Gigi_Layout_Sync::get_status();
		if ( empty( $layout_status ) ) {
			echo '<p><em>Manifeste introuvable — mettez à jour gigi-theme et gigi-checker.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:800px">';
			echo '<thead><tr><th>Composant</th><th>Source active</th><th>État</th></tr></thead><tbody>';
			foreach ( $layout_status as $item ) {
				if ( $item['customized'] ) {
					$source_label = 'Base de données (surcharge)';
					$state        = '⚠️ Sera réinitialisé à la prochaine MAJ';
					$color        = '#d63638';
				} else {
					$source_label = 'Fichier du thème';
					$state        = '✅ Synchronisé';
					$color        = 'green';
				}
				printf(
					'<tr><td><strong>%s</strong><br><small style="color:#666"><code>%s</code></small></td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
					esc_html( $item['label'] ),
					esc_html( $item['slug'] ),
					esc_html( $source_label ),
					esc_attr( $color ),
					esc_html( $state )
				);
			}
			echo '</tbody></table>';
			echo '<form method="post" style="margin-top:1em">';
			wp_nonce_field( 'gigi_layout_sync' );
			echo '<input type="hidden" name="gigi_layout_sync" value="1">';
			echo '<button type="submit" class="button">Forcer la resynchronisation maintenant</button>';
			echo '</form>';
		}

		// ---- Tableau des versions --------------------------------------
		echo '<h2>Versions</h2>';

		if ( empty( $remote ) ) {
			echo '<p><em>Impossible d\'afficher les versions — le fichier versions.json est inaccessible.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:800px">';
			echo '<thead><tr><th>Composant</th><th>Installé</th><th>Disponible</th><th>État</th></tr></thead><tbody>';

			foreach ( $slugs as $slug ) {
				$remote_data    = $remote[ $slug ] ?? null;
				$remote_version = $remote_data['version'] ?? '—';

				if ( 'gigi-theme' === $slug ) {
					$theme           = wp_get_theme( $slug );
					$installed       = $theme->exists() ? $theme->get( 'Version' ) : '(non trouvé)';
					$component_label = $theme->exists() ? $theme->get( 'Name' ) : $slug;
				} else {
					$plugin_path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
					if ( file_exists( $plugin_path ) ) {
						if ( ! function_exists( 'get_plugin_data' ) ) {
							require_once ABSPATH . 'wp-admin/includes/plugin.php';
						}
						$data            = get_plugin_data( $plugin_path );
						$installed       = $data['Version'];
						$component_label = $data['Name'];
					} else {
						$installed       = '(non trouvé)';
						$component_label = $slug;
					}
				}

				if ( '—' === $remote_version ) {
					$status = '⚠️ Absent du versions.json';
					$color  = 'orange';
				} elseif ( '(non trouvé)' === $installed ) {
					$status = '⚠️ Plugin/thème non installé';
					$color  = 'orange';
				} elseif ( version_compare( $installed, $remote_version, '<' ) ) {
					$status = '🔄 Mise à jour disponible';
					$color  = '#0073aa';
				} else {
					$status = '✅ À jour';
					$color  = 'green';
				}

				printf(
					'<tr><td><strong>%s</strong><br><small style="color:#666">%s</small></td><td>%s</td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
					esc_html( $component_label ),
					esc_html( $slug ),
					esc_html( $installed ),
					esc_html( $remote_version ),
					esc_attr( $color ),
					esc_html( $status )
				);
			}

			echo '</tbody></table>';
		}

		// ---- Cache WordPress -------------------------------------------
		echo '<h2>Cache WordPress</h2>';
		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Transient</th><th>Contenu Gigi</th><th>Dernière vérification</th></tr></thead><tbody>';

		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'response → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'no_update → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = '⚠️ Absent';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i:s', $t_plugins->last_checked ) : '—';
			printf( '<tr><td>update_plugins</td><td><code>%s</code> : %s</td><td>%s</td></tr>',
				esc_html( $slug_short ), esc_html( $info ), esc_html( $last ) );
		}

		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'response → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'no_update → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = '⚠️ Absent';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i:s', $t_themes->last_checked ) : '—';
		printf( '<tr><td>update_themes</td><td><code>gigi-theme</code> : %s</td><td>%s</td></tr>',
			esc_html( $t_info ), esc_html( $last_t ) );

		echo '</tbody></table>';

		// ---- Actions ---------------------------------------------------
		echo '<p style="margin-top:1.5em">';
		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf( '<a href="%s" class="button button-primary">Vider le cache et vérifier</a>',
			esc_url( $flush_url ) );
		echo '</p>';

		echo '</div>';
	}
}
