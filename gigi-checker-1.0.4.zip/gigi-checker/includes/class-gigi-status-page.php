<?php
/**
 * Gigi_Status_Page — page d'état dans l'admin WP (Outils → Gigi Checker).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	public static function register(): void {
		add_management_page(
			'Gigi Checker — État',
			'Gigi Checker',
			'update_plugins',
			'gigi-checker-status',
			[ self::class, 'render' ]
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		// ---- Sauvegarde de l'URL personnalisée -------------------------
		if (
			isset( $_POST['gigi_versions_url'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_url' )
		) {
			$new_url = sanitize_url( trim( wp_unslash( $_POST['gigi_versions_url'] ) ) );
			Gigi_Versions::save_url( $new_url );
			Gigi_Versions::flush_cache();
			echo '<div class="notice notice-success is-dismissible"><p>URL mise à jour. Le cache a été vidé.</p></div>';
		}

		// ---- Fetch frais (ignore le cache) -----------------------------
		$remote      = Gigi_Versions::fetch_remote();
		$last_error  = Gigi_Versions::get_last_error();
		$current_url = Gigi_Versions::get_url();
		$slugs       = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];

		echo '<div class="wrap">';
		echo '<h1>Gigi Checker — État</h1>';

		// ---- Connexion au repo distant ----------------------------------
		echo '<h2>Connexion</h2>';
		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			echo '<strong>❌ Échec de connexion</strong><br>';
			printf( 'URL : <code>%s</code><br>', esc_html( $current_url ) );
			printf( 'Erreur : <code>%s</code>', esc_html( $last_error['message'] ) );
			if ( ! empty( $last_error['code'] ) && 'http_error' !== $last_error['type'] ) {
				printf( ' (<code>%s</code>)', esc_html( (string) $last_error['code'] ) );
			}
			echo '</p></div>';
		} elseif ( empty( $remote ) ) {
			echo '<div class="notice notice-error inline"><p>';
			printf( '❌ Impossible de récupérer <code>%s</code>.', esc_html( $current_url ) );
			echo '</p></div>';
		} else {
			echo '<div class="notice notice-success inline"><p>';
			printf( '✅ Connexion OK — <code>%s</code>', esc_html( $current_url ) );
			echo '</p></div>';
		}

		// ---- Configuration de l'URL ------------------------------------
		echo '<h2>URL du fichier versions.json</h2>';
		echo '<p>Par défaut : <code>' . esc_html( GIGI_VERSIONS_URL ) . '</code></p>';
		echo '<p>Si votre hébergeur bloque Bitbucket, utilisez <strong>jsDelivr (GitHub)</strong> :<br>';
		echo '<code>https://cdn.jsdelivr.net/gh/<strong>VOTRE_USER</strong>/<strong>VOTRE_REPO</strong>@latest/versions.json</code></p>';
		echo '<form method="post">';
		wp_nonce_field( 'gigi_save_url' );
		printf(
			'<input type="url" name="gigi_versions_url" value="%s" class="regular-text" style="width:500px;max-width:100%%">',
			esc_attr( $current_url )
		);
		echo ' <button type="submit" class="button button-primary">Enregistrer et tester</button>';
		echo '</form>';

		// ---- Tableau des versions --------------------------------------
		echo '<h2>Versions</h2>';

		if ( empty( $remote ) ) {
			echo '<p><em>Impossible d\'afficher les versions — le fichier versions.json est inaccessible.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:800px">';
			echo '<thead><tr><th>Composant</th><th>Installé</th><th>Disponible</th><th>État</th></tr></thead><tbody>';

			foreach ( $slugs as $slug ) {
				$remote_data    = $remote[ $slug ] ?? null;
				$remote_version = $remote_data['version'] ?? '—';

				if ( 'gigi-theme' === $slug ) {
					$theme           = wp_get_theme( $slug );
					$installed       = $theme->exists() ? $theme->get( 'Version' ) : '(non trouvé)';
					$component_label = $theme->exists() ? $theme->get( 'Name' ) : $slug;
				} else {
					$plugin_path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
					if ( file_exists( $plugin_path ) ) {
						if ( ! function_exists( 'get_plugin_data' ) ) {
							require_once ABSPATH . 'wp-admin/includes/plugin.php';
						}
						$data            = get_plugin_data( $plugin_path );
						$installed       = $data['Version'];
						$component_label = $data['Name'];
					} else {
						$installed       = '(non trouvé)';
						$component_label = $slug;
					}
				}

				if ( '—' === $remote_version ) {
					$status = '⚠️ Absent du versions.json';
					$color  = 'orange';
				} elseif ( '(non trouvé)' === $installed ) {
					$status = '⚠️ Plugin/thème non installé';
					$color  = 'orange';
				} elseif ( version_compare( $installed, $remote_version, '<' ) ) {
					$status = '🔄 Mise à jour disponible';
					$color  = '#0073aa';
				} else {
					$status = '✅ À jour';
					$color  = 'green';
				}

				printf(
					'<tr><td><strong>%s</strong><br><small style="color:#666">%s</small></td><td>%s</td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
					esc_html( $component_label ),
					esc_html( $slug ),
					esc_html( $installed ),
					esc_html( $remote_version ),
					esc_attr( $color ),
					esc_html( $status )
				);
			}

			echo '</tbody></table>';
		}

		// ---- Cache WordPress -------------------------------------------
		echo '<h2>Cache WordPress</h2>';
		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Transient</th><th>Contenu Gigi</th><th>Dernière vérification</th></tr></thead><tbody>';

		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'response → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'no_update → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = '⚠️ Absent';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i:s', $t_plugins->last_checked ) : '—';
			printf( '<tr><td>update_plugins</td><td><code>%s</code> : %s</td><td>%s</td></tr>',
				esc_html( $slug_short ), esc_html( $info ), esc_html( $last ) );
		}

		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'response → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'no_update → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = '⚠️ Absent';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i:s', $t_themes->last_checked ) : '—';
		printf( '<tr><td>update_themes</td><td><code>gigi-theme</code> : %s</td><td>%s</td></tr>',
			esc_html( $t_info ), esc_html( $last_t ) );

		echo '</tbody></table>';

		// ---- Actions ---------------------------------------------------
		echo '<p style="margin-top:1.5em">';
		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf( '<a href="%s" class="button button-primary">Vider le cache et vérifier</a>',
			esc_url( $flush_url ) );
		echo '</p>';

		echo '</div>';
	}
}
