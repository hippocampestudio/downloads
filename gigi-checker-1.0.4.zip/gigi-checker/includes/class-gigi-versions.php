<?php
/**
 * Gigi_Versions — récupère et met en cache le fichier versions.json distant.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Versions {

	private const CACHE_KEY      = 'gigi_checker_versions';
	private const LAST_ERROR_KEY = 'gigi_checker_last_error';
	private const URL_OPTION     = 'gigi_checker_versions_url';

	/**
	 * Retourne l'URL active (option WP > constante par défaut).
	 */
	public static function get_url(): string {
		$option = get_option( self::URL_OPTION, '' );
		return ( is_string( $option ) && '' !== trim( $option ) )
			? trim( $option )
			: GIGI_VERSIONS_URL;
	}

	public static function get(): array {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		return self::fetch_remote();
	}

	/**
	 * Récupère le fichier distant.
	 * Sauvegarde l'erreur éventuelle pour affichage dans la page d'état.
	 */
	public static function fetch_remote(): array {
		$url = add_query_arg( 'ts', time(), self::get_url() );

		$response = wp_remote_get( $url, [
			'timeout'    => 15,
			'user-agent' => 'GigiChecker/' . GIGI_CHECKER_VERSION . '; ' . home_url(),
			'headers'    => [
				'Cache-Control' => 'no-cache',
				'Pragma'        => 'no-cache',
			],
		] );

		if ( is_wp_error( $response ) ) {
			update_option( self::LAST_ERROR_KEY, [
				'type'    => 'wp_error',
				'message' => $response->get_error_message(),
				'code'    => $response->get_error_code(),
				'url'     => self::get_url(),
				'time'    => time(),
			] );
			return [];
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			update_option( self::LAST_ERROR_KEY, [
				'type'    => 'http_error',
				'message' => 'Réponse HTTP : ' . $code . ' ' . wp_remote_retrieve_response_message( $response ),
				'code'    => $code,
				'url'     => self::get_url(),
				'time'    => time(),
			] );
			return [];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			update_option( self::LAST_ERROR_KEY, [
				'type'    => 'json_error',
				'message' => 'JSON invalide reçu : ' . esc_html( mb_substr( $body, 0, 200 ) ),
				'code'    => 0,
				'url'     => self::get_url(),
				'time'    => time(),
			] );
			return [];
		}

		// Succès — efface l'erreur précédente
		delete_option( self::LAST_ERROR_KEY );
		set_transient( self::CACHE_KEY, $data, GIGI_CHECKER_CACHE_TTL );

		return $data;
	}

	public static function get_last_error(): ?array {
		$err = get_option( self::LAST_ERROR_KEY, null );
		return is_array( $err ) ? $err : null;
	}

	public static function get_for( string $slug ): ?array {
		$versions = self::get();
		return $versions[ $slug ] ?? null;
	}

	public static function flush_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	public static function save_url( string $url ): void {
		update_option( self::URL_OPTION, sanitize_url( trim( $url ) ) );
	}
}
