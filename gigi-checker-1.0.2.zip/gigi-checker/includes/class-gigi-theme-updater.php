<?php
/**
 * Gigi_Theme_Updater — injecte les mises à jour du thème dans WordPress.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Theme_Updater {

	private string $theme_slug;

	public function __construct( string $theme_slug ) {
		$this->theme_slug = $theme_slug;

		add_filter( 'pre_set_site_transient_update_themes', [ $this, 'inject_update' ] );
		add_filter( 'site_transient_update_themes',         [ $this, 'inject_update' ] );
		add_filter( 'themes_api', [ $this, 'theme_api_info' ], 10, 3 );
	}

	/**
	 * Injecte la mise à jour du thème dans le transient WordPress.
	 *
	 * @param mixed $transient
	 * @return mixed
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		if ( ! isset( $transient->response ) )  $transient->response  = [];
		if ( ! isset( $transient->no_update ) ) $transient->no_update = [];

		$remote = Gigi_Versions::get_for( $this->theme_slug );
		if ( null === $remote || empty( $remote['version'] ) || empty( $remote['zip_url'] ) ) {
			return $transient;
		}

		$current_theme   = wp_get_theme( $this->theme_slug );
		$current_version = $current_theme->get( 'Version' );

		if ( version_compare( $current_version, $remote['version'], '<' ) ) {
			unset( $transient->no_update[ $this->theme_slug ] );

			$transient->response[ $this->theme_slug ] = [
				'theme'        => $this->theme_slug,
				'new_version'  => $remote['version'],
				'url'          => 'https://bitbucket.org/antibo/gigi',
				'package'      => $remote['zip_url'],
				'requires'     => $remote['requires']     ?? '6.4',
				'requires_php' => $remote['requires_php'] ?? '8.1',
			];
		} else {
			unset( $transient->response[ $this->theme_slug ] );

			$transient->no_update[ $this->theme_slug ] = [
				'theme'       => $this->theme_slug,
				'new_version' => $current_version,
				'url'         => 'https://bitbucket.org/antibo/gigi',
				'package'     => '',
			];
		}

		return $transient;
	}

	/**
	 * Fournit les informations du thème pour l'écran de détail WP.
	 *
	 * @param false|object $result
	 * @param string       $action
	 * @param object       $args
	 */
	public function theme_api_info( $result, string $action, object $args ) {
		if ( 'theme_information' !== $action ) {
			return $result;
		}

		if ( ! isset( $args->slug ) || $args->slug !== $this->theme_slug ) {
			return $result;
		}

		$remote = Gigi_Versions::get_for( $this->theme_slug );
		if ( null === $remote ) {
			return $result;
		}

		return (object) [
			'name'          => 'Gigi Theme',
			'slug'          => $this->theme_slug,
			'version'       => $remote['version'],
			'author'        => 'Antibo',
			'homepage'      => 'https://bitbucket.org/antibo/gigi',
			'download_link' => $remote['zip_url'],
			'requires'      => $remote['requires']     ?? '6.4',
			'requires_php'  => $remote['requires_php'] ?? '8.1',
			'tested'        => $remote['tested']       ?? '6.7',
			'sections'      => [
				'description' => 'Thème de blocs Gigi pour les sites du groupe.',
				'changelog'   => $remote['changelog'] ?? '',
			],
		];
	}
}
