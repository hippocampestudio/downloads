<?php
/**
 * Plugin Name: Gigi Checker
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Vérifie les mises à jour du thème Gigi et des plugins Gigi via le dépôt public Bitbucket, et les injecte dans le système de mises à jour automatiques WordPress.
 * Version:     1.0.2
 * Author:      Antibo
 * Author URI:  https://bitbucket.org/antibo
 * License:     Proprietary
 * Text Domain: gigi-checker
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_CHECKER_VERSION', '1.0.2' );
define( 'GIGI_CHECKER_FILE', __FILE__ );

/**
 * URL du fichier versions.json dans le repo public Bitbucket.
 * Ce fichier liste les versions courantes du thème et des plugins.
 *
 * Format du fichier raw Bitbucket :
 * https://bitbucket.org/{workspace}/{repo}/raw/{branch}/{fichier}
 */
define( 'GIGI_VERSIONS_URL', 'https://bitbucket.org/antibo/downloads/raw/main/versions.json' );

/**
 * Durée de cache du fichier versions.json (en secondes).
 * Par défaut : 12 heures — correspond à la fréquence des vérifications WP.
 */
define( 'GIGI_CHECKER_CACHE_TTL', 12 * HOUR_IN_SECONDS );

require_once __DIR__ . '/includes/class-gigi-versions.php';
require_once __DIR__ . '/includes/class-gigi-theme-updater.php';
require_once __DIR__ . '/includes/class-gigi-plugin-updater.php';

/**
 * Notice admin si versions.json est inaccessible.
 */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	// Ne tester que si le cache est vide (pas de fetch supplémentaire en routine)
	$cached = get_transient( 'gigi_checker_versions' );
	if ( false !== $cached ) {
		return;
	}

	$data = Gigi_Versions::fetch_remote();

	if ( empty( $data ) ) {
		echo '<div class="notice notice-error is-dismissible"><p>'
			. '<strong>Gigi Checker</strong> : impossible de contacter '
			. '<code>' . esc_html( GIGI_VERSIONS_URL ) . '</code>. '
			. 'Vérifiez que le serveur autorise les requêtes HTTP sortantes vers Bitbucket.'
			. '</p></div>';
	}
} );

/**
 * Initialise les updaters au bon moment dans le cycle WP.
 */
add_action( 'init', function () {
	new Gigi_Theme_Updater( 'gigi-theme' );
	new Gigi_Plugin_Updater( 'gigi-checker/gigi-checker.php', 'gigi-checker' );
	new Gigi_Plugin_Updater( 'gigi-blocks/gigi-blocks.php', 'gigi-blocks' );
} );

/**
 * Ajoute un lien "Vérifier les MAJ" dans la liste des plugins.
 */
add_filter( 'plugin_action_links_' . plugin_basename( GIGI_CHECKER_FILE ), function ( array $links ): array {
	$check_url = wp_nonce_url(
		add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
		'gigi_force_check'
	);
	array_unshift( $links, sprintf(
		'<a href="%s">%s</a>',
		esc_url( $check_url ),
		esc_html__( 'Vérifier les MAJ', 'gigi-checker' )
	) );
	return $links;
} );

/**
 * Traite la demande de vérification forcée depuis l'admin.
 */
add_action( 'admin_init', function () {
	if (
		! isset( $_GET['gigi-force-check'] ) ||
		! current_user_can( 'update_plugins' ) ||
		! check_admin_referer( 'gigi_force_check' )
	) {
		return;
	}

	Gigi_Versions::flush_cache();

	// Vide les transients WP pour forcer un re-check complet
	delete_site_transient( 'update_plugins' );
	delete_site_transient( 'update_themes' );

	/*
	 * Redirige vers update-core.php avec ?force-check=1 + nonce valide.
	 * Sans le nonce, WordPress ignore le paramètre force-check depuis WP 5.x.
	 * Avec force-check, WP appelle wp_update_plugins(true) → notre hook injecte
	 * nos MAJ dans le transient fraîchement écrit, elles apparaissent immédiatement.
	 */
	$redirect = wp_nonce_url(
		add_query_arg( 'force-check', '1', admin_url( 'update-core.php' ) ),
		'force-check-update_core'
	);

	wp_redirect( $redirect );
	exit;
} );
