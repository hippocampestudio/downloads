<?php
/**
 * Plugin Name: Gigi Checker
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Vérifie les mises à jour du thème Gigi et des plugins Gigi via le dépôt public Bitbucket, et les injecte dans le système de mises à jour automatiques WordPress.
 * Version:     1.0.20
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-checker
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_CHECKER_VERSION', '1.0.20' );
define( 'GIGI_CHECKER_FILE', __FILE__ );

/**
 * versions.json : priorité Bitbucket (à jour dès le push).
 * Fallback GitHub raw (cache ~5 min). Ne pas utiliser jsDelivr pour ce fichier :
 * cdn.jsdelivr.net/gh/.../versions.json reste obsolète des jours sur la branche @main.
 * Les ZIPs restent sur jsDelivr (URL versionnée, immuable).
 */
define( 'GIGI_VERSIONS_URL', 'https://bitbucket.org/antibo/downloads/raw/main/versions.json' );
define( 'GIGI_VERSIONS_URL_FALLBACK', 'https://raw.githubusercontent.com/hippocampestudio/downloads/main/versions.json' );

/**
 * Durée de cache du fichier versions.json (en secondes).
 * Par défaut : 12 heures — correspond à la fréquence des vérifications WP.
 */
define( 'GIGI_CHECKER_CACHE_TTL', 12 * HOUR_IN_SECONDS );

require_once __DIR__ . '/includes/class-gigi-versions.php';
require_once __DIR__ . '/includes/class-gigi-theme-updater.php';
require_once __DIR__ . '/includes/class-gigi-plugin-updater.php';
require_once __DIR__ . '/includes/class-gigi-status-page.php';
require_once __DIR__ . '/includes/class-gigi-remote-sync.php';
require_once __DIR__ . '/includes/class-gigi-layout-sync.php';
require_once __DIR__ . '/includes/class-gigi-fleet.php';

add_action( 'plugins_loaded', function (): void {
	if ( version_compare( (string) get_option( 'gigi_checker_internal_version', '0' ), '1.0.8', '>=' ) ) {
		return;
	}
	$url = get_option( 'gigi_checker_versions_url', '' );
	if ( is_string( $url ) && $url !== '' && str_contains( $url, 'jsdelivr.net' ) ) {
		delete_option( 'gigi_checker_versions_url' );
		delete_transient( 'gigi_checker_versions' );
	}
	update_option( 'gigi_checker_internal_version', '1.0.8' );
}, 5 );

add_action( 'admin_menu', [ 'Gigi_Status_Page', 'register' ] );
Gigi_Remote_Sync::register();
Gigi_Layout_Sync::register();

/**
 * Notice admin si versions.json est inaccessible.
 */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	// Ne tester que si le cache est vide (pas de fetch supplémentaire en routine)
	$cached = get_transient( 'gigi_checker_versions' );
	if ( false !== $cached ) {
		return;
	}

	$data = Gigi_Versions::fetch_remote();

	if ( empty( $data ) ) {
		echo '<div class="notice notice-error is-dismissible"><p>'
			. '<strong>Gigi Checker</strong> : impossible de contacter '
			. '<code>' . esc_html( GIGI_VERSIONS_URL ) . '</code>. '
			. 'Vérifiez les requêtes HTTP sortantes (Bitbucket puis GitHub).'
			. '</p></div>';
	}
} );

/**
 * Initialise les updaters au bon moment dans le cycle WP.
 */
add_action( 'init', function () {
	new Gigi_Theme_Updater( 'gigi-theme' );
	new Gigi_Plugin_Updater( 'gigi-checker/gigi-checker.php', 'gigi-checker' );
	new Gigi_Plugin_Updater( 'gigi-blocks/gigi-blocks.php', 'gigi-blocks' );
} );

/**
 * Ajoute un lien "Vérifier les MAJ" dans la liste des plugins.
 */
add_filter( 'plugin_action_links_' . plugin_basename( GIGI_CHECKER_FILE ), function ( array $links ): array {
	$check_url = wp_nonce_url(
		add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
		'gigi_force_check'
	);
	$status_url = admin_url( 'tools.php?page=gigi-checker-status' );
	array_unshift( $links,
		sprintf( '<a href="%s">%s</a>', esc_url( $status_url ), 'État' ),
		sprintf( '<a href="%s">%s</a>', esc_url( $check_url ), 'Vérifier les MAJ' )
	);
	return $links;
} );

/**
 * Traite la demande de vérification forcée depuis l'admin.
 *
 * Au lieu de déléguer à wp_update_plugins() / api.wordpress.org (lent, asynchrone),
 * on fetch versions.json directement puis on écrit nous-mêmes dans les transients WP.
 * La redirection vers update-core.php affiche immédiatement les mises à jour.
 */
add_action( 'admin_init', function () {
	if (
		! isset( $_GET['gigi-force-check'] ) ||
		! current_user_can( 'update_plugins' ) ||
		! check_admin_referer( 'gigi_force_check' )
	) {
		return;
	}

	// 1. Fetch fresh — vide le cache Gigi et récupère les données immédiatement.
	Gigi_Versions::flush_cache();
	$remote = Gigi_Versions::fetch_remote();

	if ( ! empty( $remote ) ) {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// 2. Plugins — on merge dans le transient existant pour ne pas effacer
		//    les mises à jour d'autres plugins.
		$tp = get_site_transient( 'update_plugins' );
		if ( ! is_object( $tp ) ) {
			$tp = new stdClass();
		}
		if ( ! isset( $tp->response ) )  $tp->response  = [];
		if ( ! isset( $tp->no_update ) ) $tp->no_update = [];
		if ( ! isset( $tp->checked ) )   $tp->checked   = [];

		foreach ( [
			'gigi-checker/gigi-checker.php' => 'gigi-checker',
			'gigi-blocks/gigi-blocks.php'   => 'gigi-blocks',
		] as $plugin_file => $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $plugin_file;
			if ( ! file_exists( $path ) ) {
				continue;
			}

			$data            = get_plugin_data( $path );
			$current_version = $data['Version'] ?? '0.0.0';
			$r               = $remote[ $slug ] ?? null;

			$tp->checked[ $plugin_file ] = $current_version;

			if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
				unset( $tp->no_update[ $plugin_file ] );
				$tp->response[ $plugin_file ] = (object) [
					'id'           => 'gigi/' . $slug,
					'slug'         => $slug,
					'plugin'       => $plugin_file,
					'new_version'  => $r['version'],
					'url'          => 'https://hippocampe.studio',
					'package'      => $r['zip_url'],
					'icons'        => [],
					'banners'      => [],
					'tested'       => $r['tested']       ?? '6.7',
					'requires_php' => $r['requires_php'] ?? '8.1',
					'requires'     => $r['requires']     ?? '6.4',
				];
			} elseif ( $r ) {
				unset( $tp->response[ $plugin_file ] );
				$tp->no_update[ $plugin_file ] = (object) [
					'id'          => 'gigi/' . $slug,
					'slug'        => $slug,
					'plugin'      => $plugin_file,
					'new_version' => $current_version,
					'url'         => 'https://hippocampe.studio',
					'package'     => '',
					'icons'       => [],
					'banners'     => [],
				];
			}
		}
		set_site_transient( 'update_plugins', $tp );

		// 3. Thème — même logique.
		$tt = get_site_transient( 'update_themes' );
		if ( ! is_object( $tt ) ) {
			$tt = new stdClass();
		}
		if ( ! isset( $tt->response ) )  $tt->response  = [];
		if ( ! isset( $tt->no_update ) ) $tt->no_update = [];
		if ( ! isset( $tt->checked ) )   $tt->checked   = [];

		$theme           = wp_get_theme( 'gigi-theme' );
		$current_version = $theme->get( 'Version' );
		$r               = $remote['gigi-theme'] ?? null;

		$tt->checked['gigi-theme'] = $current_version;

		if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
			unset( $tt->no_update['gigi-theme'] );
			$tt->response['gigi-theme'] = [
				'theme'        => 'gigi-theme',
				'new_version'  => $r['version'],
				'url'          => 'https://hippocampe.studio',
				'package'      => $r['zip_url'],
				'requires'     => $r['requires']     ?? '6.4',
				'requires_php' => $r['requires_php'] ?? '8.1',
			];
		} elseif ( $r ) {
			unset( $tt->response['gigi-theme'] );
			$tt->no_update['gigi-theme'] = [
				'theme'       => 'gigi-theme',
				'new_version' => $current_version,
				'url'         => 'https://hippocampe.studio',
				'package'     => '',
			];
		}
		set_site_transient( 'update_themes', $tt );
	}

	// 4. Rediriger vers update-core.php — les transients sont déjà à jour,
	//    pas besoin de force-check (qui déclencherait un appel à api.wordpress.org).
	wp_redirect( admin_url( 'update-core.php' ) );
	exit;
} );
