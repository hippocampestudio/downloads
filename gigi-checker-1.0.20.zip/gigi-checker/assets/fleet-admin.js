/**
 * Admin flotte Gigi Checker — lignes dynamiques Nom + URL.
 */
(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	ready(function () {
		var form = document.getElementById('gigi-fleet-form');
		if (!form) {
			return;
		}

		var masterToggle = document.getElementById('gigi_is_master');
		var masterPanel = document.getElementById('gigi-fleet-master-panel');
		var tbody = document.getElementById('gigi-fleet-rows');
		var addBtn = document.getElementById('gigi-fleet-add');
		var addCurrentBtn = document.getElementById('gigi-fleet-add-current');
		var template = document.getElementById('gigi-fleet-row-template');

		function toggleMasterPanel() {
			if (!masterPanel || !masterToggle) {
				return;
			}
			masterPanel.hidden = !masterToggle.checked;
		}

		function reindexRows() {
			if (!tbody) {
				return;
			}
			Array.prototype.forEach.call(tbody.querySelectorAll('tr.gigi-fleet-row'), function (row, index) {
				row.querySelectorAll('[data-name]').forEach(function (input) {
					var field = input.getAttribute('data-name');
					input.name = 'gigi_fleet_sites[' + index + '][' + field + ']';
				});
			});
		}

		function refreshRoles() {
			if (!tbody) {
				return;
			}
			var current = (tbody.getAttribute('data-current-url') || '').toLowerCase();
			Array.prototype.forEach.call(tbody.querySelectorAll('tr.gigi-fleet-row'), function (row) {
				var urlInput = row.querySelector('[data-name="url"]');
				var role = row.querySelector('.gigi-fleet-role');
				if (!urlInput || !role) {
					return;
				}
				var url = (urlInput.value || '').replace(/\/+$/, '').toLowerCase();
				if (url && current && url === current) {
					role.innerHTML = '<span class="gigi-fleet-badge gigi-fleet-badge--master">Ce site</span>';
					row.classList.add('gigi-fleet-row--current');
				} else {
					role.innerHTML = '<span class="gigi-fleet-badge">Autre site</span>';
					row.classList.remove('gigi-fleet-row--current');
				}
			});
		}

		function bindRow(row) {
			var removeBtn = row.querySelector('.gigi-fleet-remove');
			if (removeBtn) {
				removeBtn.addEventListener('click', function () {
					var rows = tbody.querySelectorAll('tr.gigi-fleet-row');
					if (rows.length <= 1) {
						row.querySelectorAll('input[type="text"], input[type="url"]').forEach(function (input) {
							input.value = '';
						});
						refreshRoles();
						return;
					}
					row.remove();
					reindexRows();
					refreshRoles();
				});
			}
			var urlInput = row.querySelector('[data-name="url"]');
			if (urlInput) {
				urlInput.addEventListener('input', refreshRoles);
				urlInput.addEventListener('change', refreshRoles);
			}
		}

		function addRow(label, url) {
			if (!template || !tbody) {
				return;
			}
			var node = template.content.cloneNode(true);
			var row = node.querySelector('tr');
			var labelInput = row.querySelector('[data-name="label"]');
			var urlInput = row.querySelector('[data-name="url"]');
			if (labelInput) {
				labelInput.value = label || '';
			}
			if (urlInput) {
				urlInput.value = url || '';
			}
			tbody.appendChild(node);
			bindRow(tbody.lastElementChild);
			reindexRows();
			refreshRoles();
			if (labelInput) {
				tbody.lastElementChild.querySelector('[data-name="label"]').focus();
			}
		}

		if (masterToggle) {
			masterToggle.addEventListener('change', toggleMasterPanel);
			toggleMasterPanel();
		}

		if (tbody) {
			Array.prototype.forEach.call(tbody.querySelectorAll('tr.gigi-fleet-row'), bindRow);
			reindexRows();
			refreshRoles();
		}

		if (addBtn) {
			addBtn.addEventListener('click', function () {
				addRow('', '');
			});
		}

		if (addCurrentBtn && tbody) {
			addCurrentBtn.addEventListener('click', function () {
				var currentUrl = tbody.getAttribute('data-current-url') || '';
				var currentLabel = tbody.getAttribute('data-current-label') || '';
				if (!currentUrl) {
					return;
				}
				var exists = false;
				Array.prototype.forEach.call(tbody.querySelectorAll('[data-name="url"]'), function (input) {
					var value = (input.value || '').replace(/\/+$/, '').toLowerCase();
					if (value === currentUrl.toLowerCase()) {
						exists = true;
						input.focus();
					}
				});
				if (!exists) {
					addRow(currentLabel, currentUrl);
				}
			});
		}
	});
})();
