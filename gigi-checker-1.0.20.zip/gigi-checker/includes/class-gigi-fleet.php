<?php
/**
 * Gigi_Fleet — liste des sites Gigi + rôle maître / satellite.
 *
 * Le site maître stocke la liste complète et peut déclencher une sync
 * sur tous les satellites (même secret partagé).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Fleet {

	private const OPTION_IS_MASTER = 'gigi_checker_is_master';
	private const OPTION_SITES     = 'gigi_checker_fleet_sites';

	public static function is_master(): bool {
		return (bool) get_option( self::OPTION_IS_MASTER, false );
	}

	public static function set_is_master( bool $is_master ): void {
		update_option( self::OPTION_IS_MASTER, $is_master ? 1 : 0, false );
	}

	/**
	 * @return list<array{label: string, url: string}>
	 */
	public static function get_sites(): array {
		$sites = get_option( self::OPTION_SITES, [] );
		if ( ! is_array( $sites ) ) {
			return [];
		}

		$clean = [];
		foreach ( $sites as $site ) {
			if ( ! is_array( $site ) ) {
				continue;
			}
			$url = self::normalize_url( (string) ( $site['url'] ?? '' ) );
			if ( '' === $url ) {
				continue;
			}
			$clean[] = [
				'label' => sanitize_text_field( (string) ( $site['label'] ?? '' ) ) ?: self::label_from_url( $url ),
				'url'   => $url,
			];
		}

		return $clean;
	}

	/**
	 * @param list<array{label?: string, url?: string}>|string $sites Liste ou texte multiligne "Label | https://…"
	 */
	public static function save_sites( $sites ): void {
		if ( is_string( $sites ) ) {
			$sites = self::parse_sites_textarea( $sites );
		}

		$clean = [];
		$seen  = [];
		foreach ( (array) $sites as $site ) {
			$url = self::normalize_url( (string) ( $site['url'] ?? '' ) );
			if ( '' === $url || isset( $seen[ $url ] ) ) {
				continue;
			}
			$seen[ $url ] = true;
			$clean[]      = [
				'label' => sanitize_text_field( (string) ( $site['label'] ?? '' ) ) ?: self::label_from_url( $url ),
				'url'   => $url,
			];
		}

		update_option( self::OPTION_SITES, $clean, false );
	}

	public static function get_current_site_url(): string {
		return self::normalize_url( home_url( '/' ) );
	}

	/**
	 * Sites de la flotte hors le site courant (satellites à appeler).
	 *
	 * @return list<array{label: string, url: string}>
	 */
	public static function get_remote_sites(): array {
		$current = self::get_current_site_url();
		$remote  = [];
		foreach ( self::get_sites() as $site ) {
			if ( self::urls_match( $site['url'], $current ) ) {
				continue;
			}
			$remote[] = $site;
		}
		return $remote;
	}

	/**
	 * Déclenche /sync sur chaque satellite.
	 *
	 * @return list<array{label: string, url: string, ok: bool, http_code: int, body: mixed, error?: string}>
	 */
	public static function sync_all_remote(): array {
		$secret = get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		if ( ! is_string( $secret ) || '' === $secret ) {
			return [
				[
					'label'     => '',
					'url'       => '',
					'ok'        => false,
					'http_code' => 0,
					'body'      => null,
					'error'     => 'Secret de synchronisation vide — définissez-le d’abord.',
				],
			];
		}

		$results = [];
		foreach ( self::get_remote_sites() as $site ) {
			$results[] = self::sync_remote_site( $site['url'], $site['label'], $secret );
		}

		return $results;
	}

	/**
	 * @return array{label: string, url: string, ok: bool, http_code: int, body: mixed, error?: string}
	 */
	public static function sync_remote_site( string $url, string $label, string $secret ): array {
		$url      = self::normalize_url( $url );
		$endpoint = trailingslashit( $url ) . 'wp-json/gigi-checker/v1/sync';
		$result   = self::post_sync( $endpoint, $secret );

		// Fallback permaliens non jolis / staging.
		if ( ! $result['ok'] && ! in_array( $result['http_code'], [ 200, 401 ], true ) ) {
			$fallback = trailingslashit( $url ) . 'index.php?rest_route=/gigi-checker/v1/sync';
			$result   = self::post_sync( $fallback, $secret );
		}

		$result['label'] = $label;
		$result['url']   = $url;

		return $result;
	}

	/**
	 * @return array{ok: bool, http_code: int, body: mixed, error?: string}
	 */
	private static function post_sync( string $endpoint, string $secret ): array {
		$args = [
			'method'  => 'POST',
			'timeout' => 120,
			'headers' => [
				'X-Gigi-Sync-Secret' => $secret,
				'Content-Type'       => 'application/json',
			],
			'body'    => '{}',
		];

		// Staging o2switch (universe.wf) : certificat souvent invalide.
		if ( str_contains( $endpoint, 'universe.wf' ) ) {
			$args['sslverify'] = false;
		}

		$response = wp_remote_post( $endpoint, $args );

		if ( is_wp_error( $response ) ) {
			return [
				'ok'        => false,
				'http_code' => 0,
				'body'      => null,
				'error'     => $response->get_error_message(),
			];
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$body = json_decode( $raw, true );
		if ( null === $body ) {
			$body = $raw;
		}

		return [
			'ok'        => 200 === $code && is_array( $body ) && ! empty( $body['success'] ),
			'http_code' => $code,
			'body'      => $body,
		];
	}

	/**
	 * @return list<array{label: string, url: string}>
	 */
	public static function parse_sites_textarea( string $text ): array {
		$sites = [];
		foreach ( preg_split( '/\R/', $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}

			if ( str_contains( $line, '|' ) ) {
				[ $label, $url ] = array_map( 'trim', explode( '|', $line, 2 ) );
			} else {
				$url   = $line;
				$label = '';
			}

			$sites[] = [
				'label' => $label,
				'url'   => $url,
			];
		}

		return $sites;
	}

	public static function sites_to_textarea( array $sites ): string {
		$lines = [];
		foreach ( $sites as $site ) {
			$lines[] = $site['label'] . ' | ' . $site['url'];
		}
		return implode( "\n", $lines );
	}

	public static function default_sites(): array {
		return [
			[ 'label' => 'Gigi Événements', 'url' => 'https://www.gigi-evenements.fr' ],
			[ 'label' => 'FB Le Bar', 'url' => 'https://www.fb-lebar.fr' ],
			[ 'label' => 'La Guinguette Éphémère', 'url' => 'https://www.la-guinguette-ephemere.fr' ],
			[ 'label' => 'Foodtrucks Festival', 'url' => 'https://foodtrucks-festivalfr.sc1brfr7470.universe.wf' ],
		];
	}

	public static function default_sites_textarea(): string {
		return self::sites_to_textarea( self::default_sites() );
	}

	/**
	 * Sites à afficher dans le formulaire d’édition (enregistrés ou défauts).
	 *
	 * @return list<array{label: string, url: string}>
	 */
	public static function get_sites_for_editor(): array {
		$sites = self::get_sites();
		return $sites ?: self::default_sites();
	}

	public static function normalize_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}
		$url = esc_url_raw( $url );
		if ( ! $url ) {
			return '';
		}
		return untrailingslashit( $url );
	}

	public static function urls_match( string $a, string $b ): bool {
		$a = strtolower( self::normalize_url( $a ) );
		$b = strtolower( self::normalize_url( $b ) );
		return $a === $b;
	}

	private static function label_from_url( string $url ): string {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		return is_string( $host ) ? $host : $url;
	}
}
