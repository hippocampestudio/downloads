<?php
/**
 * Gigi_Status_Page — admin Gigi Checker (onglets, langage non technique).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	private const TABS = [
		'overview' => 'Vue d’ensemble',
		'sites'    => 'Sites',
		'layout'   => 'En-tête & pied de page',
		'settings' => 'Réglages',
	];

	public static function register(): void {
		add_management_page(
			'Gigi Checker',
			'Gigi Checker',
			'update_plugins',
			'gigi-checker-status',
			[ self::class, 'render' ]
		);

		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
	}

	public static function enqueue_assets( string $hook ): void {
		if ( 'tools_page_gigi-checker-status' !== $hook ) {
			return;
		}

		$base = plugin_dir_url( GIGI_CHECKER_FILE ) . 'assets/';
		wp_enqueue_style( 'gigi-fleet-admin', $base . 'fleet-admin.css', [], GIGI_CHECKER_VERSION );
		wp_enqueue_script( 'gigi-fleet-admin', $base . 'fleet-admin.js', [], GIGI_CHECKER_VERSION, true );
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		$tab                = self::current_tab();
		$fleet_sync_results = null;
		$notices            = [];

		self::handle_posts( $tab, $fleet_sync_results, $notices );

		$remote     = Gigi_Versions::fetch_remote();
		$last_error = Gigi_Versions::get_last_error();
		$versions   = self::collect_versions( $remote );
		$is_master  = Gigi_Fleet::is_master();
		$layout     = Gigi_Layout_Sync::get_status();
		$layout_local = 0;
		foreach ( $layout as $item ) {
			if ( ! empty( $item['customized'] ) ) {
				$layout_local++;
			}
		}

		echo '<div class="wrap gigi-admin">';
		echo '<h1>Gigi Checker</h1>';
		echo '<p class="gigi-admin-intro">Gérez les mises à jour du thème et des plugins Gigi, la liste des sites, et les éléments d’en-tête / pied de page partagés.</p>';

		foreach ( $notices as $notice ) {
			printf(
				'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
				esc_attr( $notice['type'] ),
				wp_kses_post( $notice['message'] )
			);
		}

		self::render_tabs( $tab );

		echo '<div class="gigi-admin-panel">';
		switch ( $tab ) {
			case 'sites':
				self::render_tab_sites( $fleet_sync_results );
				break;
			case 'layout':
				self::render_tab_layout( $layout );
				break;
			case 'settings':
				self::render_tab_settings( $remote, $last_error );
				break;
			default:
				self::render_tab_overview( $remote, $last_error, $versions, $is_master, $layout_local );
				break;
		}
		echo '</div>';
		echo '</div>';
	}

	private static function current_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		return isset( self::TABS[ $tab ] ) ? $tab : 'overview';
	}

	private static function tab_url( string $tab ): string {
		return add_query_arg(
			[
				'page' => 'gigi-checker-status',
				'tab'  => $tab,
			],
			admin_url( 'tools.php' )
		);
	}

	private static function render_tabs( string $current ): void {
		echo '<nav class="nav-tab-wrapper gigi-admin-tabs" aria-label="Sections Gigi Checker">';
		foreach ( self::TABS as $slug => $label ) {
			printf(
				'<a href="%s" class="nav-tab%s">%s</a>',
				esc_url( self::tab_url( $slug ) ),
				$current === $slug ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</nav>';
	}

	/**
	 * @param array|null $fleet_sync_results
	 * @param list<array{type: string, message: string}> $notices
	 */
	private static function handle_posts( string $tab, ?array &$fleet_sync_results, array &$notices ): void {
		if ( empty( $_POST['_wpnonce'] ) ) {
			return;
		}

		// Secret.
		if (
			isset( $_POST['gigi_sync_secret'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_sync_secret' )
		) {
			update_option(
				Gigi_Remote_Sync::get_secret_option_name(),
				sanitize_text_field( wp_unslash( $_POST['gigi_sync_secret'] ) )
			);
			$notices[] = [
				'type'    => 'success',
				'message' => 'Clé de synchronisation enregistrée. Utilisez la même clé sur tous les sites.',
			];
		}

		// Flotte.
		if (
			isset( $_POST['gigi_save_fleet'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_fleet' )
		) {
			$is_master = ! empty( $_POST['gigi_is_master'] );
			Gigi_Fleet::set_is_master( $is_master );
			if ( $is_master && isset( $_POST['gigi_fleet_sites'] ) && is_array( $_POST['gigi_fleet_sites'] ) ) {
				$sites = [];
				foreach ( wp_unslash( $_POST['gigi_fleet_sites'] ) as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$sites[] = [
						'label' => sanitize_text_field( (string) ( $row['label'] ?? '' ) ),
						'url'   => sanitize_text_field( (string) ( $row['url'] ?? '' ) ),
					];
				}
				Gigi_Fleet::save_sites( $sites );
			}
			$notices[] = [
				'type'    => 'success',
				'message' => 'Liste des sites enregistrée.',
			];
		}

		// Sync flotte.
		if (
			isset( $_POST['gigi_fleet_sync'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_fleet_sync' )
		) {
			if ( ! Gigi_Fleet::is_master() ) {
				$notices[] = [
					'type'    => 'error',
					'message' => 'Seul le site principal peut mettre à jour tous les sites.',
				];
			} else {
				$local_request      = new WP_REST_Request( 'POST', '/gigi-checker/v1/sync' );
				$local_response     = Gigi_Remote_Sync::sync_and_apply( $local_request );
				$fleet_sync_results = [
					'local'  => $local_response->get_data(),
					'remote' => Gigi_Fleet::sync_all_remote(),
				];
				$notices[] = [
					'type'    => 'success',
					'message' => 'Mise à jour de tous les sites terminée — voir le détail ci-dessous.',
				];
			}
		}

		// Layout local.
		if (
			isset( $_POST['gigi_layout_sync'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_sync' )
		) {
			$report = Gigi_Layout_Sync::sync_all();
			$reset  = count( $report['reset'] );
			$migrated = count( $report['migrated_nav_marques'] ?? [] );
			$parts = [];
			if ( $reset > 0 ) {
				$parts[] = sprintf(
					'%d élément(s) revenus à la version du thème (%s)',
					$reset,
					esc_html( implode( ', ', $report['reset'] ) )
				);
			}
			if ( $migrated > 0 ) {
				$titles = array_map(
					static fn( $row ) => $row['title'] ?? ( '#' . $row['id'] ),
					$report['migrated_nav_marques']
				);
				$parts[] = sprintf(
					'%d page(s) : Navigation Marques convertie en template part (%s)',
					$migrated,
					esc_html( implode( ', ', $titles ) )
				);
			}
			if ( $parts ) {
				$notices[] = [
					'type'    => 'success',
					'message' => 'Sur <strong>ce site</strong> : ' . implode( ' — ', $parts ) . '.',
				];
			} else {
				$notices[] = [
					'type'    => 'info',
					'message' => 'Rien à corriger sur ce site : layout et pages déjà à jour.',
				];
			}
		}

		// URL versions.
		if (
			isset( $_POST['gigi_versions_url'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_url' )
		) {
			Gigi_Versions::save_url( sanitize_url( trim( wp_unslash( $_POST['gigi_versions_url'] ) ) ) );
			Gigi_Versions::flush_cache();
			$notices[] = [
				'type'    => 'success',
				'message' => 'Source des versions enregistrée. Le cache a été vidé.',
			];
		}
	}

	/**
	 * @return list<array{slug: string, label: string, installed: string, available: string, status: string, color: string, outdated: bool}>
	 */
	private static function collect_versions( ?array $remote ): array {
		$slugs  = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];
		$labels = [
			'gigi-theme'   => 'Thème Gigi',
			'gigi-checker' => 'Gigi Checker',
			'gigi-blocks'  => 'Gigi Blocks',
		];
		$rows = [];

		foreach ( $slugs as $slug ) {
			$available = is_array( $remote ) ? ( $remote[ $slug ]['version'] ?? '—' ) : '—';

			if ( 'gigi-theme' === $slug ) {
				$theme     = wp_get_theme( $slug );
				$installed = $theme->exists() ? (string) $theme->get( 'Version' ) : 'Non installé';
			} else {
				$path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
				if ( file_exists( $path ) ) {
					if ( ! function_exists( 'get_plugin_data' ) ) {
						require_once ABSPATH . 'wp-admin/includes/plugin.php';
					}
					$data      = get_plugin_data( $path );
					$installed = (string) ( $data['Version'] ?? '?' );
				} else {
					$installed = 'Non installé';
				}
			}

			$outdated = false;
			if ( '—' === $available ) {
				$status = 'Info indisponible';
				$color  = 'orange';
			} elseif ( 'Non installé' === $installed ) {
				$status = 'Non installé';
				$color  = 'orange';
			} elseif ( version_compare( $installed, $available, '<' ) ) {
				$status   = 'Mise à jour disponible';
				$color    = '#0073aa';
				$outdated = true;
			} else {
				$status = 'À jour';
				$color  = 'green';
			}

			$rows[] = [
				'slug'      => $slug,
				'label'     => $labels[ $slug ],
				'installed' => $installed,
				'available' => $available,
				'status'    => $status,
				'color'     => $color,
				'outdated'  => $outdated,
			];
		}

		return $rows;
	}

	private static function render_tab_overview( ?array $remote, ?array $last_error, array $versions, bool $is_master, int $layout_local ): void {
		$outdated = array_filter( $versions, static fn( $row ) => ! empty( $row['outdated'] ) );
		$secret   = (string) get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		$fleet    = Gigi_Fleet::get_sites();

		echo '<div class="gigi-cards">';

		echo '<div class="gigi-card">';
		echo '<h2>Ce site</h2>';
		if ( $is_master ) {
			echo '<p><span class="gigi-fleet-badge gigi-fleet-badge--master">Site principal</span></p>';
			echo '<p>Vous pouvez gérer la liste des sites et lancer une mise à jour sur toute la flotte.</p>';
		} else {
			echo '<p><span class="gigi-fleet-badge">Site secondaire</span></p>';
			echo '<p>Les mises à jour groupées se lancent depuis le site principal. Ici, vous gérez surtout ce site.</p>';
		}
		printf(
			'<p><a class="button" href="%s">Gérer les sites</a></p>',
			esc_url( self::tab_url( 'sites' ) )
		);
		echo '</div>';

		echo '<div class="gigi-card">';
		echo '<h2>Mises à jour</h2>';
		if ( empty( $remote ) ) {
			echo '<p class="gigi-status-bad">Impossible de vérifier les versions en ligne pour le moment.</p>';
		} elseif ( $outdated ) {
			printf(
				'<p class="gigi-status-warn"><strong>%d</strong> composant(s) à mettre à jour.</p>',
				count( $outdated )
			);
		} else {
			echo '<p class="gigi-status-ok"><strong>Tout est à jour</strong> sur ce site.</p>';
		}

		echo '<table class="widefat striped gigi-compact-table"><thead><tr><th>Composant</th><th>Installé</th><th>État</th></tr></thead><tbody>';
		foreach ( $versions as $row ) {
			printf(
				'<tr><td>%s</td><td>%s</td><td style="color:%s">%s</td></tr>',
				esc_html( $row['label'] ),
				esc_html( $row['installed'] ),
				esc_attr( $row['color'] ),
				esc_html( $row['status'] )
			);
		}
		echo '</tbody></table>';

		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf(
			'<p style="margin-top:12px"><a class="button button-primary" href="%s">Vérifier les mises à jour maintenant</a></p>',
			esc_url( $flush_url )
		);
		if ( $is_master && count( $fleet ) > 1 && $secret !== '' ) {
			printf(
				'<p><a class="button" href="%s">Mettre à jour tous les sites…</a></p>',
				esc_url( self::tab_url( 'sites' ) )
			);
		}
		echo '</div>';

		echo '<div class="gigi-card">';
		echo '<h2>En-tête & pied de page</h2>';
		if ( $layout_local > 0 ) {
			printf(
				'<p class="gigi-status-warn">Sur <strong>ce site</strong>, <strong>%d</strong> élément(s) ont été modifiés dans l’éditeur et ne suivent plus le thème commun.</p>',
				$layout_local
			);
		} else {
			echo '<p class="gigi-status-ok">Sur ce site, l’en-tête et le pied de page utilisent la version du thème.</p>';
		}
		printf(
			'<p><a class="button" href="%s">Voir le détail</a></p>',
			esc_url( self::tab_url( 'layout' ) )
		);
		echo '</div>';

		echo '</div>'; // .gigi-cards

		if ( $secret === '' ) {
			echo '<div class="notice notice-warning inline"><p>';
			echo 'Pour pouvoir mettre à jour les autres sites depuis le site principal, définissez une <strong>clé de synchronisation</strong> identique partout. ';
			printf( '<a href="%s">Configurer</a>', esc_url( self::tab_url( 'sites' ) ) );
			echo '</p></div>';
		}

		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			echo 'La vérification des versions en ligne a échoué. ';
			printf( '<a href="%s">Voir les réglages</a>', esc_url( self::tab_url( 'settings' ) ) );
			echo '</p></div>';
		}
	}

	private static function render_tab_sites( ?array $fleet_sync_results ): void {
		$is_master     = Gigi_Fleet::is_master();
		$fleet_sites   = Gigi_Fleet::get_sites();
		$editor_sites  = Gigi_Fleet::get_sites_for_editor();
		$current_url   = Gigi_Fleet::get_current_site_url();
		$current_label = wp_parse_url( home_url(), PHP_URL_HOST );
		$current_label = is_string( $current_label ) ? $current_label : 'Ce site';
		$sync_secret   = (string) get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );

		echo '<h2>Clé de synchronisation</h2>';
		echo '<p>Mot de passe partagé entre tous les sites. Il permet au site principal de leur demander une mise à jour. '
			. '<strong>Même valeur partout</strong> (site principal et sites secondaires).</p>';
		echo '<form method="post" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
		wp_nonce_field( 'gigi_save_sync_secret' );
		echo '<input type="password" name="gigi_sync_secret" value="' . esc_attr( $sync_secret ) . '" class="regular-text" style="width:280px" placeholder="Clé partagée" autocomplete="new-password"> ';
		echo '<button type="submit" class="button button-primary">Enregistrer la clé</button>';
		echo '</form>';

		echo '<h2 style="margin-top:2em">Liste des sites</h2>';
		echo '<div class="gigi-fleet-box">';
		echo '<p>Le <strong>site principal</strong> détient la liste et peut tout mettre à jour d’un clic. '
			. 'Les autres sites n’ont besoin que de la clé ci-dessus.</p>';

		echo '<form method="post" id="gigi-fleet-form" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
		wp_nonce_field( 'gigi_save_fleet' );
		echo '<input type="hidden" name="gigi_save_fleet" value="1">';

		echo '<label class="gigi-fleet-master-toggle">';
		echo '<input type="checkbox" name="gigi_is_master" id="gigi_is_master" value="1"' . checked( $is_master, true, false ) . '>';
		echo '<span><strong>Ce site est le site principal</strong>';
		echo '<span class="description">À cocher sur un seul site (souvent gigi-evenements.fr).</span></span>';
		echo '</label>';

		printf( '<div id="gigi-fleet-master-panel"%s>', $is_master ? '' : ' hidden' );

		echo '<table class="widefat striped gigi-fleet-table"><thead><tr>';
		echo '<th class="gigi-fleet-col-label">Nom</th>';
		echo '<th class="gigi-fleet-col-url">Adresse du site</th>';
		echo '<th class="gigi-fleet-col-role">Rôle</th>';
		echo '<th class="gigi-fleet-col-actions"><span class="screen-reader-text">Actions</span></th>';
		echo '</tr></thead>';
		printf(
			'<tbody id="gigi-fleet-rows" data-current-url="%s" data-current-label="%s">',
			esc_attr( $current_url ),
			esc_attr( $current_label )
		);

		foreach ( $editor_sites as $i => $site ) {
			$is_current = Gigi_Fleet::urls_match( $site['url'], $current_url );
			printf( '<tr class="gigi-fleet-row%s">', $is_current ? ' gigi-fleet-row--current' : '' );
			printf(
				'<td><input type="text" class="regular-text" data-name="label" name="gigi_fleet_sites[%d][label]" value="%s" placeholder="Ex. Gigi Événements"></td>',
				(int) $i,
				esc_attr( $site['label'] )
			);
			printf(
				'<td><input type="url" class="regular-text" data-name="url" name="gigi_fleet_sites[%d][url]" value="%s" placeholder="https://www.exemple.fr"></td>',
				(int) $i,
				esc_attr( $site['url'] )
			);
			echo '<td class="gigi-fleet-role">';
			echo $is_current
				? '<span class="gigi-fleet-badge gigi-fleet-badge--master">Ce site</span>'
				: '<span class="gigi-fleet-badge">Autre site</span>';
			echo '</td>';
			echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<div class="gigi-fleet-actions">';
		echo '<button type="button" class="button" id="gigi-fleet-add">+ Ajouter un site</button>';
		echo '<button type="button" class="button" id="gigi-fleet-add-current">Ajouter ce site</button>';
		echo '</div>';
		echo '<p class="description">Incluez ce site dans la liste. Son adresse doit correspondre exactement à l’URL WordPress (avec ou sans www).</p>';
		echo '</div>';

		if ( ! $is_master ) {
			echo '<p class="gigi-fleet-satellite-note">Ce site est un <strong>site secondaire</strong>. La liste se configure sur le site principal.</p>';
		}

		echo '<div class="gigi-fleet-save-row"><button type="submit" class="button button-primary">Enregistrer</button></div>';
		echo '</form>';

		echo '<template id="gigi-fleet-row-template">';
		echo '<tr class="gigi-fleet-row">';
		echo '<td><input type="text" class="regular-text" data-name="label" value="" placeholder="Ex. Gigi Événements"></td>';
		echo '<td><input type="url" class="regular-text" data-name="url" value="" placeholder="https://www.exemple.fr"></td>';
		echo '<td class="gigi-fleet-role"><span class="gigi-fleet-badge">Autre site</span></td>';
		echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
		echo '</tr></template>';
		echo '</div>';

		if ( $is_master ) {
			echo '<h2>Mettre à jour tous les sites</h2>';
			if ( '' === $sync_secret ) {
				echo '<div class="notice notice-warning inline"><p>Enregistrez d’abord une clé de synchronisation (en haut de cette page), sur <strong>tous</strong> les sites.</p></div>';
			} elseif ( empty( $fleet_sites ) ) {
				echo '<div class="notice notice-warning inline"><p>Enregistrez d’abord la liste des sites.</p></div>';
			} else {
				$remote_count = count( Gigi_Fleet::get_remote_sites() );
				echo '<p>Installe les mises à jour Gigi sur <strong>ce site</strong>, puis sur chaque autre site de la liste.</p>';
				echo '<form method="post" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
				wp_nonce_field( 'gigi_fleet_sync' );
				echo '<input type="hidden" name="gigi_fleet_sync" value="1">';
				printf(
					'<button type="submit" class="button button-primary button-hero">Mettre à jour toute la flotte (%d autre%s site%s)</button>',
					$remote_count,
					1 === $remote_count ? '' : 's',
					1 === $remote_count ? '' : 's'
				);
				echo '</form>';
			}
		}

		if ( is_array( $fleet_sync_results ) ) {
			echo '<h3>Résultat</h3>';
			$local = $fleet_sync_results['local'] ?? [];
			printf(
				'<p><strong>Ce site :</strong> %s</p>',
				esc_html( is_array( $local ) ? (string) ( $local['message'] ?? '' ) : '' )
			);
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Site</th><th>Résultat</th></tr></thead><tbody>';
			foreach ( $fleet_sync_results['remote'] ?? [] as $row ) {
				if ( ! empty( $row['error'] ) && '' === ( $row['url'] ?? '' ) ) {
					printf( '<tr><td colspan="2" style="color:#d63638">%s</td></tr>', esc_html( $row['error'] ) );
					continue;
				}
				$ok  = ! empty( $row['ok'] );
				$msg = $row['error'] ?? '';
				if ( ! $msg && is_array( $row['body'] ?? null ) ) {
					$msg = (string) ( $row['body']['message'] ?? '' );
				} elseif ( ! $msg && is_string( $row['body'] ?? null ) ) {
					$msg = $row['body'];
				}
				printf(
					'<tr><td><strong>%s</strong><br><small>%s</small></td><td style="color:%s">%s %s</td></tr>',
					esc_html( $row['label'] ?? '' ),
					esc_html( $row['url'] ?? '' ),
					$ok ? 'green' : '#d63638',
					$ok ? 'OK' : 'Échec',
					esc_html( (string) $msg )
				);
			}
			echo '</tbody></table>';
		}
	}

	private static function render_tab_layout( array $layout ): void {
		echo '<h2>En-tête, pied de page et navigation</h2>';
		echo '<p>Ces éléments sont fournis par le thème Gigi. L’idéal est de les laisser tels quels pour qu’une mise à jour du thème les mette à jour partout.</p>';
		echo '<div class="gigi-callout">';
		echo '<p><strong>Que se passe-t-il si on les modifie dans Apparence → Éditeur ?</strong></p>';
		echo '<p>WordPress garde une copie <em>uniquement sur ce site</em>. Cette copie bloque alors les prochaines mises à jour du thème pour cet élément.</p>';
		echo '<p>Le tableau indique si <strong>ce site</strong> utilise encore la version du thème, ou une copie locale. '
			. 'Ce n’est pas une comparaison en direct avec les autres sites.</p>';
		echo '</div>';

		if ( empty( $layout ) ) {
			echo '<p><em>Liste indisponible — mettez à jour le thème et Gigi Checker.</em></p>';
			return;
		}

		echo '<table class="widefat striped" style="max-width:900px">';
		echo '<thead><tr><th>Élément</th><th>Sur ce site</th><th>État</th></tr></thead><tbody>';
		foreach ( $layout as $item ) {
			if ( ! empty( $item['customized'] ) ) {
				$source = 'Copie locale (modifié dans l’éditeur)';
				$state  = 'Ne suivra plus les mises à jour du thème';
				$color  = '#d63638';
			} else {
				$source = 'Version du thème';
				$state  = 'OK — suivra les prochaines mises à jour';
				$color  = 'green';
			}
			printf(
				'<tr><td><strong>%s</strong></td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
				esc_html( $item['label'] ),
				esc_html( $source ),
				esc_attr( $color ),
				esc_html( $state )
			);
		}
		echo '</tbody></table>';

		echo '<form method="post" action="' . esc_url( self::tab_url( 'layout' ) ) . '" style="margin-top:1em">';
		wp_nonce_field( 'gigi_layout_sync' );
		echo '<input type="hidden" name="gigi_layout_sync" value="1">';
		echo '<button type="submit" class="button button-primary">Revenir à la version du thème sur ce site</button>';
		echo '<p class="description">Efface les copies locales des parties de modèle <strong>uniquement sur ce site</strong>, et convertit les anciennes Navigation Marques (blocs copiés dans les pages) en référence au template part.</p>';
		echo '</form>';

		$copies = Gigi_Layout_Sync::count_navigation_marques_copies();
		if ( $copies > 0 ) {
			printf(
				'<div class="notice notice-warning inline" style="margin-top:1em"><p><strong>%d</strong> page(s) utilisent encore l’ancienne Navigation Marques (copie figée). Le bouton ci-dessus les convertit pour qu’elles suivent le template part.</p></div>',
				$copies
			);
		}
	}

	private static function render_tab_settings( ?array $remote, ?array $last_error ): void {
		$current_url = Gigi_Versions::get_url();

		echo '<h2>Source des versions</h2>';
		echo '<p>Adresse utilisée pour savoir quelles versions du thème et des plugins sont disponibles. En général, laissez la valeur par défaut.</p>';

		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			printf( 'Dernière erreur : %s', esc_html( $last_error['message'] ) );
			echo '</p></div>';
		} elseif ( ! empty( $remote ) ) {
			echo '<div class="notice notice-success inline"><p>Connexion à la source des versions : OK.</p></div>';
		}

		echo '<form method="post" action="' . esc_url( self::tab_url( 'settings' ) ) . '">';
		wp_nonce_field( 'gigi_save_url' );
		printf(
			'<input type="url" name="gigi_versions_url" value="%s" class="regular-text" style="width:100%%;max-width:560px">',
			esc_attr( $current_url )
		);
		echo ' <button type="submit" class="button button-primary">Enregistrer</button>';
		echo '</form>';
		echo '<p class="description">Défaut : Bitbucket, avec secours GitHub. Évitez une URL jsDelivr pour ce fichier (cache trop long).</p>';

		echo '<h2 style="margin-top:2em">Diagnostic (avancé)</h2>';
		echo '<p class="description">Réservé au dépannage. Utile si une mise à jour ne s’affiche pas.</p>';

		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Type</th><th>Info Gigi</th><th>Dernière vérif.</th></tr></thead><tbody>';

		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'MAJ → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'À jour → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = 'Absent du cache';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i', $t_plugins->last_checked ) : '—';
			printf(
				'<tr><td>Plugin %s</td><td>%s</td><td>%s</td></tr>',
				esc_html( $slug_short ),
				esc_html( $info ),
				esc_html( $last )
			);
		}

		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'MAJ → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'À jour → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = 'Absent du cache';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i', $t_themes->last_checked ) : '—';
		printf( '<tr><td>Thème</td><td>%s</td><td>%s</td></tr>', esc_html( $t_info ), esc_html( $last_t ) );
		echo '</tbody></table>';

		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf(
			'<p style="margin-top:1em"><a class="button" href="%s">Vider le cache et revérifier</a></p>',
			esc_url( $flush_url )
		);
	}
}
