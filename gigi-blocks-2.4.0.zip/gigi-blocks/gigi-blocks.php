<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     2.4.0
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '2.4.0' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/* ================================================================
   1. Block registration
   ================================================================ */

add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}
	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/* ================================================================
   2. Slider — frontend assets
   ================================================================ */

add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}
	wp_enqueue_style( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.css', [], GIGI_BLOCKS_VERSION );
	wp_enqueue_script( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.js', [], GIGI_BLOCKS_VERSION, true );
	return $content;
}, 10, 2 );

/* ================================================================
   3. Block category
   ================================================================ */

add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
