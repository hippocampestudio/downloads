( function () {
	const header = document.querySelector( '.gigi-header-sticky' );
	const sentinel = document.querySelector( '.gigi-header-sentinel' );

	if ( ! header || ! sentinel || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}

	const observer = new IntersectionObserver(
		( [ entry ] ) => {
			header.classList.toggle( 'is-stuck', ! entry.isIntersecting );
		},
		{ threshold: 0 }
	);

	observer.observe( sentinel );
} )();
