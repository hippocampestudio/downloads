<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     1.6.0
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '1.6.0' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Enregistre tous les blocs présents dans le dossier build/.
 * Le bloc gigi/strate est enregistré comme bloc dynamique (render_callback)
 * pour garantir que le HTML frontend est toujours généré côté serveur
 * avec toutes les CSS custom properties.
 */
add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';

	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}

	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		$metadata = json_decode( file_get_contents( $block_json ), true );
		$args     = [];

		if ( ( $metadata['name'] ?? '' ) === 'gigi/strate' ) {
			$args['render_callback'] = 'gigi_strate_render_callback';
		}

		register_block_type( dirname( $block_json ), $args );
	}
} );

/**
 * Render callback for the Strate block.
 *
 * Generates the frontend HTML entirely from PHP so that CSS custom
 * properties are always present regardless of the saved HTML.
 */
function gigi_strate_render_callback( array $attributes, string $content, WP_Block $block ): string {
	$title           = $attributes['title'] ?? '';
	$text            = $attributes['text'] ?? '';
	$buttons         = $attributes['buttons'] ?? [];
	$media_url       = $attributes['mediaUrl'] ?? '';
	$media_alt       = $attributes['mediaAlt'] ?? '';
	$layout_reversed = ! empty( $attributes['layoutReversed'] );

	/* ── CSS classes ── */
	$classes = [ 'gigi-strate' ];
	if ( $layout_reversed ) {
		$classes[] = 'gigi-strate--reversed';
	}

	/* ── CSS custom properties ── */
	$vars = [];

	$media_width = (int) ( $attributes['mediaWidth'] ?? 50 );
	if ( $media_width !== 50 ) {
		$vars[] = "--gigi-strate-media-width:{$media_width}%";
	}

	$pos_x = (int) ( $attributes['imagePositionX'] ?? 50 );
	$pos_y = (int) ( $attributes['imagePositionY'] ?? 50 );
	if ( $pos_x !== 50 || $pos_y !== 50 ) {
		$vars[] = "--gigi-strate-img-pos:{$pos_x}% {$pos_y}%";
	}

	$zoom = (int) ( $attributes['imageZoom'] ?? 100 );
	if ( $zoom !== 100 ) {
		$scale  = round( $zoom / 100, 2 );
		$vars[] = "--gigi-strate-img-zoom:{$scale}";
	}

	$gap = (int) ( $attributes['columnsGap'] ?? 0 );
	if ( $gap > 0 ) {
		$vars[] = "--gigi-strate-gap:{$gap}px";
	}

	$color_map = [
		'buttonBgColor'      => 'btn-bg',
		'buttonTextColor'    => 'btn-color',
		'buttonHoverBgColor' => 'btn-hover-bg',
	];
	foreach ( $color_map as $attr => $var ) {
		if ( ! empty( $attributes[ $attr ] ) ) {
			$vars[] = "--gigi-strate-{$var}:{$attributes[ $attr ]}";
		}
	}

	$font_map = [
		'titleFontSize'  => 'title-size',
		'textFontSize'   => 'text-size',
		'buttonFontSize' => 'btn-size',
	];
	foreach ( $font_map as $attr => $var ) {
		if ( ! empty( $attributes[ $attr ] ) ) {
			$val = $attributes[ $attr ];
			if ( preg_match( '/^[a-z-]+$/i', $val ) ) {
				$val = "var(--wp--preset--font-size--{$val})";
			}
			$vars[] = "--gigi-strate-{$var}:{$val}";
		}
	}

	/* Redirect padding from wrapper to content column */
	$padding     = $attributes['style']['spacing']['padding'] ?? [];
	$has_padding = false;
	if ( ! empty( $padding ) ) {
		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $dir ) {
			if ( empty( $padding[ $dir ] ) ) {
				continue;
			}
			$val = $padding[ $dir ];
			if ( str_starts_with( $val, 'var:' ) ) {
				$parts = explode( '|', substr( $val, 4 ) );
				$val   = 'var(--wp--preset--' . implode( '--', $parts ) . ')';
			}
			$vars[]      = "--gigi-strate-pad-{$dir}:{$val}";
			$has_padding = true;
		}
		if ( $has_padding ) {
			$vars[] = 'padding:0 !important';
		}
	}

	$style_str    = implode( ';', $vars );
	$wrapper_attrs = get_block_wrapper_attributes( [
		'class' => implode( ' ', $classes ),
		'style' => $style_str,
	] );

	/* ── Build HTML ── */
	$html        = '<div ' . $wrapper_attrs . '>';
	$has_content = $title || $text || ! empty( $buttons );

	if ( $has_content ) {
		$html .= '<div class="gigi-strate__content">';

		if ( $title ) {
			$html .= '<h2 class="gigi-strate__title">' . wp_kses_post( $title ) . '</h2>';
		}
		if ( $text ) {
			$html .= '<p class="gigi-strate__text">' . wp_kses_post( $text ) . '</p>';
		}
		if ( ! empty( $buttons ) ) {
			$html .= '<div class="gigi-strate__buttons">';
			foreach ( $buttons as $btn ) {
				$btn_text = esc_html( $btn['text'] ?? '' );
				$btn_url  = esc_url( $btn['url'] ?? '#' );
				$html    .= '<a href="' . $btn_url . '" class="gigi-strate__button">' . $btn_text . '</a>';
			}
			$html .= '</div>';
		}

		$html .= '</div>';
	}

	if ( $media_url ) {
		$html .= '<div class="gigi-strate__media">';
		$html .= '<img src="' . esc_url( $media_url ) . '" alt="' . esc_attr( $media_alt ) . '" />';
		$html .= '</div>';
	}

	$html .= '</div>';

	return $html;
}

/**
 * Charge les assets frontend du slider à la première occurrence du bloc rendu.
 * render_block est plus fiable que wp_enqueue_scripts + has_block() :
 * il détecte le bloc même dans les template parts (header, footer).
 */
add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}

	wp_enqueue_style(
		'gigi-slider',
		GIGI_BLOCKS_URL . 'assets/slider.css',
		[],
		GIGI_BLOCKS_VERSION
	);
	wp_enqueue_script(
		'gigi-slider',
		GIGI_BLOCKS_URL . 'assets/slider.js',
		[],
		GIGI_BLOCKS_VERSION,
		true
	);

	return $content;
}, 10, 2 );

/**
 * Catégorie de blocs personnalisée "Gigi" dans l'éditeur.
 */
add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
