import { __ } from '@wordpress/i18n';
import { useBlockProps, InnerBlocks } from '@wordpress/block-editor';
import { useSelect } from '@wordpress/data';
import { useState, useEffect } from '@wordpress/element';

const TEMPLATE = [
	[ 'gigi/slide' ],
	[ 'gigi/slide' ],
];

export default function SliderEdit( { clientId } ) {
	const blockProps = useBlockProps( {
		className: 'gigi-slider gigi-slider--editor',
	} );

	const slideCount = useSelect(
		( select ) => {
			const block = select( 'core/block-editor' ).getBlock( clientId );
			return block?.innerBlocks?.length ?? 0;
		},
		[ clientId ]
	);

	const [ currentIndex, setCurrentIndex ] = useState( 0 );

	useEffect( () => {
		if ( currentIndex >= slideCount && slideCount > 0 ) {
			setCurrentIndex( Math.max( 0, slideCount - 1 ) );
		}
	}, [ slideCount, currentIndex ] );

	const trackStyle = {
		transform: `translateX(-${ currentIndex * 100 }%)`,
	};

	const goPrev = () => setCurrentIndex( ( i ) => Math.max( 0, i - 1 ) );
	const goNext = () => setCurrentIndex( ( i ) => Math.min( slideCount - 1, i + 1 ) );

	return (
		<div { ...blockProps }>
			<button
				type="button"
				className="gigi-slider__arrow gigi-slider__arrow--prev"
				onClick={ goPrev }
				disabled={ currentIndex <= 0 }
				aria-label={ __( 'Slide précédent', 'gigi-blocks' ) }
			>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M15 18l-6-6 6-6" /></svg>
			</button>
			<div className="gigi-slider__viewport">
				<div className="gigi-slider__track" style={ trackStyle }>
					<InnerBlocks
						allowedBlocks={ [ 'gigi/slide' ] }
						template={ TEMPLATE }
						templateLock={ false }
						renderAppender={ InnerBlocks.ButtonBlockAppender }
					/>
				</div>
			</div>
			<button
				type="button"
				className="gigi-slider__arrow gigi-slider__arrow--next"
				onClick={ goNext }
				disabled={ currentIndex >= slideCount - 1 || slideCount === 0 }
				aria-label={ __( 'Slide suivant', 'gigi-blocks' ) }
			>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M9 18l6-6-6-6" /></svg>
			</button>
		</div>
	);
}
