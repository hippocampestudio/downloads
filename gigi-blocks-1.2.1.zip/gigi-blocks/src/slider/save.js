import { __ } from '@wordpress/i18n';
import { useBlockProps, InnerBlocks } from '@wordpress/block-editor';

export default function SliderSave() {
	const blockProps = useBlockProps.save( {
		className: 'gigi-slider',
		'data-gigi-slider': '',
	} );

	return (
		<div { ...blockProps }>
			<button
				type="button"
				className="gigi-slider__arrow gigi-slider__arrow--prev"
				aria-label={ __( 'Slide précédent', 'gigi-blocks' ) }
			>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M15 18l-6-6 6-6" /></svg>
			</button>
			<div className="gigi-slider__viewport">
				<div className="gigi-slider__track">
					<InnerBlocks.Content />
				</div>
			</div>
			<button
				type="button"
				className="gigi-slider__arrow gigi-slider__arrow--next"
				aria-label={ __( 'Slide suivant', 'gigi-blocks' ) }
			>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M9 18l6-6-6-6" /></svg>
			</button>
		</div>
	);
}
