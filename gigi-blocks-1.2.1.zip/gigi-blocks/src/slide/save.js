import { useBlockProps, InnerBlocks } from '@wordpress/block-editor';

export default function SlideSave() {
	const blockProps = useBlockProps.save( {
		className: 'gigi-slide',
	} );

	return (
		<div { ...blockProps }>
			<div className="gigi-slide__inner">
				<InnerBlocks.Content />
			</div>
		</div>
	);
}
