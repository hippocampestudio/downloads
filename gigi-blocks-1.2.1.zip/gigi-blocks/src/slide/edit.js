import { useBlockProps, InnerBlocks } from '@wordpress/block-editor';

export default function SlideEdit() {
	const blockProps = useBlockProps( {
		className: 'gigi-slide',
	} );

	return (
		<div { ...blockProps }>
			<div className="gigi-slide__inner">
				<InnerBlocks
					allowedBlocks={ undefined }
					templateLock={ false }
					renderAppender={ InnerBlocks.ButtonBlockAppender }
				/>
			</div>
		</div>
	);
}
