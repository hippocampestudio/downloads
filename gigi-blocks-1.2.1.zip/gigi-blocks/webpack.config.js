const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );
const path = require( 'path' );
const glob = require( 'glob' );

/**
 * Génère automatiquement les entry points pour chaque bloc dans src/.
 * Chaque bloc doit avoir un fichier index.js à la racine de son dossier.
 */
const blockEntries = glob
	.sync( './src/*/index.js' )
	.reduce( ( acc, filePath ) => {
		const blockName = path.dirname( filePath ).split( '/' ).pop();
		acc[ blockName + '/index' ] = path.resolve( filePath );
		return acc;
	}, {} );

module.exports = {
	...defaultConfig,
	entry: blockEntries,
	output: {
		...defaultConfig.output,
		path: path.resolve( __dirname, 'build' ),
	},
};
