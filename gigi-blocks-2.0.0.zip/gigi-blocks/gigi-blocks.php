<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     2.0.0
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '2.0.0' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/* ================================================================
   1. Block registration
   ================================================================ */

add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}
	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/* ================================================================
   2. Strate — frontend post-processing
   ================================================================ */

add_filter( 'render_block', 'gigi_strate_filter_frontend', 20, 2 );

function gigi_strate_filter_frontend( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/strate' ) {
		return $content;
	}

	$attrs = $block['attrs'] ?? [];

	$p = new WP_HTML_Tag_Processor( $content );
	if ( ! $p->next_tag( 'div' ) ) {
		return $content;
	}

	// A) Inject non-padding CSS custom properties into wrapper inline style.
	$css_vars = gigi_strate_build_css_vars( $attrs );
	if ( $css_vars ) {
		$existing = $p->get_attribute( 'style' ) ?? '';
		$p->set_attribute( 'style', $css_vars . ( $existing ? ';' . $existing : '' ) );
	}

	// B) Padding redirect via scoped <style> tag.
	//    This is far more reliable than inline-style manipulation because
	//    WordPress 6.4+ can express preset spacing values in a separate
	//    <style> tag that inline !important alone cannot always override.
	$padding = $attrs['style']['spacing']['padding'] ?? [];
	$scoped_css = '';

	if ( ! empty( $padding ) ) {
		static $uid_counter = 0;
		$uid = 'gs-' . ( ++$uid_counter ) . '-' . wp_unique_id();
		$p->set_attribute( 'id', $uid );

		$scoped_css .= "#{$uid}{padding:0 !important}";
		$content_rules = '';

		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $dir ) {
			if ( ! isset( $padding[ $dir ] ) || $padding[ $dir ] === '' ) {
				continue;
			}
			$val = $padding[ $dir ];
			if ( str_starts_with( $val, 'var:' ) ) {
				$parts = explode( '|', substr( $val, 4 ) );
				$val   = 'var(--wp--preset--' . implode( '--', $parts ) . ')';
			}
			$content_rules .= "padding-{$dir}:{$val} !important;";
		}

		if ( $content_rules ) {
			$scoped_css .= "#{$uid}>.gigi-strate__content{{$content_rules}}";
		}
	}

	$html = $p->get_updated_html();

	if ( $scoped_css ) {
		$html = "<style>{$scoped_css}</style>" . $html;
	}

	return $html;
}

/* ================================================================
   3. Strate helpers
   ================================================================ */

function gigi_strate_build_css_vars( array $attrs ): string {
	$vars = [];

	$w = (int) ( $attrs['mediaWidth'] ?? 50 );
	if ( $w !== 50 ) {
		$vars[] = "--gigi-strate-media-width:{$w}%";
	}

	$gap = (int) ( $attrs['columnsGap'] ?? 0 );
	if ( $gap > 0 ) {
		$vars[] = "--gigi-strate-gap:{$gap}px";
	}

	$px = (int) ( $attrs['imagePositionX'] ?? 50 );
	$py = (int) ( $attrs['imagePositionY'] ?? 50 );
	if ( $px !== 50 || $py !== 50 ) {
		$vars[] = "--gigi-strate-img-pos:{$px}% {$py}%";
	}

	$zoom = (int) ( $attrs['imageZoom'] ?? 100 );
	if ( $zoom !== 100 ) {
		$vars[] = '--gigi-strate-img-zoom:' . round( $zoom / 100, 2 );
	}

	// Legacy global button colors (backward compat for pre-2.0 blocks).
	$colors = [
		'buttonBgColor'      => 'btn-bg',
		'buttonTextColor'    => 'btn-color',
		'buttonHoverBgColor' => 'btn-hover-bg',
	];
	foreach ( $colors as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$vars[] = "--gigi-strate-{$css}:{$attrs[ $attr ]}";
		}
	}

	// Legacy global typography.
	$fonts = [
		'titleFontSize'  => 'title-size',
		'textFontSize'   => 'text-size',
		'buttonFontSize' => 'btn-size',
	];
	foreach ( $fonts as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$val = $attrs[ $attr ];
			if ( preg_match( '/^[a-z-]+$/i', $val ) ) {
				$val = "var(--wp--preset--font-size--{$val})";
			}
			$vars[] = "--gigi-strate-{$css}:{$val}";
		}
	}

	return implode( ';', $vars );
}

/* ================================================================
   4. Slider — frontend assets
   ================================================================ */

add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}
	wp_enqueue_style( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.css', [], GIGI_BLOCKS_VERSION );
	wp_enqueue_script( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.js', [], GIGI_BLOCKS_VERSION, true );
	return $content;
}, 10, 2 );

/* ================================================================
   5. Block category
   ================================================================ */

add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
