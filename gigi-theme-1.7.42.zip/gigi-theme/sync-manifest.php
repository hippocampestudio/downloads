<?php
/**
 * Manifeste des composants de layout synchronisés depuis les fichiers du thème.
 *
 * Après chaque MAJ du thème, Gigi Checker supprime les surcharges en base de données
 * (wp_template_part) pour que le fichier dans parts/ reprenne le dessus.
 *
 * Éditer le markup dans gigi-theme/parts/{slug}.html — pas via l’éditeur de site
 * si la modification doit se propager à tous les sites.
 */

defined( 'ABSPATH' ) || exit;

return [
	'template_parts' => [
		'header-multisite' => [
			'label' => 'En-tête multisite',
			'sync'  => true,
			'layer' => 'layout',
		],
		'footer-multisite' => [
			'label' => 'Pied de page multisite',
			'sync'  => true,
			'layer' => 'layout',
		],
		'navigation-mobile' => [
			'label' => 'Navigation mobile',
			'sync'  => true,
			'layer' => 'layout',
		],
		'header-protected' => [
			'label' => 'En-tête pages protégées',
			'sync'  => true,
			'layer' => 'layout',
		],
		'footer-protected' => [
			'label' => 'Pied de page pages protégées',
			'sync'  => true,
			'layer' => 'layout',
		],
		'password-protected' => [
			'label' => 'Contenu protégé par mot de passe',
			'sync'  => true,
			'layer' => 'layout',
		],
	],
];
