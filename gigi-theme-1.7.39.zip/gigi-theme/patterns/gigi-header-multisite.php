<?php
/**
 * Title: GIGI - Header Multisite
 * Slug: gigi-theme/gigi-header-multisite
 * Categories: gigi
 * Keywords: header, en-tête, navigation, logo, multisite
 * Viewport Width: 1200
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"GIGI - Header Multisite","categories":["gigi"],"patternName":"gigi-theme/gigi-header-multisite"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"custom-gigi-gris-fonce","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-gris-fonce-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide">

		<!-- wp:html -->
		<a href="https://www.gigi-evenements.fr" style="display:block;flex:0 0 auto;width:125px;line-height:0">
			<img src="/wp-content/themes/gigi-theme/assets/images/logo-gigi-evenements.png" alt="Gigi Évènements" width="125" style="width:125px;height:auto;display:block"/>
		</a>
		<!-- /wp:html -->

		<!-- wp:navigation {"overlayMenu":"mobile","overlay":"navigation-mobile","textColor":"white","icon":"menu","fontSize":"s","className":"gigi-header-nav","style":{"spacing":{"blockGap":"1.5rem"}},"layout":{"type":"flex","justifyContent":"right"}} -->
		<!-- wp:navigation-link {"label":"Nos marques","url":"https://www.gigi-evenements.fr/nos-marques","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"Festivals","url":"https://www.gigi-evenements.fr/foodtruck-festival-fr","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"Évènementiel","url":"https://www.gigi-evenements.fr/evenementiel","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"Qui sommes-nous","url":"https://www.gigi-evenements.fr/notre-histoire","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"Contact","url":"https://www.gigi-evenements.fr/contact","kind":"custom","isTopLevelLink":true} /-->
		<!-- /wp:navigation -->

	</div>
	<!-- /wp:group -->

</div>
<!-- /wp:group -->
