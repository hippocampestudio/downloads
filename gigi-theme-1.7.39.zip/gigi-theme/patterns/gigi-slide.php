<?php
/**
 * Title: GIGI - Slide
 * Slug: gigi-theme/gigi-slide
 * Categories: gigi
 * Keywords: slide, slider, carte, image, cta
 * Viewport Width: 800
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"GIGI - Slide","categories":["gigi"],"patternName":"gigi-theme/gigi-slide"},"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"border":{"radius":{"topLeft":"30px","topRight":"30px","bottomLeft":"30px","bottomRight":"30px"}}},"backgroundColor":"custom-gigi-gris-fonce","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-gris-fonce-background-color has-background" style="border-top-left-radius:30px;border-top-right-radius:30px;border-bottom-left-radius:30px;border-bottom-right-radius:30px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"verticalAlignment":"center","align":"full","style":{"spacing":{"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns alignfull are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"66.66%","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"blockGap":"var:preset|spacing|20"},"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-blanc"}}}},"textColor":"custom-gigi-blanc"} -->
<div class="wp-block-column is-vertically-aligned-center has-custom-gigi-blanc-color has-text-color has-link-color" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50);flex-basis:66.66%"><!-- wp:heading -->
<h2 class="wp-block-heading">Titre h2</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Texte</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"fontSize":"xs"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-xs-font-size has-custom-font-size wp-element-button">Label du bouton</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:image {"lightbox":{"enabled":false},"aspectRatio":"3/4","scale":"cover","sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":{"topRight":"30px","bottomRight":"30px"}}}} -->
<figure class="wp-block-image size-full has-custom-border"><img style="border-top-right-radius:30px;border-bottom-right-radius:30px;aspect-ratio:3/4;object-fit:cover"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
