<?php
/**
 * Title: GIGI - Formulaire
 * Slug: gigi-theme/gigi-formulaire
 * Categories: gigi
 * Keywords: formulaire, form, forminator, contact
 * Viewport Width: 800
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"GIGI - Formulaire","categories":["gigi"],"patternName":"gigi-theme/gigi-formulaire"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}},"border":{"radius":{"topLeft":"40px","topRight":"40px","bottomLeft":"40px","bottomRight":"40px"}},"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-blanc"}}}},"backgroundColor":"custom-gigi-gris-fonce","textColor":"custom-gigi-blanc","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-blanc-color has-custom-gigi-gris-fonce-background-color has-text-color has-background has-link-color" style="border-top-left-radius:40px;border-top-right-radius:40px;border-bottom-left-radius:40px;border-bottom-right-radius:40px;margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50);padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:forminator/forms {"module_id":""} /--></div>
<!-- /wp:group -->
