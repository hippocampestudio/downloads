<?php
/**
 * Title: GIGI - Vignette Titrée
 * Slug: gigi-theme/gigi-vignette-titree
 * Categories: gigi
 * Keywords: vignette, cover, titre, carte, image
 * Viewport Width: 400
 * Inserter: true
 */
?>
<!-- wp:cover {"dimRatio":0,"isUserOverlayColor":false,"contentPosition":"bottom center","isDark":false,"sizeSlug":"full","metadata":{"name":"GIGI Vignette Titrée","categories":["gigi"],"patternName":"gigi-theme/gigi-vignette-titree"},"style":{"border":{"radius":{"topLeft":"40px","topRight":"40px","bottomLeft":"40px","bottomRight":"40px"}},"spacing":{"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover is-light has-custom-content-position is-position-bottom-center" style="border-top-left-radius:40px;border-top-right-radius:40px;border-bottom-left-radius:40px;border-bottom-right-radius:40px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20","right":"var:preset|spacing|20"}}},"backgroundColor":"custom-gigi-gris-fonce","fontSize":"xs","fontFamily":"zuume","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-custom-gigi-gris-fonce-background-color has-background has-zuume-font-family has-xs-font-size" style="padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:paragraph {"placeholder":"Rédigez le titre…","align":"full","style":{"typography":{"textAlign":"center","fontStyle":"normal","fontWeight":"500"}},"fontSize":"large"} -->
<p class="has-text-align-center alignfull has-large-font-size" style="font-style:normal;font-weight:500">Titre<br>de la vignette</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->
