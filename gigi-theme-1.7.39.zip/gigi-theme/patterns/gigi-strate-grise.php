<?php
/**
 * Title: GIGI - Strate Grise
 * Slug: gigi-theme/gigi-strate-grise
 * Categories: gigi
 * Keywords: strate, cover, gris, section, image, cta
 * Viewport Width: 1400
 * Inserter: true
 */
?>
<!-- wp:cover {"overlayColor":"custom-gigi-gris-fonce","isUserOverlayColor":true,"minHeight":50,"sizeSlug":"full","metadata":{"name":"GIGI Strate Grise","categories":["gigi"],"patternName":"gigi-theme/gigi-strate-grise"},"align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull" style="padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30);min-height:50px"><span aria-hidden="true" class="wp-block-cover__background has-custom-gigi-gris-fonce-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:columns {"verticalAlignment":"bottom","align":"wide","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":{"top":"0","left":"0"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-bottom" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"verticalAlignment":"bottom","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:55%"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"10%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:10%"></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"35%","style":{"spacing":{"blockGap":"var:preset|spacing|30","padding":{"bottom":"var:preset|spacing|50","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}}}} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30);flex-basis:35%"><!-- wp:heading -->
<h2 class="wp-block-heading">Titre h2</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"xs"} -->
<p class="has-xs-font-size">Texte</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-fill","fontSize":"s"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link has-s-font-size has-custom-font-size wp-element-button">Label du bouton</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->
