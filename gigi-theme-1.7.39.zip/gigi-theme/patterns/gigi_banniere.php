<?php
/**
 * Title: GIGI - Bannière
 * Slug: gigi-theme/gigi-banniere
 * Categories: gigi
 * Keywords: bannière, cover, hero, entête
 * Viewport Width: 1400
 * Inserter: true
 */
?>
<!-- wp:cover {"overlayColor":"custom-gigi-noir","isUserOverlayColor":true,"sizeSlug":"full","metadata":{"name":"GIGI Bannière","categories":["gigi"],"patternName":"gigi-theme/gigi-banniere"},"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><span aria-hidden="true" class="wp-block-cover__background has-custom-gigi-noir-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"blockGap":{"top":"0","left":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--30)"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":1,"fontSize":"xl"} -->
<h1 class="wp-block-heading has-xl-font-size">Titre H1</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Introduction</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"isStackedOnMobile":false,"metadata":{"name":"Étoiles"},"align":"wide"} -->
<div class="wp-block-columns alignwide is-not-stacked-on-mobile"><!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"backgroundColor":"custom-gigi-blanc"} -->
<hr class="wp-block-separator has-text-color has-custom-gigi-blanc-color has-alpha-channel-opacity has-custom-gigi-blanc-background-color has-background is-style-wide" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"200px"} -->
<div class="wp-block-column" style="flex-basis:200px"><!-- wp:image {"lightbox":{"enabled":false},"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/etoiles.svg' ) ); ?>" alt="Étoiles décoratif"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"backgroundColor":"custom-gigi-blanc"} -->
<hr class="wp-block-separator has-text-color has-custom-gigi-blanc-color has-alpha-channel-opacity has-custom-gigi-blanc-background-color has-background is-style-wide" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)"/>
<!-- /wp:separator --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->
