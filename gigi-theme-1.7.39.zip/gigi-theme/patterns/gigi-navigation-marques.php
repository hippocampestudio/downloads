<?php
/**
 * Title: GIGI - Navigation Marques
 * Slug: gigi-theme/gigi-navigation-marques
 * Categories: gigi
 * Keywords: navigation, marques, logos, foodtruck
 * Viewport Width: 1200
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"GIGI - Navigation Marques","categories":["gigi"],"patternName":"gigi-theme/gigi-navigation-marques"},"align":"full","className":"gigi-navigation-marques","style":{"spacing":{"blockGap":"0","padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"dimensions":{"minHeight":"60px"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group alignfull gigi-navigation-marques" style="min-height:60px;padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"custom","style":{"layout":{"selfStretch":"fit","flexSize":""},"spacing":{"margin":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}}} -->
<figure class="wp-block-image size-full" style="margin-right:var(--wp--preset--spacing--30);margin-left:var(--wp--preset--spacing--30)"><a href="https://www.gigi-evenements.fr/nos-marques/fb-foodtruck-fr/"><img src="/wp-content/themes/gigi-theme/assets/images/fb-foodtruck-bouton.png" alt="FB-Foodtruck" style="object-fit:cover"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"custom","style":{"layout":{"selfStretch":"fit","flexSize":null},"spacing":{"margin":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}}} -->
<figure class="wp-block-image size-full" style="margin-right:var(--wp--preset--spacing--30);margin-left:var(--wp--preset--spacing--30)"><a href="https://www.gigi-evenements.fr/nos-marques/fb-food-fr/"><img src="/wp-content/themes/gigi-theme/assets/images/fb-food-bouton.png" alt="FB-Food" style="object-fit:cover"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"custom","style":{"layout":{"selfStretch":"fit","flexSize":null},"spacing":{"margin":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}}} -->
<figure class="wp-block-image size-full" style="margin-right:var(--wp--preset--spacing--30);margin-left:var(--wp--preset--spacing--30)"><a href="https://www.gigi-evenements.fr/nos-marques/fb-lebar-fr/"><img src="/wp-content/themes/gigi-theme/assets/images/fb-lebar-bouton.png" alt="FB-Lebar" style="object-fit:cover"/></a></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"custom","className":"gigi-navigation-marques__guinguette","style":{"layout":{"selfStretch":"fit","flexSize":null},"spacing":{"margin":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}},"border":{"radius":{"topLeft":"50%","topRight":"50%","bottomLeft":"50%","bottomRight":"50%"}}}} -->
<figure class="wp-block-image size-full gigi-navigation-marques__guinguette has-custom-border" style="margin-right:var(--wp--preset--spacing--30);margin-left:var(--wp--preset--spacing--30)"><a href="https://www.gigi-evenements.fr/nos-marques/la-guinguette-ephemere-fr/"><img src="/wp-content/themes/gigi-theme/assets/images/la-guinguette-ephemere-bouton.png" alt="La Guinguette éphémère" style="border-top-left-radius:50%;border-top-right-radius:50%;border-bottom-left-radius:50%;border-bottom-right-radius:50%;object-fit:cover"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->
