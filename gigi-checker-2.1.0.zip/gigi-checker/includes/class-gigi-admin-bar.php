<?php
/**
 * Gigi_Admin_Bar — menu « SITES GIGI » dans la barre d’admin WP.
 *
 * Liste les sites de la flotte (ou les défauts) avec un lien vers /bo-securise.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Admin_Bar {

	private const ADMIN_PATH = 'bo-securise';

	public static function register(): void {
		add_action( 'admin_bar_menu', [ self::class, 'add_nodes' ], 100 );
	}

	/**
	 * @param WP_Admin_Bar $bar
	 */
	public static function add_nodes( $bar ): void {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		$sites = Gigi_Fleet::get_sites_for_editor();
		if ( empty( $sites ) ) {
			return;
		}

		$bar->add_node(
			[
				'id'    => 'gigi-sites',
				'title' => 'SITES GIGI',
				'href'  => false,
				'meta'  => [
					'title' => 'Administration des sites Gigi',
				],
			]
		);

		$current = Gigi_Fleet::get_current_site_url();
		foreach ( $sites as $index => $site ) {
			$url   = trailingslashit( $site['url'] ) . self::ADMIN_PATH . '/';
			$label = $site['label'];
			if ( Gigi_Fleet::urls_match( $site['url'], $current ) ) {
				$label = '• ' . $label;
			}

			$bar->add_node(
				[
					'id'     => 'gigi-sites-' . $index,
					'parent' => 'gigi-sites',
					'title'  => $label,
					'href'   => esc_url( $url ),
				]
			);
		}
	}
}
