<?php
/**
 * Gigi_Remote_Sync — endpoint REST pour forcer la vérification et appliquer les MAJ à distance.
 * Utilisé en phase de dev pour mettre à jour tous les sites en une commande.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Remote_Sync {

	private const OPTION_SECRET = 'gigi_checker_sync_secret';
	private const REST_NAMESPACE = 'gigi-checker/v1';

	public static function register(): void {
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
	}

	public static function register_routes(): void {
		register_rest_route( self::REST_NAMESPACE, '/sync', [
			'methods'             => 'POST',
			'permission_callback' => [ self::class, 'check_secret' ],
			'callback'            => [ self::class, 'sync_and_apply' ],
		] );
	}

	/**
	 * Vérifie le secret (header X-Gigi-Sync-Secret ou body secret).
	 */
	public static function check_secret( WP_REST_Request $request ): bool {
		$secret = get_option( self::OPTION_SECRET, '' );
		if ( '' === $secret || ! is_string( $secret ) ) {
			return false;
		}

		$provided = $request->get_header( 'X-Gigi-Sync-Secret' );
		if ( '' === $provided ) {
			$body = $request->get_json_params();
			$provided = $body['secret'] ?? $request->get_param( 'secret' ) ?? '';
		}

		return is_string( $provided ) && hash_equals( $secret, $provided );
	}

	/**
	 * Force la vérification des versions puis applique les mises à jour Gigi.
	 */
	public static function sync_and_apply( WP_REST_Request $request ): WP_REST_Response {
		$result = [
			'success'   => true,
			'message'   => '',
			'updated'   => [],
			'errors'    => [],
		];

		// 1. Vider le cache et récupérer versions.json
		Gigi_Versions::flush_cache();
		$remote = Gigi_Versions::fetch_remote();

		if ( empty( $remote ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message'  => 'Impossible de récupérer versions.json',
				'updated'  => [],
				'errors'   => [ 'fetch_remote' ],
			], 500 );
		}

		// 2. Mettre à jour les transients (même logique que force-check)
		self::update_transients( $remote );

		// 3. Appliquer les mises à jour (thème + plugins)
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$tp = get_site_transient( 'update_plugins' );
		$tt = get_site_transient( 'update_themes' );

		// Plugins Gigi
		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $plugin_file ) {
			if ( ! isset( $tp->response[ $plugin_file ] ) ) {
				continue;
			}
			$obj = $tp->response[ $plugin_file ];
			if ( empty( $obj->package ) ) {
				continue;
			}
			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$done = $upgrader->upgrade( $plugin_file, [ 'clear_update_cache' => false ] );
			if ( true === $done ) {
				$result['updated'][] = 'plugin:' . $plugin_file;
			} elseif ( is_wp_error( $done ) ) {
				$result['errors'][] = 'plugin:' . $plugin_file . ' — ' . $done->get_error_message();
			}
		}

		// Thème Gigi
		if ( isset( $tt->response['gigi-theme']['package'] ) && '' !== $tt->response['gigi-theme']['package'] ) {
			$upgrader = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
			$done = $upgrader->upgrade( 'gigi-theme', [ 'clear_update_cache' => false ] );
			if ( true === $done ) {
				$result['updated'][] = 'theme:gigi-theme';
			} elseif ( is_wp_error( $done ) ) {
				$result['errors'][] = 'theme:gigi-theme — ' . $done->get_error_message();
			}
		}

		if ( ! empty( $result['errors'] ) ) {
			$result['success'] = false;
			$result['message'] = implode( ' ; ', $result['errors'] );
		} else {
			$result['message'] = count( $result['updated'] ) > 0
				? 'Mises à jour appliquées : ' . implode( ', ', $result['updated'] )
				: 'Aucune mise à jour à appliquer (déjà à jour).';
		}

		// Vider le cache des mises à jour pour refléter l’état réel
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Met à jour les transients update_plugins et update_themes (copie de la logique admin_init force-check).
	 */
	private static function update_transients( array $remote ): void {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$tp = get_site_transient( 'update_plugins' );
		if ( ! is_object( $tp ) ) {
			$tp = new stdClass();
		}
		if ( ! isset( $tp->response ) ) {
			$tp->response = [];
		}
		if ( ! isset( $tp->no_update ) ) {
			$tp->no_update = [];
		}
		if ( ! isset( $tp->checked ) ) {
			$tp->checked = [];
		}

		foreach ( [
			'gigi-checker/gigi-checker.php' => 'gigi-checker',
			'gigi-blocks/gigi-blocks.php'   => 'gigi-blocks',
		] as $plugin_file => $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $plugin_file;
			if ( ! file_exists( $path ) ) {
				continue;
			}
			$data            = get_plugin_data( $path );
			$current_version = $data['Version'] ?? '0.0.0';
			$r               = $remote[ $slug ] ?? null;
			$tp->checked[ $plugin_file ] = $current_version;

			if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
				unset( $tp->no_update[ $plugin_file ] );
				$tp->response[ $plugin_file ] = (object) [
					'id'           => 'gigi/' . $slug,
					'slug'         => $slug,
					'plugin'       => $plugin_file,
					'new_version'  => $r['version'],
					'url'          => 'https://hippocampe.studio',
					'package'      => $r['zip_url'],
					'icons'        => [],
					'banners'      => [],
					'tested'       => $r['tested']       ?? '6.7',
					'requires_php' => $r['requires_php'] ?? '8.1',
					'requires'     => $r['requires']     ?? '6.4',
				];
			} elseif ( $r ) {
				unset( $tp->response[ $plugin_file ] );
				$tp->no_update[ $plugin_file ] = (object) [
					'id'          => 'gigi/' . $slug,
					'slug'        => $slug,
					'plugin'      => $plugin_file,
					'new_version' => $current_version,
					'url'         => 'https://hippocampe.studio',
					'package'     => '',
					'icons'       => [],
					'banners'     => [],
				];
			}
		}
		set_site_transient( 'update_plugins', $tp );

		$tt = get_site_transient( 'update_themes' );
		if ( ! is_object( $tt ) ) {
			$tt = new stdClass();
		}
		if ( ! isset( $tt->response ) ) {
			$tt->response = [];
		}
		if ( ! isset( $tt->no_update ) ) {
			$tt->no_update = [];
		}
		if ( ! isset( $tt->checked ) ) {
			$tt->checked = [];
		}

		$theme           = wp_get_theme( 'gigi-theme' );
		$current_version = $theme->get( 'Version' );
		$r               = $remote['gigi-theme'] ?? null;
		$tt->checked['gigi-theme'] = $current_version;

		if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
			unset( $tt->no_update['gigi-theme'] );
			$tt->response['gigi-theme'] = [
				'theme'        => 'gigi-theme',
				'new_version'  => $r['version'],
				'url'          => 'https://hippocampe.studio',
				'package'      => $r['zip_url'],
				'requires'     => $r['requires']     ?? '6.4',
				'requires_php' => $r['requires_php'] ?? '8.1',
			];
		} elseif ( $r ) {
			unset( $tt->response['gigi-theme'] );
			$tt->no_update['gigi-theme'] = [
				'theme'       => 'gigi-theme',
				'new_version' => $current_version,
				'url'         => 'https://hippocampe.studio',
				'package'     => '',
			];
		}
		set_site_transient( 'update_themes', $tt );
	}

	public static function get_secret_option_name(): string {
		return self::OPTION_SECRET;
	}
}
