<?php
/**
 * Title: GIGI - En-tête (header)
 * Slug: gigi-theme/header
 * Categories: gigi
 * Block Types: core/template-part/header
 * Inserter: false
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"backgroundColor":"custom-gigi-gris-fonce","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-gris-fonce-background-color has-background" style="padding-right:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)"><!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":"125px"}}} -->
<figure class="wp-block-image size-full"><img src="" alt="Logo" style="object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:navigation {"textColor":"custom-gigi-blanc","icon":"menu","layout":{"type":"flex","justifyContent":"right","flexWrap":"nowrap"},"overlayMenu":"mobile"} -->
<!-- wp:navigation-link {"label":"Gigi Évènements","url":"https://gigi-evenements.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"FB Food","url":"https://fb-food.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"FB Le Bar","url":"https://fb-lebar.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"La Guinguette","url":"https://la-guinguette-ephemere.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
