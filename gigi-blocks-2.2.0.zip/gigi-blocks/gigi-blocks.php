<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     2.2.0
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '2.1.5' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/* ================================================================
   1. Block registration
   ================================================================ */

add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}
	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/* ================================================================
   2. Strate — frontend post-processing

   The block is STATIC: save.js generates the HTML which WP stores
   in post_content.  This filter runs AFTER WordPress has applied
   block-support styles (color, spacing) at priority 10.

   It does two things:
   A) Injects CSS custom properties from block attributes so that
      the stylesheet can read them (covers blocks saved before the
      CSS-variable logic was added to save.js).
   B) Redirects padding from the wrapper to the content column via
      a scoped <style> tag, then zeroes the wrapper padding so the
      image always touches the strate edges.
   ================================================================ */

add_filter( 'render_block', 'gigi_strate_filter_frontend', 20, 2 );

function gigi_strate_filter_frontend( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/strate' ) {
		return $content;
	}

	$attrs = $block['attrs'] ?? [];

	$p = new WP_HTML_Tag_Processor( $content );
	if ( ! $p->next_tag( 'div' ) ) {
		return $content;
	}

	// A) Inject non-padding CSS custom properties + background (options WP standard).
	$existing = $p->get_attribute( 'style' ) ?? '';
	$css_vars  = gigi_strate_build_css_vars( $attrs );
	$style     = $css_vars ? $css_vars . ( $existing ? ';' . $existing : '' ) : $existing;
	$style     = gigi_strate_merge_background_style( $attrs, $style );
	if ( $style ) {
		$p->set_attribute( 'style', $style );
	}

	$zoom = (int) ( $attrs['imageZoom'] ?? 100 );
	if ( $zoom < 100 ) {
		$class = $p->get_attribute( 'class' ) ?? '';
		if ( ! str_contains( $class, 'gigi-strate--zoom-out' ) ) {
			$p->set_attribute( 'class', trim( $class . ' gigi-strate--zoom-out' ) );
		}
	}

	// B) Padding redirect via scoped <style> tag.
	$padding    = $attrs['style']['spacing']['padding'] ?? [];
	$scoped_css = '';

	if ( ! empty( $padding ) ) {
		$uid = 'gs-' . wp_unique_id();
		$p->set_attribute( 'id', $uid );

		$scoped_css .= "#{$uid}{padding:0 !important}";
		$content_rules = '';

		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $dir ) {
			if ( ! isset( $padding[ $dir ] ) || $padding[ $dir ] === '' ) {
				continue;
			}
			$val = gigi_resolve_wp_preset( $padding[ $dir ] );
			$content_rules .= "padding-{$dir}:{$val} !important;";
		}

		if ( $content_rules ) {
			$scoped_css .= "#{$uid}>.gigi-strate__content{{$content_rules}}";
		}
	}

	$html = $p->get_updated_html();

	if ( $scoped_css ) {
		$html = "<style>{$scoped_css}</style>" . $html;
	}

	$overlay_html = gigi_strate_build_overlay_html( $attrs );
	if ( $overlay_html && ! str_contains( $html, 'gigi-strate__overlay' ) ) {
		$html = preg_replace(
			'/(<div[^>]*class="[^"]*gigi-strate[^"]*"[^>]*>)/',
			'$1' . $overlay_html,
			$html,
			1
		);
	}

	return $html;
}

/* ================================================================
   3. Shared helpers
   ================================================================ */

/**
 * Convert a WordPress preset reference to a CSS var() expression.
 *   "var:preset|spacing|80" → "var(--wp--preset--spacing--80)"
 *   "20px"                  → "20px" (returned as-is)
 */
function gigi_resolve_wp_preset( string $value ): string {
	if ( str_starts_with( $value, 'var:' ) ) {
		$parts = explode( '|', substr( $value, 4 ) );
		return 'var(--wp--' . implode( '--', $parts ) . ')';
	}
	return $value;
}

/**
 * Fusionne les styles background (image de fond WP) dans l'attribut style du wrapper.
 */
function gigi_strate_merge_background_style( array $attrs, string $existing_style ): string {
	$background = $attrs['style']['background'] ?? null;
	if ( empty( $background ) || ! is_array( $background ) ) {
		return $existing_style;
	}
	if ( ! function_exists( 'wp_style_engine_get_styles' ) ) {
		return $existing_style;
	}

	$generated = wp_style_engine_get_styles( [ 'background' => $background ] );
	$css       = $generated['css'] ?? '';
	if ( '' === $css ) {
		return $existing_style;
	}

	// Évite les doublons si le HTML sauvegardé contient déjà background-image.
	if ( str_contains( $existing_style, 'background-image' ) ) {
		return $existing_style;
	}

	return $css . ( $existing_style ? ';' . $existing_style : '' );
}

/**
 * HTML du calque de superposition (miroir de getStrateOverlayProps() en JS).
 */
function gigi_strate_build_overlay_html( array $attrs ): string {
	$dim = (int) ( $attrs['overlayDimRatio'] ?? 0 );
	if ( $dim <= 0 ) {
		return '';
	}

	$step     = min( 100, (int) ( round( $dim / 10 ) * 10 ) );
	$classes  = [
		'gigi-strate__overlay',
		'has-background-dim',
		"has-background-dim-{$step}",
	];
	$inline   = '';
	$custom   = $attrs['customOverlayColor'] ?? '';
	$preset   = $attrs['overlayColor'] ?? '';

	if ( is_string( $custom ) && '' !== $custom ) {
		$inline = 'background-color:' . sanitize_hex_color( $custom );
	} elseif ( is_string( $preset ) && '' !== $preset ) {
		$classes[] = 'has-' . sanitize_html_class( $preset ) . '-background-color';
	}

	$class_attr = esc_attr( implode( ' ', $classes ) );
	$style_attr = $inline ? ' style="' . esc_attr( $inline ) . '"' : '';

	return "<span class=\"{$class_attr}\"{$style_attr} aria-hidden=\"true\"></span>";
}

/**
 * Build CSS custom properties string from Strate block attributes.
 *
 * ⚠ Mirror of buildStrateStyle() in src/strate/utils.js — keep in sync.
 */
function gigi_strate_build_css_vars( array $attrs ): string {
	$vars = [];

	$cw = array_key_exists( 'contentWidth', $attrs ) && null !== $attrs['contentWidth']
		? (int) $attrs['contentWidth']
		: ( 100 - (int) ( $attrs['mediaWidth'] ?? 50 ) );
	if ( 50 !== $cw ) {
		$vars[] = "--gigi-strate-content-width:{$cw}%";
	}

	$gap = (int) ( $attrs['columnsGap'] ?? 0 );
	if ( $gap > 0 ) {
		$vars[] = "--gigi-strate-gap:{$gap}px";
	}

	$px = (int) ( $attrs['imagePositionX'] ?? 50 );
	$py = (int) ( $attrs['imagePositionY'] ?? 50 );
	if ( $px !== 50 || $py !== 50 ) {
		$vars[] = "--gigi-strate-img-pos:{$px}% {$py}%";
	}

	$zoom = (int) ( $attrs['imageZoom'] ?? 100 );
	if ( $zoom !== 100 ) {
		$vars[] = '--gigi-strate-img-zoom:' . round( $zoom / 100, 2 );
	}

	// Legacy global button colors (backward compat for pre-2.0 blocks).
	$colors = [
		'buttonBgColor'      => 'btn-bg',
		'buttonTextColor'    => 'btn-color',
		'buttonHoverBgColor' => 'btn-hover-bg',
	];
	foreach ( $colors as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$vars[] = "--gigi-strate-{$css}:{$attrs[ $attr ]}";
		}
	}

	// Legacy global typography.
	$fonts = [
		'titleFontSize'  => 'title-size',
		'textFontSize'   => 'text-size',
		'buttonFontSize' => 'btn-size',
	];
	foreach ( $fonts as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$val = $attrs[ $attr ];
			if ( preg_match( '/^[a-z-]+$/i', $val ) ) {
				$val = "var(--wp--preset--font-size--{$val})";
			}
			$vars[] = "--gigi-strate-{$css}:{$val}";
		}
	}

	return implode( ';', $vars );
}

/* ================================================================
   4. Slider — frontend assets
   ================================================================ */

add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}
	wp_enqueue_style( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.css', [], GIGI_BLOCKS_VERSION );
	wp_enqueue_script( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.js', [], GIGI_BLOCKS_VERSION, true );
	return $content;
}, 10, 2 );

/* ================================================================
   5. Block category
   ================================================================ */

add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
