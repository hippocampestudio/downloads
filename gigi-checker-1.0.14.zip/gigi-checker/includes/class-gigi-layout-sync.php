<?php
/**
 * Gigi_Layout_Sync — réapplique les template parts de layout depuis les fichiers du thème.
 *
 * WordPress enregistre en base une copie dès qu’un template part est modifié dans
 * l’éditeur de site. Cette copie masque le fichier du thème, même après une MAJ ZIP.
 * Ce module supprime ces surcharges pour les composants listés dans sync-manifest.php.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Layout_Sync {

	private const THEME_SLUG = 'gigi-theme';

	public static function register(): void {
		add_action( 'upgrader_process_complete', [ self::class, 'on_upgrader_complete' ], 20, 2 );
	}

	/**
	 * @return array{template_parts: array<string, array<string, mixed>>, patterns: array<string, array<string, mixed>>}|null
	 */
	public static function get_manifest(): ?array {
		$path = get_theme_root() . '/' . self::THEME_SLUG . '/sync-manifest.php';

		if ( ! is_readable( $path ) ) {
			return null;
		}

		$manifest = require $path;

		return is_array( $manifest ) ? $manifest : null;
	}

	/**
	 * @return array<string, array{slug: string, label: string, source: string, customized: bool}>
	 */
	public static function get_status(): array {
		$manifest = self::get_manifest();
		$status   = [];

		if ( null === $manifest ) {
			return $status;
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}

			$template = self::get_template_part( $slug );
			$source   = $template->source ?? 'missing';

			$status[ $slug ] = [
				'slug'        => $slug,
				'label'       => $config['label'] ?? $slug,
				'source'      => $source,
				'customized'  => 'custom' === $source,
			];
		}

		return $status;
	}

	/**
	 * Supprime les surcharges DB des template parts synchronisés.
	 *
	 * @return array{reset: string[], already_synced: string[], missing: string[], errors: string[]}
	 */
	public static function sync_all(): array {
		$report = [
			'reset'          => [],
			'already_synced' => [],
			'missing'        => [],
			'errors'         => [],
		];

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			$report['errors'][] = 'sync-manifest.php introuvable dans gigi-theme';
			return $report;
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}

			$result = self::reset_template_part( $slug );

			if ( 'reset' === $result ) {
				$report['reset'][] = $slug;
			} elseif ( 'already_synced' === $result ) {
				$report['already_synced'][] = $slug;
			} elseif ( 'missing' === $result ) {
				$report['missing'][] = $slug;
			} else {
				$report['errors'][] = $slug . ' (' . $result . ')';
			}
		}

		return $report;
	}

	public static function on_upgrader_complete( $upgrader, array $options ): void {
		if ( ( $options['action'] ?? '' ) !== 'update' || ( $options['type'] ?? '' ) !== 'theme' ) {
			return;
		}

		$themes = $options['themes'] ?? [];
		if ( ! in_array( self::THEME_SLUG, $themes, true ) ) {
			return;
		}

		self::sync_all();
	}

	private static function get_template_part( string $slug ): ?WP_Block_Template {
		if ( ! function_exists( 'get_block_template' ) ) {
			return null;
		}

		$template = get_block_template( self::THEME_SLUG . '//' . $slug, 'wp_template_part' );

		return $template instanceof WP_Block_Template ? $template : null;
	}

	/**
	 * @return 'reset'|'already_synced'|'missing'|'delete_failed'|'no_wp_id'
	 */
	private static function reset_template_part( string $slug ): string {
		$template = self::get_template_part( $slug );

		if ( ! $template ) {
			return 'missing';
		}

		if ( 'theme' === $template->source ) {
			return 'already_synced';
		}

		if ( empty( $template->wp_id ) ) {
			return 'no_wp_id';
		}

		$deleted = wp_delete_post( (int) $template->wp_id, true );

		if ( ! $deleted ) {
			return 'delete_failed';
		}

		self::clear_template_cache( $slug );

		return 'reset';
	}

	private static function clear_template_cache( string $slug ): void {
		if ( function_exists( 'clean_theme_cache' ) ) {
			clean_theme_cache( self::THEME_SLUG );
		}

		wp_cache_delete( 'wp_template_part_' . $slug . '_' . self::THEME_SLUG, 'block_templates' );
		wp_cache_delete( 'wp_template_part_' . self::THEME_SLUG . '//' . $slug, 'block_templates' );
	}
}
