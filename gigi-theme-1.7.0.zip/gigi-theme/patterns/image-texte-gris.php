<?php
/**
 * Title: GIGI - Image/Texte fond gris
 * Slug: gigi-theme/image-texte-gris
 * Categories: gigi
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"Image/Texte Gris"},"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"background":{"backgroundSize":"50vw","backgroundPosition":"0% 50%","backgroundRepeat":"no-repeat"}},"backgroundColor":"custom-gigi-gris-fonce","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-gris-fonce-background-color has-background" style="padding-top:0;padding-right:var(--wp--preset--spacing--50);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group alignwide" style="padding-right:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"},"layout":{"selfStretch":"fixed","flexSize":"50%"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-blanc"}}}},"textColor":"custom-gigi-blanc"} -->
<h2 class="wp-block-heading has-custom-gigi-blanc-color has-text-color has-link-color">Titre</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-gris-clair"}}}},"textColor":"custom-gigi-gris-clair"} -->
<p class="has-custom-gigi-gris-clair-color has-text-color has-link-color">Ceci est un texte d'introduction à la fois long et pas trop long car il doit représenter un texte standard d'accroche pour une strate de contenu avec une image sur la gauche</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"custom-gigi-blanc","textColor":"custom-gigi-noir","style":{"border":{"radius":{"topLeft":"5px","topRight":"5px","bottomLeft":"5px","bottomRight":"5px"}},"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-noir"}}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-gigi-noir-color has-custom-gigi-blanc-background-color has-text-color has-background has-link-color wp-element-button" style="border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px">Réservez</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
