<?php
/**
 * Title: GIGI - Texte/Image fond blanc
 * Slug: gigi-theme/texte-image-blanc
 * Categories: gigi
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"Texte/Image Blanc"},"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"background":{"backgroundSize":"50vw","backgroundPosition":"100% 50%","backgroundRepeat":"no-repeat","backgroundAttachment":"scroll"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:0;padding-right:var(--wp--preset--spacing--50);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"},"layout":{"selfStretch":"fixed","flexSize":"50%"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading -->
<h2 class="wp-block-heading">Titre</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Ceci est un texte d'introduction à la fois long et pas trop long car il doit représenter un texte standard d'accroche pour une strate de contenu avec une image sur la droite</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"custom-gigi-noir","style":{"elements":{"link":{"color":{"text":"#ffffff"}}},"border":{"radius":{"topLeft":"5px","topRight":"5px","bottomLeft":"5px","bottomRight":"5px"}},"color":{"text":"#ffffff"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-gigi-noir-background-color has-text-color has-background has-link-color wp-element-button" style="border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;color:#ffffff">Réservez</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
