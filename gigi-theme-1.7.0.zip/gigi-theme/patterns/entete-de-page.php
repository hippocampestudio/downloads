<?php
/**
 * Title: GIGI - Entête de page
 * Slug: gigi-theme/entete-de-page
 * Categories: gigi
 * Inserter: true
 */
?>
<!-- wp:group {"metadata":{"name":"Entête de page"},"style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-blanc"}}},"spacing":{"padding":{"bottom":"var:preset|spacing|70","top":"var:preset|spacing|70"}}},"backgroundColor":"custom-gigi-noir","textColor":"custom-gigi-blanc","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-blanc-color has-custom-gigi-noir-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"blockGap":{"left":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30)"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Titre</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Texte d'introduction</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"custom-gigi-blanc","textColor":"custom-gigi-gris-fonce","style":{"elements":{"link":{"color":{"text":"var:preset|color|custom-gigi-gris-fonce"}}},"border":{"radius":{"topLeft":"5px","topRight":"5px","bottomLeft":"5px","bottomRight":"5px"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-gigi-gris-fonce-color has-custom-gigi-blanc-background-color has-text-color has-background has-link-color wp-element-button" style="border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px">Réservez</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"isStackedOnMobile":false,"align":"wide"} -->
<div class="wp-block-columns alignwide is-not-stacked-on-mobile"><!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"custom-gigi-gris-clair"} -->
<hr class="wp-block-separator has-text-color has-custom-gigi-gris-clair-color has-alpha-channel-opacity has-custom-gigi-gris-clair-background-color has-background is-style-wide" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"200px"} -->
<div class="wp-block-column" style="flex-basis:200px"><!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="" alt="Étoiles décoratif" style="object-fit:cover"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:separator {"className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"custom-gigi-gris-clair"} -->
<hr class="wp-block-separator has-text-color has-custom-gigi-gris-clair-color has-alpha-channel-opacity has-custom-gigi-gris-clair-background-color has-background is-style-wide" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/>
<!-- /wp:separator --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
