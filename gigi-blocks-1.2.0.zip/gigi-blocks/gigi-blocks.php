<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites Gigi : cartes d'événements, galeries, menus, etc.
 * Version:     1.2.0
 * Author:      Antibo
 * Author URI:  https://bitbucket.org/antibo
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '1.2.0' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Enregistre tous les blocs présents dans le dossier build/.
 * Chaque bloc doit avoir son propre block.json.
 */
add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';

	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}

	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/**
 * Enqueue le JS vanilla du slider uniquement sur les pages qui l'utilisent.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( has_block( 'gigi/slider' ) ) {
		wp_enqueue_style(
			'gigi-slider',
			GIGI_BLOCKS_URL . 'assets/slider.css',
			[],
			GIGI_BLOCKS_VERSION
		);
		wp_enqueue_script(
			'gigi-slider',
			GIGI_BLOCKS_URL . 'assets/slider.js',
			[],
			GIGI_BLOCKS_VERSION,
			true
		);
	}
} );

/**
 * Catégorie de blocs personnalisée "Gigi" dans l'éditeur.
 */
add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
