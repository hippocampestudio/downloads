/**
 * GIGI Slider — carousel frontend (flèches + drag souris + swipe touch).
 */
( function () {
	var DRAG_THRESHOLD = 50;

	function init( el ) {
		var viewport  = el.querySelector( '.gigi-slider__viewport' );
		var track     = el.querySelector( '.gigi-slider__track' );
		var slides    = el.querySelectorAll( '.gigi-slide' );
		var prevBtn   = el.querySelector( '.gigi-slider__arrow--prev' );
		var nextBtn   = el.querySelector( '.gigi-slider__arrow--next' );
		var total     = slides.length;
		var current   = 0;
		var dragStartX = null;
		var roDebounce = null;

		if ( ! track || total === 0 ) return;

		/**
		 * Synchronise la hauteur de toutes les slides sur la plus haute,
		 * pour éviter les sauts de hauteur lors du défilement.
		 */
		function syncHeight() {
			for ( var i = 0; i < slides.length; i++ ) {
				slides[ i ].style.height = 'auto';
			}
			void track.offsetHeight; // force reflow
			var maxH = 0;
			for ( var i = 0; i < slides.length; i++ ) {
				var h = slides[ i ].getBoundingClientRect().height;
				if ( h > maxH ) maxH = h;
			}
			if ( maxH > 0 ) {
				for ( var i = 0; i < slides.length; i++ ) {
					slides[ i ].style.height = maxH + 'px';
				}
			}
		}

		function syncHeightDebounced() {
			clearTimeout( roDebounce );
			roDebounce = setTimeout( syncHeight, 50 );
		}

		function goTo( index ) {
			if ( index < 0 || index >= total ) return;
			current = index;
			track.style.transform = 'translateX(-' + current * 100 + '%)';
			if ( prevBtn ) prevBtn.disabled = current === 0;
			if ( nextBtn ) nextBtn.disabled = current === total - 1;
		}

		if ( prevBtn ) prevBtn.addEventListener( 'click', function () { goTo( current - 1 ); } );
		if ( nextBtn ) nextBtn.addEventListener( 'click', function () { goTo( current + 1 ); } );

		/* Drag souris */
		var area = viewport || el;
		area.addEventListener( 'mousedown', function ( e ) {
			if ( e.button !== 0 ) return;
			dragStartX = e.clientX;
		} );
		area.addEventListener( 'mouseleave', function () { dragStartX = null; } );
		area.addEventListener( 'mouseup', function ( e ) {
			if ( e.button !== 0 || dragStartX === null ) return;
			var delta = e.clientX - dragStartX;
			if ( delta > DRAG_THRESHOLD )       goTo( current - 1 );
			else if ( delta < -DRAG_THRESHOLD ) goTo( current + 1 );
			dragStartX = null;
		} );

		/* Swipe tactile */
		var touchStartX = null;
		area.addEventListener( 'touchstart', function ( e ) {
			touchStartX = e.touches[ 0 ].clientX;
		}, { passive: true } );
		area.addEventListener( 'touchend', function ( e ) {
			if ( touchStartX === null ) return;
			var delta = e.changedTouches[ 0 ].clientX - touchStartX;
			if ( delta > DRAG_THRESHOLD )       goTo( current - 1 );
			else if ( delta < -DRAG_THRESHOLD ) goTo( current + 1 );
			touchStartX = null;
		}, { passive: true } );

		goTo( 0 );

		syncHeight();
		window.addEventListener( 'load', syncHeight );
		window.addEventListener( 'resize', syncHeightDebounced );

		if ( typeof ResizeObserver !== 'undefined' ) {
			var ro = new ResizeObserver( syncHeightDebounced );
			for ( var i = 0; i < slides.length; i++ ) {
				ro.observe( slides[ i ] );
			}
		}
	}

	function run() {
		document.querySelectorAll( '[data-gigi-slider]' ).forEach( init );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', run );
	} else {
		run();
	}
} )();
