<?php
/**
 * Gigi_Versions — récupère et met en cache le fichier versions.json distant.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Versions {

	private const CACHE_KEY = 'gigi_checker_versions';

	/**
	 * Retourne le tableau de versions (depuis le cache ou le remote).
	 *
	 * Structure attendue du versions.json :
	 * {
	 *   "gigi-theme": {
	 *     "version": "1.2.0",
	 *     "zip_url": "https://bitbucket.org/antibo/downloads/raw/main/gigi-theme-1.2.0.zip",
	 *     "requires": "6.4",
	 *     "requires_php": "8.1",
	 *     "tested": "6.7"
	 *   },
	 *   "gigi-checker": { ... },
	 *   "gigi-blocks":  { ... }
	 * }
	 */
	public static function get(): array {
		$cached = get_transient( self::CACHE_KEY );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		return self::fetch_remote();
	}

	/**
	 * Récupère le fichier distant et met en cache le résultat.
	 */
	public static function fetch_remote(): array {
		$response = wp_remote_get( GIGI_VERSIONS_URL, [
			'timeout'    => 10,
			'user-agent' => 'GigiChecker/' . GIGI_CHECKER_VERSION . '; ' . home_url(),
		] );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $code ) {
			return [];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			return [];
		}

		set_transient( self::CACHE_KEY, $data, GIGI_CHECKER_CACHE_TTL );

		return $data;
	}

	/**
	 * Retourne les données d'un composant spécifique (slug).
	 */
	public static function get_for( string $slug ): ?array {
		$versions = self::get();
		return $versions[ $slug ] ?? null;
	}

	/**
	 * Vide le cache pour forcer une re-vérification.
	 */
	public static function flush_cache(): void {
		delete_transient( self::CACHE_KEY );
	}
}
