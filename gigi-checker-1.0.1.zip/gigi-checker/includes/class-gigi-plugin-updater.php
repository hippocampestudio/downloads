<?php
/**
 * Gigi_Plugin_Updater — injecte les mises à jour des plugins dans WordPress.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Plugin_Updater {

	private string $plugin_file;
	private string $slug;
	private array  $plugin_data;

	/**
	 * @param string $plugin_file Chemin relatif au dossier plugins (ex: "gigi-checker/gigi-checker.php")
	 * @param string $slug        Clé dans versions.json (ex: "gigi-checker")
	 */
	public function __construct( string $plugin_file, string $slug ) {
		$this->plugin_file = $plugin_file;
		$this->slug        = $slug;
		$this->plugin_data = [];

		add_filter( 'site_transient_update_plugins', [ $this, 'inject_update' ] );
		add_filter( 'plugins_api', [ $this, 'plugin_api_info' ], 10, 3 );
		add_filter( 'upgrader_source_selection', [ $this, 'fix_directory_name' ], 10, 4 );
	}

	/**
	 * Injecte la mise à jour dans le transient de WordPress (lu à chaque vérification).
	 *
	 * On utilise `site_transient_update_plugins` (lecture) et non
	 * `pre_set_site_transient_update_plugins` (écriture) pour que l'alerte
	 * apparaisse immédiatement sans attendre le cycle de 12h de WordPress.
	 *
	 * @param mixed $transient
	 * @return mixed
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$remote = Gigi_Versions::get_for( $this->slug );
		if ( null === $remote || empty( $remote['version'] ) || empty( $remote['zip_url'] ) ) {
			return $transient;
		}

		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_path = WP_PLUGIN_DIR . '/' . $this->plugin_file;
		if ( ! file_exists( $plugin_path ) ) {
			return $transient;
		}

		$this->plugin_data   = get_plugin_data( $plugin_path );
		$current_version     = $this->plugin_data['Version'] ?? '0.0.0';

		if ( version_compare( $current_version, $remote['version'], '<' ) ) {
			$transient->response[ $this->plugin_file ] = (object) [
				'id'            => 'bitbucket/' . $this->slug,
				'slug'          => $this->slug,
				'plugin'        => $this->plugin_file,
				'new_version'   => $remote['version'],
				'url'           => 'https://bitbucket.org/antibo/gigi',
				'package'       => $remote['zip_url'],
				'icons'         => [],
				'banners'       => [],
				'tested'        => $remote['tested']        ?? '6.7',
				'requires_php'  => $remote['requires_php']  ?? '8.1',
				'requires'      => $remote['requires']      ?? '6.4',
				'upgrade_notice'=> $remote['upgrade_notice'] ?? '',
			];
		} else {
			$transient->no_update[ $this->plugin_file ] = (object) [
				'id'          => 'bitbucket/' . $this->slug,
				'slug'        => $this->slug,
				'plugin'      => $this->plugin_file,
				'new_version' => $current_version,
				'url'         => 'https://bitbucket.org/antibo/gigi',
				'package'     => '',
				'icons'       => [],
				'banners'     => [],
			];
		}

		return $transient;
	}

	/**
	 * Fournit les métadonnées du plugin pour l'écran de détail WP.
	 *
	 * @param false|object $result
	 * @param string       $action
	 * @param object       $args
	 */
	public function plugin_api_info( $result, string $action, object $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}

		if ( ! isset( $args->slug ) || $args->slug !== $this->slug ) {
			return $result;
		}

		$remote = Gigi_Versions::get_for( $this->slug );
		if ( null === $remote ) {
			return $result;
		}

		return (object) [
			'name'          => $remote['name']          ?? $this->slug,
			'slug'          => $this->slug,
			'version'       => $remote['version'],
			'author'        => '<a href="https://bitbucket.org/antibo">Antibo</a>',
			'homepage'      => 'https://bitbucket.org/antibo/gigi',
			'download_link' => $remote['zip_url'],
			'requires'      => $remote['requires']      ?? '6.4',
			'requires_php'  => $remote['requires_php']  ?? '8.1',
			'tested'        => $remote['tested']        ?? '6.7',
			'last_updated'  => $remote['last_updated']  ?? '',
			'sections'      => [
				'description' => $remote['description'] ?? '',
				'changelog'   => $remote['changelog']   ?? '',
			],
		];
	}

	/**
	 * Corrige le nom du dossier extrait du ZIP pour qu'il corresponde au slug.
	 * Bitbucket nomme parfois les ZIPs avec un hash de commit.
	 *
	 * @param string      $source        Chemin du dossier source extrait
	 * @param string      $remote_source Chemin du dossier distant
	 * @param WP_Upgrader $upgrader      Instance de l'upgrader
	 * @param array       $hook_extra    Données supplémentaires du hook
	 */
	public function fix_directory_name( string $source, string $remote_source, $upgrader, array $hook_extra ): string {
		global $wp_filesystem;

		if ( ! isset( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->plugin_file ) {
			return $source;
		}

		$correct_dir = trailingslashit( dirname( $source ) ) . $this->slug . '/';

		if ( $source === $correct_dir ) {
			return $source;
		}

		if ( $wp_filesystem->move( $source, $correct_dir ) ) {
			return $correct_dir;
		}

		return $source;
	}
}
