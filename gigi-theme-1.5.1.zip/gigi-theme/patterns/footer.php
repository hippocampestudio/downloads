<?php
/**
 * Title: GIGI - Pied de page (footer)
 * Slug: gigi-theme/footer
 * Categories: gigi
 * Block Types: core/template-part/footer
 * Inserter: false
 */
?>
<!-- wp:group {"tagName":"footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50","right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"backgroundColor":"custom-gigi-gris-fonce","textColor":"custom-gigi-blanc","layout":{"type":"constrained"}} -->
<footer class="wp-block-group has-custom-gigi-blanc-color has-custom-gigi-gris-fonce-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:columns {"align":"wide","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-bottom:var(--wp--preset--spacing--50)"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:image {"width":"180px","sizeSlug":"full","linkDestination":"none","className":"is-style-default"} -->
<figure class="wp-block-image size-full is-style-default" style="width:180px"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo-gigi-evenements.png' ) ); ?>" alt="Gigi Évènements" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"30%"} -->
<div class="wp-block-column" style="flex-basis:30%"><!-- wp:navigation {"overlayMenu":"never","style":{"spacing":{"blockGap":"0"}},"fontSize":"large","layout":{"type":"flex","orientation":"vertical"}} -->
<!-- wp:navigation-link {"label":"Gigi Évènements","url":"https://gigi-evenements.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"FB Food","url":"https://fb-food.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"FB Le Bar","url":"https://fb-lebar.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"La Guinguette","url":"https://la-guinguette-ephemere.fr","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"30%"} -->
<div class="wp-block-column" style="flex-basis:30%"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Gigi événements</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"custom-1"} -->
<p class="has-custom-1-font-size">17 allée des vignes<br>Montamisé, France</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"custom-1"} -->
<p class="has-custom-1-font-size">06 00 00 00 00</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"custom-1"} -->
<p class="has-custom-1-font-size">contact@gigi-evenements.fr</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></footer>
<!-- /wp:group -->