<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     1.7.0
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '1.7.0' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/* ================================================================
   1. Block registration
   ================================================================ */

add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}
	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/* ================================================================
   2. Strate — frontend post-processing

   The block is STATIC: save.js generates the HTML which WP stores
   in post_content.  This filter runs AFTER WordPress has applied
   block-support styles (color, spacing) at priority 10.

   It does two things:
   A) Injects CSS custom properties from block attributes so that
      the stylesheet can read them (covers blocks saved before the
      CSS-variable logic was added).
   B) Redirects padding from the wrapper to the content column via
      CSS variables, then zeroes the wrapper padding so the image
      always touches the strate edges.
   ================================================================ */

add_filter( 'render_block', 'gigi_strate_filter_frontend', 20, 2 );

function gigi_strate_filter_frontend( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/strate' ) {
		return $content;
	}

	$attrs = $block['attrs'] ?? [];

	$p = new WP_HTML_Tag_Processor( $content );
	if ( ! $p->next_tag() ) {
		return $content;
	}

	$style = $p->get_attribute( 'style' ) ?? '';

	// A) CSS custom properties from custom attributes.
	$css_vars = gigi_strate_build_css_vars( $attrs );

	// B) Redirect padding → content column.
	$pad_vars = gigi_strate_build_padding_vars( $attrs );
	if ( $pad_vars ) {
		$style = preg_replace(
			'/padding(-top|-right|-bottom|-left)?\s*:\s*[^;]+;?\s*/',
			'',
			$style
		);
		$style = trim( $style, '; ' );
	}

	// C) Assemble final style string.
	$parts     = array_filter( [ $css_vars, $pad_vars, $style ] );
	$new_style = implode( ';', $parts );
	if ( $pad_vars ) {
		$new_style .= ';padding:0 !important';
	}

	if ( $new_style ) {
		$p->set_attribute( 'style', $new_style );
	}

	return $p->get_updated_html();
}

/* ================================================================
   3. Strate helpers
   ================================================================ */

/**
 * Build CSS custom properties string from Strate block attributes.
 */
function gigi_strate_build_css_vars( array $attrs ): string {
	$vars = [];

	// Layout ---
	$w = (int) ( $attrs['mediaWidth'] ?? 50 );
	if ( $w !== 50 ) {
		$vars[] = "--gigi-strate-media-width:{$w}%";
	}

	$gap = (int) ( $attrs['columnsGap'] ?? 0 );
	if ( $gap > 0 ) {
		$vars[] = "--gigi-strate-gap:{$gap}px";
	}

	// Image ---
	$px = (int) ( $attrs['imagePositionX'] ?? 50 );
	$py = (int) ( $attrs['imagePositionY'] ?? 50 );
	if ( $px !== 50 || $py !== 50 ) {
		$vars[] = "--gigi-strate-img-pos:{$px}% {$py}%";
	}

	$zoom = (int) ( $attrs['imageZoom'] ?? 100 );
	if ( $zoom !== 100 ) {
		$vars[] = '--gigi-strate-img-zoom:' . round( $zoom / 100, 2 );
	}

	// Button colors ---
	$colors = [
		'buttonBgColor'      => 'btn-bg',
		'buttonTextColor'    => 'btn-color',
		'buttonHoverBgColor' => 'btn-hover-bg',
	];
	foreach ( $colors as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$vars[] = "--gigi-strate-{$css}:{$attrs[ $attr ]}";
		}
	}

	// Typography ---
	$fonts = [
		'titleFontSize'  => 'title-size',
		'textFontSize'   => 'text-size',
		'buttonFontSize' => 'btn-size',
	];
	foreach ( $fonts as $attr => $css ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$val = $attrs[ $attr ];
			if ( preg_match( '/^[a-z-]+$/i', $val ) ) {
				$val = "var(--wp--preset--font-size--{$val})";
			}
			$vars[] = "--gigi-strate-{$css}:{$val}";
		}
	}

	return implode( ';', $vars );
}

/**
 * Convert padding attributes to CSS custom properties for the
 * content column.  Returns empty string if no padding is set.
 */
function gigi_strate_build_padding_vars( array $attrs ): string {
	$padding = $attrs['style']['spacing']['padding'] ?? [];
	if ( empty( $padding ) ) {
		return '';
	}

	$vars = [];
	foreach ( [ 'top', 'right', 'bottom', 'left' ] as $dir ) {
		if ( empty( $padding[ $dir ] ) ) {
			continue;
		}
		$val = $padding[ $dir ];
		if ( str_starts_with( $val, 'var:' ) ) {
			$parts = explode( '|', substr( $val, 4 ) );
			$val   = 'var(--wp--preset--' . implode( '--', $parts ) . ')';
		}
		$vars[] = "--gigi-strate-pad-{$dir}:{$val}";
	}

	return implode( ';', $vars );
}

/* ================================================================
   4. Slider — frontend assets
   ================================================================ */

add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}
	wp_enqueue_style( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.css', [], GIGI_BLOCKS_VERSION );
	wp_enqueue_script( 'gigi-slider', GIGI_BLOCKS_URL . 'assets/slider.js', [], GIGI_BLOCKS_VERSION, true );
	return $content;
}, 10, 2 );

/* ================================================================
   5. Block category
   ================================================================ */

add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
