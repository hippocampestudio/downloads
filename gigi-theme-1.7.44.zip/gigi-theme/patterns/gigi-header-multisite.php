<?php
/**
 * Title: GIGI - Header Multisite
 * Slug: gigi-theme/gigi-header-multisite
 * Categories: gigi
 * Keywords: header, en-tête, navigation, logo, multisite
 * Viewport Width: 1200
 * Description: Référence le template part « En-tête multisite ». Modifier le markup dans Apparence → Éditeur → Template parts → En-tête multisite, ou directement dans parts/header-multisite.html (recommandé pour un déploiement multi-sites).
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header-multisite","theme":"gigi-theme","area":"header"} /-->
