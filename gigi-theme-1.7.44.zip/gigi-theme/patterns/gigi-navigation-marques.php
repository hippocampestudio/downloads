<?php
/**
 * Title: GIGI - Navigation Marques
 * Slug: gigi-theme/gigi-navigation-marques
 * Categories: gigi
 * Keywords: navigation, marques, logos, foodtruck
 * Viewport Width: 1200
 * Description: Référence le template part « Navigation Marques ». Modifiable dans Apparence → Éditeur → Compositions → Général → Navigation Marques. Pour propager aux autres sites : reporter les changements dans parts/navigation-marques.html puis déployer.
 * Inserter: true
 */
?>
<!-- wp:template-part {"slug":"navigation-marques","theme":"gigi-theme","area":"uncategorized"} /-->
