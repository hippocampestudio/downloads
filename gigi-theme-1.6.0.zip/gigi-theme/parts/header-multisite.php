<?php
$logo = esc_url( get_theme_file_uri( 'assets/images/logo-gigi-evenements.png' ) );
$href = esc_url( defined( 'GIGI_HEADER_LOGO_HREF' ) ? GIGI_HEADER_LOGO_HREF : 'https://dev.gigi-evenements.fr' );
?>
<!-- wp:group {"style":{"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"backgroundColor":"custom-gigi-gris-fonce","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-custom-gigi-gris-fonce-background-color has-background" style="padding-right:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)">

		<!-- wp:html -->
		<a href="<?php echo $href; ?>" style="display:block;flex:0 0 auto;width:125px;line-height:0">
			<img src="<?php echo $logo; ?>" alt="Gigi Évènements" width="125" style="width:125px;height:auto;display:block"/>
		</a>
		<!-- /wp:html -->

		<!-- wp:navigation {"textColor":"white","icon":"menu","layout":{"type":"flex","justifyContent":"right"}} -->
		<!-- wp:navigation-link {"label":"Gigi Évènements","url":"https://dev.gigi-evenements.fr","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"FB Food","url":"https://fb-food.fr","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"FB Le Bar","url":"https://fb-lebar.fr","kind":"custom","isTopLevelLink":true} /-->
		<!-- wp:navigation-link {"label":"La Guinguette","url":"https://la-guinguette-ephemere.fr","kind":"custom","isTopLevelLink":true} /-->
		<!-- /wp:navigation -->

	</div>
	<!-- /wp:group -->

</div>
<!-- /wp:group -->
