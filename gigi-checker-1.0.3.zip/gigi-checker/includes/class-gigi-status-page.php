<?php
/**
 * Gigi_Status_Page — page d'état dans l'admin WP (Outils → Gigi Checker).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	public static function register(): void {
		add_management_page(
			'Gigi Checker — État',
			'Gigi Checker',
			'update_plugins',
			'gigi-checker-status',
			[ self::class, 'render' ]
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		$remote   = Gigi_Versions::fetch_remote(); // fetch frais, ignore le cache
		$slugs    = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];

		echo '<div class="wrap">';
		echo '<h1>Gigi Checker — État</h1>';

		// ---- Connexion au repo distant ----------------------------------
		echo '<h2>Connexion à Bitbucket</h2>';
		if ( empty( $remote ) ) {
			echo '<div class="notice notice-error inline"><p>';
			echo '❌ Impossible de récupérer <code>' . esc_html( GIGI_VERSIONS_URL ) . '</code>.<br>';
			echo 'Vérifiez que le serveur autorise les requêtes HTTP sortantes vers Bitbucket.';
			echo '</p></div>';
		} else {
			echo '<div class="notice notice-success inline"><p>';
			echo '✅ <code>' . esc_html( GIGI_VERSIONS_URL ) . '</code> — accessible.';
			echo '</p></div>';
		}

		// ---- Tableau des versions --------------------------------------
		echo '<h2>Versions</h2>';
		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr>';
		echo '<th>Composant</th><th>Installé</th><th>Disponible (Bitbucket)</th><th>État</th>';
		echo '</tr></thead><tbody>';

		foreach ( $slugs as $slug ) {
			$remote_data     = $remote[ $slug ] ?? null;
			$remote_version  = $remote_data['version'] ?? '—';

			if ( 'gigi-theme' === $slug ) {
				$theme           = wp_get_theme( $slug );
				$installed       = $theme->exists() ? $theme->get( 'Version' ) : '(non trouvé)';
				$component_label = $theme->exists() ? $theme->get( 'Name' ) : $slug;
			} else {
				$plugin_path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
				if ( file_exists( $plugin_path ) ) {
					if ( ! function_exists( 'get_plugin_data' ) ) {
						require_once ABSPATH . 'wp-admin/includes/plugin.php';
					}
					$data            = get_plugin_data( $plugin_path );
					$installed       = $data['Version'];
					$component_label = $data['Name'];
				} else {
					$installed       = '(non trouvé)';
					$component_label = $slug;
				}
			}

			if ( '—' === $remote_version ) {
				$status = '⚠️ Absent du versions.json';
				$color  = 'orange';
			} elseif ( '(non trouvé)' === $installed ) {
				$status = '⚠️ Plugin/thème non installé';
				$color  = 'orange';
			} elseif ( version_compare( $installed, $remote_version, '<' ) ) {
				$status = '🔄 Mise à jour disponible';
				$color  = '#0073aa';
			} else {
				$status = '✅ À jour';
				$color  = 'green';
			}

			printf(
				'<tr><td><strong>%s</strong><br><small style="color:#666">%s</small></td><td>%s</td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
				esc_html( $component_label ),
				esc_html( $slug ),
				esc_html( $installed ),
				esc_html( $remote_version ),
				esc_attr( $color ),
				esc_html( $status )
			);
		}

		echo '</tbody></table>';

		// ---- Cache WordPress -------------------------------------------
		echo '<h2>Cache WordPress (update_themes / update_plugins)</h2>';
		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Transient</th><th>Contenu Gigi</th><th>Dernière vérification</th></tr></thead><tbody>';

		// Plugins
		$plugin_keys = [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ];
		foreach ( $plugin_keys as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'response → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'no_update → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = '⚠️ Absent du transient';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i:s', $t_plugins->last_checked ) : '—';
			printf( '<tr><td>update_plugins</td><td><code>%s</code> : %s</td><td>%s</td></tr>',
				esc_html( $slug_short ), esc_html( $info ), esc_html( $last ) );
		}

		// Theme
		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'response → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'no_update → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = '⚠️ Absent du transient';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i:s', $t_themes->last_checked ) : '—';
		printf( '<tr><td>update_themes</td><td><code>gigi-theme</code> : %s</td><td>%s</td></tr>',
			esc_html( $t_info ), esc_html( $last_t ) );

		echo '</tbody></table>';

		// ---- Actions ---------------------------------------------------
		echo '<p style="margin-top:1.5em">';
		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf( '<a href="%s" class="button button-primary">Vider le cache et vérifier</a> ',
			esc_url( $flush_url ) );
		echo '</p>';

		echo '</div>';
	}
}
