<?php
/**
 * Gigi_Versions — récupère et met en cache le fichier versions.json distant.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Versions {

	private const CACHE_KEY = 'gigi_checker_versions';

	public static function get(): array {
		$cached = get_transient( self::CACHE_KEY );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		return self::fetch_remote();
	}

	/**
	 * Récupère le fichier distant en contournant le cache CDN de Bitbucket
	 * (max-age=900) via un paramètre timestamp unique.
	 */
	public static function fetch_remote(): array {
		$url = add_query_arg( 'ts', time(), GIGI_VERSIONS_URL );

		$response = wp_remote_get( $url, [
			'timeout'    => 10,
			'user-agent' => 'GigiChecker/' . GIGI_CHECKER_VERSION . '; ' . home_url(),
			'headers'    => [
				'Cache-Control' => 'no-cache',
				'Pragma'        => 'no-cache',
			],
		] );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $code ) {
			return [];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			return [];
		}

		set_transient( self::CACHE_KEY, $data, GIGI_CHECKER_CACHE_TTL );

		return $data;
	}

	public static function get_for( string $slug ): ?array {
		$versions = self::get();
		return $versions[ $slug ] ?? null;
	}

	public static function flush_cache(): void {
		delete_transient( self::CACHE_KEY );
	}
}
