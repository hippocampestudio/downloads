<?php
/**
 * Title: GIGI - Pied de page multisite
 * Slug: gigi-theme/footer-multisite
 * Categories: gigi
 * Inserter: true
 */
?>
<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"backgroundColor":"custom-gigi-gris-fonce","textColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-color has-custom-gigi-gris-fonce-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"width":"200px","sizeSlug":"full","linkDestination":"none"} -->
			<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo-gigi-evenements.png' ) ); ?>" alt="Gigi Évènements" style="width:200px"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:navigation {"overlayMenu":"never","style":{"spacing":{"blockGap":"var:preset|spacing|20"},"typography":{"fontSize":"20px"}},"fontFamily":"inter","layout":{"type":"flex","orientation":"vertical"}} -->
			<!-- wp:navigation-link {"label":"Gigi Évènements","url":"https://gigi-evenements.fr","kind":"custom","isTopLevelLink":true} /-->
			<!-- wp:navigation-link {"label":"FB Food","url":"https://fb-food.fr","kind":"custom","isTopLevelLink":true} /-->
			<!-- wp:navigation-link {"label":"FB Le Bar","url":"https://fb-lebar.fr","kind":"custom","isTopLevelLink":true} /-->
			<!-- wp:navigation-link {"label":"La Guinguette","url":"https://la-guinguette-ephemere.fr","kind":"custom","isTopLevelLink":true} /-->
			<!-- /wp:navigation -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"typography":{"fontSize":"20px"}}} -->
		<div class="wp-block-column" style="font-size:20px">
			<!-- wp:heading {"fontSize":"small"} -->
			<h2 class="wp-block-heading has-small-font-size">Gigi évènement</h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"fontSize":"custom-1"} -->
			<p class="has-custom-1-font-size">17 allée des Vignes</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"fontSize":"custom-1"} -->
			<p class="has-custom-1-font-size">MONTAMISÉ, FRANCE</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"fontSize":"custom-1"} -->
			<p class="has-custom-1-font-size">06 00 00 00 00</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"fontSize":"custom-1"} -->
			<p class="has-custom-1-font-size">contact@gigi-evenements.fr</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
