<?php
/**
 * Gigi_Status_Page — admin Gigi Checker (onglets, langage non technique).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	public const MENU_SLUG = 'gigi-checker-status';

	private const TABS = [
		'overview' => 'Vue d’ensemble',
		'sites'    => 'Sites',
		'layout'   => 'En-tête & pied de page',
		'settings' => 'Réglages',
	];

	public static function register(): void {
		// Position 81 = juste sous Réglages (80).
		add_menu_page(
			'GIGI',
			'GIGI',
			'update_plugins',
			self::MENU_SLUG,
			[ self::class, 'render' ],
			self::menu_icon(),
			81
		);

		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
	}

	/**
	 * Icône foodtruck (SVG monochrome pour la sidebar WP).
	 */
	private static function menu_icon(): string {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">'
			. '<path fill="black" d="M3 11.5h15.5a2.5 2.5 0 0 1 2.5 2.5v3a1 1 0 0 1-1 1h-1.05a2.5 2.5 0 0 1-4.9 0H10.95a2.5 2.5 0 0 1-4.9 0H4a1 1 0 0 1-1-1v-5.5Z"/>'
			. '<path fill="black" d="M3 8.5h9.5V6.2A2.2 2.2 0 0 1 14.7 4H18v4.5h-2"/>'
			. '<circle fill="black" cx="8.5" cy="18" r="1.35"/>'
			. '<circle fill="black" cx="17" cy="18" r="1.35"/>'
			. '<path fill="black" d="M14.2 7.2h2.3V5.5h-1.5a.8.8 0 0 0-.8.8v.9Z"/>'
			. '<path fill="black" d="M5.2 9.2h2v1.6h-2zm3.1 0h2v1.6h-2z"/>'
			. '</svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	public static function enqueue_assets( string $hook ): void {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		$base = plugin_dir_url( GIGI_CHECKER_FILE ) . 'assets/';
		wp_enqueue_style( 'gigi-fleet-admin', $base . 'fleet-admin.css', [], GIGI_CHECKER_VERSION );
		wp_enqueue_script( 'gigi-fleet-admin', $base . 'fleet-admin.js', [], GIGI_CHECKER_VERSION, true );
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		$tab                = self::current_tab();
		$fleet_sync_results = null;
		$notices            = [];

		self::handle_posts( $tab, $fleet_sync_results, $notices );

		$remote     = Gigi_Versions::fetch_remote();
		$last_error = Gigi_Versions::get_last_error();
		$versions   = self::collect_versions( $remote );
		$is_master  = Gigi_Fleet::is_master();
		$layout     = Gigi_Layout_Sync::get_status();
		$layout_local = 0;
		foreach ( $layout as $item ) {
			if ( ! empty( $item['customized'] ) ) {
				$layout_local++;
			}
		}

		echo '<div class="wrap gigi-admin">';
		echo '<h1>GIGI</h1>';
		echo '<p class="gigi-admin-intro">Gérez les mises à jour du thème et des plugins Gigi, la liste des sites, et les éléments d’en-tête / pied de page partagés.</p>';

		foreach ( $notices as $notice ) {
			printf(
				'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
				esc_attr( $notice['type'] ),
				wp_kses_post( $notice['message'] )
			);
		}

		self::render_tabs( $tab );

		echo '<div class="gigi-admin-panel">';
		switch ( $tab ) {
			case 'sites':
				self::render_tab_sites( $fleet_sync_results );
				break;
			case 'layout':
				self::render_tab_layout( $layout, $fleet_sync_results );
				break;
			case 'settings':
				self::render_tab_settings( $remote, $last_error );
				break;
			default:
				self::render_tab_overview( $remote, $last_error, $versions, $is_master, $layout_local );
				break;
		}
		echo '</div>';
		echo '</div>';
	}

	private static function current_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		return isset( self::TABS[ $tab ] ) ? $tab : 'overview';
	}

	private static function tab_url( string $tab ): string {
		return add_query_arg(
			[
				'page' => self::MENU_SLUG,
				'tab'  => $tab,
			],
			admin_url( 'admin.php' )
		);
	}

	private static function render_tabs( string $current ): void {
		echo '<nav class="nav-tab-wrapper gigi-admin-tabs" aria-label="Sections Gigi Checker">';
		foreach ( self::TABS as $slug => $label ) {
			printf(
				'<a href="%s" class="nav-tab%s">%s</a>',
				esc_url( self::tab_url( $slug ) ),
				$current === $slug ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</nav>';
	}

	/**
	 * @param array|null $fleet_sync_results
	 * @param list<array{type: string, message: string}> $notices
	 */
	private static function handle_posts( string $tab, ?array &$fleet_sync_results, array &$notices ): void {
		if ( empty( $_POST['_wpnonce'] ) ) {
			return;
		}

		// Secret.
		if (
			isset( $_POST['gigi_sync_secret'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_sync_secret' )
		) {
			update_option(
				Gigi_Remote_Sync::get_secret_option_name(),
				sanitize_text_field( wp_unslash( $_POST['gigi_sync_secret'] ) )
			);
			$notices[] = [
				'type'    => 'success',
				'message' => 'Clé de synchronisation enregistrée. Utilisez la même clé sur tous les sites.',
			];
		}

		// Flotte.
		if (
			isset( $_POST['gigi_save_fleet'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_fleet' )
		) {
			$is_master = ! empty( $_POST['gigi_is_master'] );
			Gigi_Fleet::set_is_master( $is_master );
			if ( $is_master && isset( $_POST['gigi_fleet_sites'] ) && is_array( $_POST['gigi_fleet_sites'] ) ) {
				$sites = [];
				foreach ( wp_unslash( $_POST['gigi_fleet_sites'] ) as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$sites[] = [
						'label' => sanitize_text_field( (string) ( $row['label'] ?? '' ) ),
						'url'   => sanitize_text_field( (string) ( $row['url'] ?? '' ) ),
					];
				}
				Gigi_Fleet::save_sites( $sites );
			}
			$notices[] = [
				'type'    => 'success',
				'message' => 'Liste des sites enregistrée.',
			];
		}

		// Sync flotte.
		if (
			isset( $_POST['gigi_fleet_sync'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_fleet_sync' )
		) {
			if ( ! Gigi_Fleet::is_master() ) {
				$notices[] = [
					'type'    => 'error',
					'message' => 'Seul le site principal peut mettre à jour tous les sites.',
				];
			} else {
				$local_request      = new WP_REST_Request( 'POST', '/gigi-checker/v1/sync' );
				$local_response     = Gigi_Remote_Sync::sync_and_apply( $local_request );
				$fleet_sync_results = [
					'local'  => $local_response->get_data(),
					'remote' => Gigi_Fleet::sync_all_remote(),
				];
				$notices[] = [
					'type'    => 'success',
					'message' => 'Mise à jour de tous les sites terminée — voir le détail ci-dessous.',
				];
			}
		}

		// Layout : tout remettre à l’usine (ce site).
		if (
			isset( $_POST['gigi_layout_sync'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_sync' )
		) {
			$report = Gigi_Layout_Sync::sync_all();
			$reset  = count( $report['reset'] );
			$repaired = count( $report['repaired_nav_marques'] ?? [] );
			$migrated = count( $report['migrated_nav_marques'] ?? [] );
			$parts = [];
			if ( $reset > 0 ) {
				$parts[] = sprintf(
					'%d élément(s) revenus à l’usine (%s)',
					$reset,
					esc_html( implode( ', ', $report['reset'] ) )
				);
			}
			if ( $repaired > 0 ) {
				$titles = array_map(
					static fn( $row ) => $row['title'] ?? ( '#' . $row['id'] ),
					$report['repaired_nav_marques']
				);
				$parts[] = sprintf(
					'%d page(s) restaurée(s) depuis une révision (%s)',
					$repaired,
					esc_html( implode( ', ', $titles ) )
				);
			}
			if ( $migrated > 0 ) {
				$titles = array_map(
					static fn( $row ) => $row['title'] ?? ( '#' . $row['id'] ),
					$report['migrated_nav_marques']
				);
				$parts[] = sprintf(
					'%d page(s) : Navigation Marques convertie en template part (%s)',
					$migrated,
					esc_html( implode( ', ', $titles ) )
				);
			}
			if ( $parts ) {
				$notices[] = [
					'type'    => 'success',
					'message' => 'Sur <strong>ce site</strong> : ' . implode( ' — ', $parts ) . '.',
				];
			} else {
				$notices[] = [
					'type'    => 'info',
					'message' => 'Rien à corriger sur ce site : déjà à l’état d’usine.',
				];
			}
		}

		// Layout : reset unitaire.
		if (
			isset( $_POST['gigi_layout_reset_slug'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_reset_one' )
		) {
			$slug   = sanitize_key( wp_unslash( (string) $_POST['gigi_layout_reset_slug'] ) );
			$result = Gigi_Layout_Sync::reset_to_factory( $slug );
			$labels = [];
			foreach ( Gigi_Layout_Sync::get_status() as $item ) {
				$labels[ $item['slug'] ] = $item['label'];
			}
			$label = $labels[ $slug ] ?? $slug;

			if ( 'reset' === $result ) {
				$notices[] = [
					'type'    => 'success',
					'message' => sprintf( '« %s » est revenu à l’état d’usine sur <strong>ce site</strong>.', esc_html( $label ) ),
				];
			} elseif ( 'already_synced' === $result ) {
				$notices[] = [
					'type'    => 'info',
					'message' => sprintf( '« %s » était déjà à l’état d’usine.', esc_html( $label ) ),
				];
			} else {
				$notices[] = [
					'type'    => 'error',
					'message' => sprintf( 'Impossible de réinitialiser « %s » (%s).', esc_html( $label ), esc_html( $result ) ),
				];
			}
		}

		// Layout : publier vers la flotte (maître).
		if (
			isset( $_POST['gigi_layout_publish'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_publish' )
		) {
			if ( ! Gigi_Fleet::is_master() ) {
				$notices[] = [
					'type'    => 'error',
					'message' => 'Seul le site principal peut publier le layout vers les autres sites.',
				];
			} else {
				$publish = Gigi_Layout_Publish::publish_to_fleet();
				$fleet_sync_results = [
					'layout_publish' => $publish,
				];
				if ( ! empty( $publish['local_errors'] ) && empty( $publish['remote'] ) ) {
					$notices[] = [
						'type'    => 'error',
						'message' => esc_html( implode( ' ', $publish['local_errors'] ) ),
					];
				} elseif ( ! empty( $publish['ok'] ) ) {
					$notices[] = [
						'type'    => 'success',
						'message' => sprintf(
							'Layout publié vers la flotte (%s).',
							esc_html( implode( ', ', $publish['parts'] ) )
						),
					];
				} else {
					$notices[] = [
						'type'    => 'warning',
						'message' => 'Publication terminée avec des erreurs — voir le détail ci-dessous.',
					];
				}
			}
		}

		// URL versions.
		if (
			isset( $_POST['gigi_versions_url'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_url' )
		) {
			Gigi_Versions::save_url( sanitize_url( trim( wp_unslash( $_POST['gigi_versions_url'] ) ) ) );
			Gigi_Versions::flush_cache();
			$notices[] = [
				'type'    => 'success',
				'message' => 'Source des versions enregistrée. Le cache a été vidé.',
			];
		}
	}

	/**
	 * @return list<array{slug: string, label: string, installed: string, available: string, status: string, color: string, outdated: bool}>
	 */
	private static function collect_versions( ?array $remote ): array {
		$slugs  = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];
		$labels = [
			'gigi-theme'   => 'Thème Gigi',
			'gigi-checker' => 'Gigi Checker',
			'gigi-blocks'  => 'Gigi Blocks',
		];
		$rows = [];

		foreach ( $slugs as $slug ) {
			$available = is_array( $remote ) ? ( $remote[ $slug ]['version'] ?? '—' ) : '—';

			if ( 'gigi-theme' === $slug ) {
				$theme     = wp_get_theme( $slug );
				$installed = $theme->exists() ? (string) $theme->get( 'Version' ) : 'Non installé';
			} else {
				$path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
				if ( file_exists( $path ) ) {
					if ( ! function_exists( 'get_plugin_data' ) ) {
						require_once ABSPATH . 'wp-admin/includes/plugin.php';
					}
					$data      = get_plugin_data( $path );
					$installed = (string) ( $data['Version'] ?? '?' );
				} else {
					$installed = 'Non installé';
				}
			}

			$outdated = false;
			if ( '—' === $available ) {
				$status = 'Info indisponible';
				$color  = 'orange';
			} elseif ( 'Non installé' === $installed ) {
				$status = 'Non installé';
				$color  = 'orange';
			} elseif ( version_compare( $installed, $available, '<' ) ) {
				$status   = 'Mise à jour disponible';
				$color    = '#0073aa';
				$outdated = true;
			} else {
				$status = 'À jour';
				$color  = 'green';
			}

			$rows[] = [
				'slug'      => $slug,
				'label'     => $labels[ $slug ],
				'installed' => $installed,
				'available' => $available,
				'status'    => $status,
				'color'     => $color,
				'outdated'  => $outdated,
			];
		}

		return $rows;
	}

	private static function render_tab_overview( ?array $remote, ?array $last_error, array $versions, bool $is_master, int $layout_local ): void {
		$outdated = array_filter( $versions, static fn( $row ) => ! empty( $row['outdated'] ) );
		$secret   = (string) get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		$fleet    = Gigi_Fleet::get_sites();

		echo '<div class="gigi-cards">';

		echo '<div class="gigi-card">';
		echo '<h2>Ce site</h2>';
		if ( $is_master ) {
			echo '<p><span class="gigi-fleet-badge gigi-fleet-badge--master">Site principal</span></p>';
			echo '<p>Vous pouvez gérer la liste des sites et lancer une mise à jour sur toute la flotte.</p>';
		} else {
			echo '<p><span class="gigi-fleet-badge">Site secondaire</span></p>';
			echo '<p>Les mises à jour groupées se lancent depuis le site principal. Ici, vous gérez surtout ce site.</p>';
		}
		printf(
			'<p><a class="button" href="%s">Gérer les sites</a></p>',
			esc_url( self::tab_url( 'sites' ) )
		);
		echo '</div>';

		echo '<div class="gigi-card">';
		echo '<h2>Mises à jour</h2>';
		if ( empty( $remote ) ) {
			echo '<p class="gigi-status-bad">Impossible de vérifier les versions en ligne pour le moment.</p>';
		} elseif ( $outdated ) {
			printf(
				'<p class="gigi-status-warn"><strong>%d</strong> composant(s) à mettre à jour.</p>',
				count( $outdated )
			);
		} else {
			echo '<p class="gigi-status-ok"><strong>Tout est à jour</strong> sur ce site.</p>';
		}

		echo '<table class="widefat striped gigi-compact-table"><thead><tr><th>Composant</th><th>Installé</th><th>État</th></tr></thead><tbody>';
		foreach ( $versions as $row ) {
			printf(
				'<tr><td>%s</td><td>%s</td><td style="color:%s">%s</td></tr>',
				esc_html( $row['label'] ),
				esc_html( $row['installed'] ),
				esc_attr( $row['color'] ),
				esc_html( $row['status'] )
			);
		}
		echo '</tbody></table>';

		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf(
			'<p style="margin-top:12px"><a class="button button-primary" href="%s">Vérifier les mises à jour maintenant</a></p>',
			esc_url( $flush_url )
		);
		if ( $is_master && count( $fleet ) > 1 && $secret !== '' ) {
			printf(
				'<p><a class="button" href="%s">Mettre à jour tous les sites…</a></p>',
				esc_url( self::tab_url( 'sites' ) )
			);
		}
		echo '</div>';

		echo '<div class="gigi-card">';
		echo '<h2>En-tête & pied de page</h2>';
		if ( $layout_local > 0 ) {
			printf(
				'<p class="gigi-status-warn">Sur <strong>ce site</strong>, <strong>%d</strong> élément(s) ont été modifiés dans l’éditeur et ne suivent plus le thème commun.</p>',
				$layout_local
			);
		} else {
			echo '<p class="gigi-status-ok">Sur ce site, l’en-tête et le pied de page utilisent la version du thème.</p>';
		}
		printf(
			'<p><a class="button" href="%s">Voir le détail</a></p>',
			esc_url( self::tab_url( 'layout' ) )
		);
		echo '</div>';

		echo '</div>'; // .gigi-cards

		if ( $secret === '' ) {
			echo '<div class="notice notice-warning inline"><p>';
			echo 'Pour pouvoir mettre à jour les autres sites depuis le site principal, définissez une <strong>clé de synchronisation</strong> identique partout. ';
			printf( '<a href="%s">Configurer</a>', esc_url( self::tab_url( 'sites' ) ) );
			echo '</p></div>';
		}

		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			echo 'La vérification des versions en ligne a échoué. ';
			printf( '<a href="%s">Voir les réglages</a>', esc_url( self::tab_url( 'settings' ) ) );
			echo '</p></div>';
		}
	}

	private static function render_tab_sites( ?array $fleet_sync_results ): void {
		$is_master     = Gigi_Fleet::is_master();
		$fleet_sites   = Gigi_Fleet::get_sites();
		$editor_sites  = Gigi_Fleet::get_sites_for_editor();
		$current_url   = Gigi_Fleet::get_current_site_url();
		$current_label = wp_parse_url( home_url(), PHP_URL_HOST );
		$current_label = is_string( $current_label ) ? $current_label : 'Ce site';
		$sync_secret   = (string) get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );

		echo '<h2>Clé de synchronisation</h2>';
		echo '<p>Mot de passe partagé entre tous les sites. Il permet au site principal de leur demander une mise à jour. '
			. '<strong>Même valeur partout</strong> (site principal et sites secondaires).</p>';
		echo '<form method="post" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
		wp_nonce_field( 'gigi_save_sync_secret' );
		echo '<input type="password" name="gigi_sync_secret" value="' . esc_attr( $sync_secret ) . '" class="regular-text" style="width:280px" placeholder="Clé partagée" autocomplete="new-password"> ';
		echo '<button type="submit" class="button button-primary">Enregistrer la clé</button>';
		echo '</form>';

		echo '<h2 style="margin-top:2em">Liste des sites</h2>';
		echo '<div class="gigi-fleet-box">';
		echo '<p>Le <strong>site principal</strong> détient la liste et peut tout mettre à jour d’un clic. '
			. 'Les autres sites n’ont besoin que de la clé ci-dessus.</p>';

		echo '<form method="post" id="gigi-fleet-form" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
		wp_nonce_field( 'gigi_save_fleet' );
		echo '<input type="hidden" name="gigi_save_fleet" value="1">';

		echo '<label class="gigi-fleet-master-toggle">';
		echo '<input type="checkbox" name="gigi_is_master" id="gigi_is_master" value="1"' . checked( $is_master, true, false ) . '>';
		echo '<span><strong>Ce site est le site principal</strong>';
		echo '<span class="description">À cocher sur un seul site (souvent gigi-evenements.fr).</span></span>';
		echo '</label>';

		printf( '<div id="gigi-fleet-master-panel"%s>', $is_master ? '' : ' hidden' );

		echo '<table class="widefat striped gigi-fleet-table"><thead><tr>';
		echo '<th class="gigi-fleet-col-label">Nom</th>';
		echo '<th class="gigi-fleet-col-url">Adresse du site</th>';
		echo '<th class="gigi-fleet-col-role">Rôle</th>';
		echo '<th class="gigi-fleet-col-actions"><span class="screen-reader-text">Actions</span></th>';
		echo '</tr></thead>';
		printf(
			'<tbody id="gigi-fleet-rows" data-current-url="%s" data-current-label="%s">',
			esc_attr( $current_url ),
			esc_attr( $current_label )
		);

		foreach ( $editor_sites as $i => $site ) {
			$is_current = Gigi_Fleet::urls_match( $site['url'], $current_url );
			printf( '<tr class="gigi-fleet-row%s">', $is_current ? ' gigi-fleet-row--current' : '' );
			printf(
				'<td><input type="text" class="regular-text" data-name="label" name="gigi_fleet_sites[%d][label]" value="%s" placeholder="Ex. Gigi Événements"></td>',
				(int) $i,
				esc_attr( $site['label'] )
			);
			printf(
				'<td><input type="url" class="regular-text" data-name="url" name="gigi_fleet_sites[%d][url]" value="%s" placeholder="https://www.exemple.fr"></td>',
				(int) $i,
				esc_attr( $site['url'] )
			);
			echo '<td class="gigi-fleet-role">';
			echo $is_current
				? '<span class="gigi-fleet-badge gigi-fleet-badge--master">Ce site</span>'
				: '<span class="gigi-fleet-badge">Autre site</span>';
			echo '</td>';
			echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<div class="gigi-fleet-actions">';
		echo '<button type="button" class="button" id="gigi-fleet-add">+ Ajouter un site</button>';
		echo '<button type="button" class="button" id="gigi-fleet-add-current">Ajouter ce site</button>';
		echo '</div>';
		echo '<p class="description">Incluez ce site dans la liste. Son adresse doit correspondre exactement à l’URL WordPress (avec ou sans www).</p>';
		echo '</div>';

		if ( ! $is_master ) {
			echo '<p class="gigi-fleet-satellite-note">Ce site est un <strong>site secondaire</strong>. La liste se configure sur le site principal.</p>';
		}

		echo '<div class="gigi-fleet-save-row"><button type="submit" class="button button-primary">Enregistrer</button></div>';
		echo '</form>';

		echo '<template id="gigi-fleet-row-template">';
		echo '<tr class="gigi-fleet-row">';
		echo '<td><input type="text" class="regular-text" data-name="label" value="" placeholder="Ex. Gigi Événements"></td>';
		echo '<td><input type="url" class="regular-text" data-name="url" value="" placeholder="https://www.exemple.fr"></td>';
		echo '<td class="gigi-fleet-role"><span class="gigi-fleet-badge">Autre site</span></td>';
		echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
		echo '</tr></template>';
		echo '</div>';

		if ( $is_master ) {
			echo '<h2>Mettre à jour tous les sites</h2>';
			if ( '' === $sync_secret ) {
				echo '<div class="notice notice-warning inline"><p>Enregistrez d’abord une clé de synchronisation (en haut de cette page), sur <strong>tous</strong> les sites.</p></div>';
			} elseif ( empty( $fleet_sites ) ) {
				echo '<div class="notice notice-warning inline"><p>Enregistrez d’abord la liste des sites.</p></div>';
			} else {
				$remote_count = count( Gigi_Fleet::get_remote_sites() );
				echo '<p>Installe les mises à jour Gigi sur <strong>ce site</strong>, puis sur chaque autre site de la liste.</p>';
				echo '<form method="post" action="' . esc_url( self::tab_url( 'sites' ) ) . '">';
				wp_nonce_field( 'gigi_fleet_sync' );
				echo '<input type="hidden" name="gigi_fleet_sync" value="1">';
				printf(
					'<button type="submit" class="button button-primary button-hero">Mettre à jour toute la flotte (%d autre%s site%s)</button>',
					$remote_count,
					1 === $remote_count ? '' : 's',
					1 === $remote_count ? '' : 's'
				);
				echo '</form>';
			}
		}

		if ( is_array( $fleet_sync_results ) ) {
			echo '<h3>Résultat</h3>';
			$local = $fleet_sync_results['local'] ?? [];
			printf(
				'<p><strong>Ce site :</strong> %s</p>',
				esc_html( is_array( $local ) ? (string) ( $local['message'] ?? '' ) : '' )
			);
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Site</th><th>Résultat</th></tr></thead><tbody>';
			foreach ( $fleet_sync_results['remote'] ?? [] as $row ) {
				if ( ! empty( $row['error'] ) && '' === ( $row['url'] ?? '' ) ) {
					printf( '<tr><td colspan="2" style="color:#d63638">%s</td></tr>', esc_html( $row['error'] ) );
					continue;
				}
				$ok  = ! empty( $row['ok'] );
				$msg = $row['error'] ?? '';
				if ( ! $msg && is_array( $row['body'] ?? null ) ) {
					$msg = (string) ( $row['body']['message'] ?? '' );
				} elseif ( ! $msg && is_string( $row['body'] ?? null ) ) {
					$msg = $row['body'];
				}
				printf(
					'<tr><td><strong>%s</strong><br><small>%s</small></td><td style="color:%s">%s %s</td></tr>',
					esc_html( $row['label'] ?? '' ),
					esc_html( $row['url'] ?? '' ),
					$ok ? 'green' : '#d63638',
					$ok ? 'OK' : 'Échec',
					esc_html( (string) $msg )
				);
			}
			echo '</tbody></table>';
		}
	}

	/**
	 * @param array<string, array{slug: string, label: string, source: string, customized: bool}> $layout
	 * @param array|null $fleet_sync_results
	 */
	private static function render_tab_layout( array $layout, ?array $fleet_sync_results = null ): void {
		$is_master = Gigi_Fleet::is_master();
		$last_pull = get_option( Gigi_Layout_Pull::OPTION_LAST_PULL, null );
		$last_pub  = get_option( Gigi_Layout_Publish::OPTION_LAST_PUBLISH, null );

		echo '<h2>En-tête, pied de page et navigation</h2>';
		echo '<div class="gigi-callout">';
		echo '<p><strong>Deux couches :</strong></p>';
		echo '<ul style="margin-left:1.2em">';
		echo '<li><strong>Usine</strong> — fichiers du thème (<code>parts/*.html</code>). Jamais modifiés par l’éditeur.</li>';
		echo '<li><strong>Live</strong> — copie en base si vous éditez dans Apparence → Éditeur (sur ce site).</li>';
		echo '</ul>';
		if ( $is_master ) {
			echo '<p>Sur le <strong>site principal</strong>, vous pouvez publier le layout live vers les autres sites.</p>';
		} else {
			echo '<p>Ce site reçoit le layout publié depuis le site principal. Vous pouvez toujours revenir à l’usine localement.</p>';
		}
		echo '</div>';

		if ( ! $is_master && is_array( $last_pull ) && ! empty( $last_pull['at'] ) ) {
			printf(
				'<p class="description">Dernier layout reçu : <strong>%s</strong> depuis %s (%s).</p>',
				esc_html( (string) $last_pull['at'] ),
				esc_html( (string) ( $last_pull['source'] ?? '—' ) ),
				esc_html( implode( ', ', (array) ( $last_pull['parts'] ?? [] ) ) )
			);
		}

		if ( empty( $layout ) ) {
			echo '<p><em>Liste indisponible — mettez à jour le thème et Gigi Checker.</em></p>';
			return;
		}

		echo '<table class="widefat striped" style="max-width:960px">';
		echo '<thead><tr><th>Élément</th><th>Sur ce site</th><th>Action</th></tr></thead><tbody>';
		foreach ( $layout as $item ) {
			if ( ! empty( $item['customized'] ) ) {
				$source = 'Live (modifié dans l’éditeur ou reçu du maître)';
				$color  = '#9a6700';
			} else {
				$source = 'Usine (fichier du thème)';
				$color  = 'green';
			}

			echo '<tr>';
			printf( '<td><strong>%s</strong><br><code>%s</code></td>', esc_html( $item['label'] ), esc_html( $item['slug'] ) );
			printf( '<td style="color:%s">%s</td>', esc_attr( $color ), esc_html( $source ) );
			echo '<td>';
			echo '<form method="post" action="' . esc_url( self::tab_url( 'layout' ) ) . '" style="display:inline">';
			wp_nonce_field( 'gigi_layout_reset_one' );
			printf( '<input type="hidden" name="gigi_layout_reset_slug" value="%s">', esc_attr( $item['slug'] ) );
			echo '<button type="submit" class="button button-small"'
				. ( empty( $item['customized'] ) ? ' disabled' : '' )
				. '>Remettre à l’usine</button>';
			echo '</form>';
			echo '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		if ( $is_master ) {
			$remote_count = count( Gigi_Fleet::get_remote_sites() );
			echo '<div class="gigi-fleet-box" style="margin-top:1.5em">';
			echo '<h3>Publier le layout vers la flotte</h3>';
			echo '<p>Envoie le layout <strong>live actuel de ce site</strong> (éditeur) vers chaque autre site. Cela n’installe pas de mises à jour de thème/plugins.</p>';
			if ( is_array( $last_pub ) && ! empty( $last_pub['at'] ) ) {
				printf(
					'<p class="description">Dernière publication : %s (%s).</p>',
					esc_html( (string) $last_pub['at'] ),
					esc_html( implode( ', ', (array) ( $last_pub['parts'] ?? [] ) ) )
				);
			}
			echo '<form method="post" action="' . esc_url( self::tab_url( 'layout' ) ) . '" onsubmit="return confirm(\'Publier le layout live vers '
				. esc_js( (string) $remote_count )
				. ' autre(s) site(s) ? Cela écrasera leur en-tête / pied de page / navigations partagés.\');">';
			wp_nonce_field( 'gigi_layout_publish' );
			echo '<input type="hidden" name="gigi_layout_publish" value="1">';
			printf(
				'<button type="submit" class="button button-primary"%s>Publier le layout maintenant (%d autre%s site%s)</button>',
				0 === $remote_count ? ' disabled' : '',
				$remote_count,
				1 === $remote_count ? '' : 's',
				1 === $remote_count ? '' : 's'
			);
			echo '</form>';
			if ( 0 === $remote_count ) {
				echo '<p class="description">Ajoutez des sites dans l’onglet <strong>Sites</strong> (et cochez « site maître »).</p>';
			}
			echo '</div>';
		}

		$publish = is_array( $fleet_sync_results ) ? ( $fleet_sync_results['layout_publish'] ?? null ) : null;
		if ( is_array( $publish ) ) {
			echo '<h3>Résultat de la publication</h3>';
			if ( ! empty( $publish['local_errors'] ) ) {
				printf( '<p style="color:#d63638">%s</p>', esc_html( implode( ' ', $publish['local_errors'] ) ) );
			}
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Site</th><th>Résultat</th></tr></thead><tbody>';
			foreach ( $publish['remote'] ?? [] as $row ) {
				$ok  = ! empty( $row['ok'] );
				$msg = $row['error'] ?? '';
				if ( ! $msg && is_array( $row['body'] ?? null ) ) {
					$msg = (string) ( $row['body']['message'] ?? '' );
					if ( ! empty( $row['body']['errors'] ) && is_array( $row['body']['errors'] ) ) {
						$msg .= ' — ' . implode( ', ', $row['body']['errors'] );
					}
				} elseif ( ! $msg && is_string( $row['body'] ?? null ) ) {
					$msg = $row['body'];
				}
				printf(
					'<tr><td><strong>%s</strong><br><small>%s</small></td><td style="color:%s">%s %s</td></tr>',
					esc_html( $row['label'] ?? '' ),
					esc_html( $row['url'] ?? '' ),
					$ok ? 'green' : '#d63638',
					$ok ? 'OK' : 'Échec',
					esc_html( (string) $msg )
				);
			}
			echo '</tbody></table>';
		}

		echo '<hr style="margin:2em 0">';
		echo '<h3>Secours</h3>';
		echo '<form method="post" action="' . esc_url( self::tab_url( 'layout' ) ) . '" style="margin-top:0.5em" onsubmit="return confirm(\'Remettre TOUS les éléments à l’usine sur ce site ?\');">';
		wp_nonce_field( 'gigi_layout_sync' );
		echo '<input type="hidden" name="gigi_layout_sync" value="1">';
		echo '<button type="submit" class="button">Tout remettre à l’usine sur ce site</button>';
		echo '<p class="description">Efface toutes les copies live locales et revient aux fichiers du thème. Utile en urgence. N’affecte pas les autres sites.</p>';
		echo '</form>';

		$copies = Gigi_Layout_Sync::count_navigation_marques_copies();
		if ( $copies > 0 ) {
			printf(
				'<div class="notice notice-warning inline" style="margin-top:1em"><p><strong>%d</strong> page(s) utilisent encore l’ancienne Navigation Marques (copie figée). « Tout remettre à l’usine » les convertit aussi vers le template part.</p></div>',
				$copies
			);
		}
	}

	private static function render_tab_settings( ?array $remote, ?array $last_error ): void {
		$current_url = Gigi_Versions::get_url();

		echo '<h2>Source des versions</h2>';
		echo '<p>Adresse utilisée pour savoir quelles versions du thème et des plugins sont disponibles. En général, laissez la valeur par défaut.</p>';

		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			printf( 'Dernière erreur : %s', esc_html( $last_error['message'] ) );
			echo '</p></div>';
		} elseif ( ! empty( $remote ) ) {
			echo '<div class="notice notice-success inline"><p>Connexion à la source des versions : OK.</p></div>';
		}

		echo '<form method="post" action="' . esc_url( self::tab_url( 'settings' ) ) . '">';
		wp_nonce_field( 'gigi_save_url' );
		printf(
			'<input type="url" name="gigi_versions_url" value="%s" class="regular-text" style="width:100%%;max-width:560px">',
			esc_attr( $current_url )
		);
		echo ' <button type="submit" class="button button-primary">Enregistrer</button>';
		echo '</form>';
		echo '<p class="description">Défaut : Bitbucket, avec secours GitHub. Évitez une URL jsDelivr pour ce fichier (cache trop long).</p>';

		echo '<h2 style="margin-top:2em">Diagnostic (avancé)</h2>';
		echo '<p class="description">Réservé au dépannage. Utile si une mise à jour ne s’affiche pas.</p>';

		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Type</th><th>Info Gigi</th><th>Dernière vérif.</th></tr></thead><tbody>';

		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'MAJ → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'À jour → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = 'Absent du cache';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i', $t_plugins->last_checked ) : '—';
			printf(
				'<tr><td>Plugin %s</td><td>%s</td><td>%s</td></tr>',
				esc_html( $slug_short ),
				esc_html( $info ),
				esc_html( $last )
			);
		}

		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'MAJ → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'À jour → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = 'Absent du cache';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i', $t_themes->last_checked ) : '—';
		printf( '<tr><td>Thème</td><td>%s</td><td>%s</td></tr>', esc_html( $t_info ), esc_html( $last_t ) );
		echo '</tbody></table>';

		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf(
			'<p style="margin-top:1em"><a class="button" href="%s">Vider le cache et revérifier</a></p>',
			esc_url( $flush_url )
		);
	}
}
