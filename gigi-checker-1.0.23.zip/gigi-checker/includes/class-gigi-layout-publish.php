<?php
/**
 * Gigi_Layout_Publish — exporte le layout live du maître et le pousse vers la flotte.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Layout_Publish {

	public const OPTION_LAST_PUBLISH = 'gigi_layout_last_publish';

	/**
	 * Contenu live de chaque part synchronisé (DB custom si présente, sinon fichier thème).
	 *
	 * Les menus `core/navigation` avec un `ref` (entité wp_navigation locale) sont
	 * convertis en liens inline avant envoi — sinon les satellites affichent la
	 * liste de toutes les pages (fallback WP).
	 *
	 * @return array{parts: array<string, array{title: string, area: string, content: string}>, errors: string[]}
	 */
	public static function export_parts(): array {
		$parts  = [];
		$errors = [];
		$manifest = Gigi_Layout_Sync::get_manifest();

		if ( null === $manifest ) {
			return [
				'parts'  => [],
				'errors' => [ 'sync-manifest.php introuvable dans gigi-theme' ],
			];
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}

			$template = Gigi_Layout_Sync::get_template_part_public( $slug );
			if ( ! $template ) {
				$errors[] = $slug . ' (introuvable)';
				continue;
			}

			$content = (string) ( $template->content ?? '' );
			if ( '' === trim( $content ) ) {
				$errors[] = $slug . ' (contenu vide)';
				continue;
			}

			$content = self::inline_navigation_refs( $content );

			if ( self::should_fallback_to_factory( $slug, $content ) ) {
				$factory = Gigi_Layout_Sync::get_factory_content( $slug );
				if ( is_string( $factory ) && '' !== trim( $factory ) ) {
					$content = $factory;
					// Info seulement — le part est quand même publié (version usine).
				} else {
					$errors[] = $slug . ' (menu live invalide et fichier usine introuvable)';
					continue;
				}
			}

			$parts[ $slug ] = [
				'title'   => (string) ( $config['label'] ?? $template->title ?? $slug ),
				'area'    => (string) ( $config['area'] ?? $template->area ?? 'uncategorized' ),
				'content' => $content,
			];
		}

		return [
			'parts'  => $parts,
			'errors' => $errors,
		];
	}

	/**
	 * Remplace <!-- wp:navigation {"ref":123} --> par les liens du wp_navigation local.
	 */
	public static function inline_navigation_refs( string $content ): string {
		if ( ! str_contains( $content, '"ref"' ) || ! str_contains( $content, 'wp:navigation' ) ) {
			return $content;
		}

		$blocks = parse_blocks( $content );
		$blocks = self::expand_navigation_refs_in_blocks( $blocks );

		return serialize_blocks( $blocks );
	}

	/**
	 * @param array<int, array<string, mixed>> $blocks
	 * @return array<int, array<string, mixed>>
	 */
	private static function expand_navigation_refs_in_blocks( array $blocks ): array {
		foreach ( $blocks as &$block ) {
			if ( ( $block['blockName'] ?? '' ) === 'core/navigation' ) {
				$ref = (int) ( $block['attrs']['ref'] ?? 0 );
				if ( $ref > 0 ) {
					$nav_post = get_post( $ref );
					if ( $nav_post instanceof WP_Post && 'wp_navigation' === $nav_post->post_type ) {
						$inner = parse_blocks( (string) $nav_post->post_content );
						$inner = self::expand_navigation_refs_in_blocks( $inner );

						unset( $block['attrs']['ref'] );
						$block['innerBlocks']  = $inner;
						$block['innerHTML']    = '';
						$block['innerContent'] = array_fill( 0, count( $inner ), null );
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$block['innerBlocks'] = self::expand_navigation_refs_in_blocks( $block['innerBlocks'] );
			}
		}
		unset( $block );

		return $blocks;
	}

	/**
	 * Parts header/footer/nav : sans navigation-link après résolution → contenu live inutilisable.
	 */
	private static function should_fallback_to_factory( string $slug, string $content ): bool {
		$nav_slugs = [
			'header-multisite',
			'footer-multisite',
			'header-protected',
			'footer-protected',
			'navigation-mobile',
		];

		if ( ! in_array( $slug, $nav_slugs, true ) ) {
			return false;
		}

		if ( preg_match( '/<!--\s*wp:navigation\s+\{[^}]*"ref"\s*:/', $content ) ) {
			return true;
		}

		if ( str_contains( $content, 'wp:navigation' ) && ! str_contains( $content, 'wp:navigation-link' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Publie le layout live vers tous les satellites.
	 *
	 * @return array{ok: bool, published_at: string, parts: string[], local_errors: string[], remote: list<array{label: string, url: string, ok: bool, http_code: int, body: mixed, error?: string}>}
	 */
	public static function publish_to_fleet(): array {
		$export = self::export_parts();
		$payload = [
			'source'       => Gigi_Fleet::get_current_site_url(),
			'published_at' => gmdate( 'c' ),
			'parts'        => $export['parts'],
		];

		$remote = [];
		if ( empty( $export['parts'] ) ) {
			return [
				'ok'           => false,
				'published_at' => $payload['published_at'],
				'parts'        => [],
				'local_errors' => $export['errors'] ?: [ 'Aucun template part à publier.' ],
				'remote'       => [],
			];
		}

		$secret = get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		if ( ! is_string( $secret ) || '' === $secret ) {
			return [
				'ok'           => false,
				'published_at' => $payload['published_at'],
				'parts'        => array_keys( $export['parts'] ),
				'local_errors' => [ 'Secret de synchronisation vide — définissez-le d’abord.' ],
				'remote'       => [],
			];
		}

		foreach ( Gigi_Fleet::get_remote_sites() as $site ) {
			$remote[] = self::push_to_site( $site['url'], $site['label'], $secret, $payload );
		}

		$all_ok = empty( $export['errors'] );
		foreach ( $remote as $row ) {
			if ( empty( $row['ok'] ) ) {
				$all_ok = false;
				break;
			}
		}

		update_option(
			self::OPTION_LAST_PUBLISH,
			[
				'at'    => $payload['published_at'],
				'parts' => array_keys( $export['parts'] ),
				'ok'    => $all_ok,
			],
			false
		);

		return [
			'ok'           => $all_ok && ! empty( $remote ),
			'published_at' => $payload['published_at'],
			'parts'        => array_keys( $export['parts'] ),
			'local_errors' => $export['errors'],
			'remote'       => $remote,
		];
	}

	/**
	 * @param array{source: string, published_at: string, parts: array<string, array{title: string, area: string, content: string}>} $payload
	 * @return array{label: string, url: string, ok: bool, http_code: int, body: mixed, error?: string}
	 */
	private static function push_to_site( string $url, string $label, string $secret, array $payload ): array {
		$url      = Gigi_Fleet::normalize_url( $url );
		$endpoint = trailingslashit( $url ) . 'wp-json/gigi-checker/v1/layout';
		$result   = Gigi_Fleet::post_json( $endpoint, $secret, $payload );

		if ( ! $result['ok'] && ! in_array( $result['http_code'], [ 200, 401 ], true ) ) {
			$fallback = trailingslashit( $url ) . 'index.php?rest_route=/gigi-checker/v1/layout';
			$result   = Gigi_Fleet::post_json( $fallback, $secret, $payload );
		}

		$result['label'] = $label;
		$result['url']   = $url;

		return $result;
	}
}
