<?php
/**
 * Gigi_Remote_Sync — endpoint REST pour forcer la vérification et appliquer les MAJ à distance.
 * Utilisé en phase de dev pour mettre à jour tous les sites en une commande.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Remote_Sync {

	private const OPTION_SECRET = 'gigi_checker_sync_secret';
	private const REST_NAMESPACE = 'gigi-checker/v1';

	/** Ordre : checker avant blocks. */
	private const GIGI_PLUGINS = [
		'gigi-checker/gigi-checker.php',
		'gigi-blocks/gigi-blocks.php',
	];

	public static function register(): void {
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
	}

	public static function register_routes(): void {
		register_rest_route( self::REST_NAMESPACE, '/sync', [
			'methods'             => 'POST',
			'permission_callback' => [ self::class, 'check_secret' ],
			'callback'            => [ self::class, 'sync_and_apply' ],
		] );
	}

	/**
	 * Vérifie le secret (header X-Gigi-Sync-Secret ou body secret).
	 */
	public static function check_secret( WP_REST_Request $request ): bool {
		$secret = get_option( self::OPTION_SECRET, '' );
		if ( '' === $secret || ! is_string( $secret ) ) {
			return false;
		}

		$provided = $request->get_header( 'X-Gigi-Sync-Secret' );
		if ( '' === $provided ) {
			$body = $request->get_json_params();
			$provided = $body['secret'] ?? $request->get_param( 'secret' ) ?? '';
		}

		return is_string( $provided ) && hash_equals( $secret, $provided );
	}

	/**
	 * Force la vérification des versions puis applique les mises à jour Gigi.
	 */
	public static function sync_and_apply( WP_REST_Request $request ): WP_REST_Response {
		$result = [
			'success'     => true,
			'message'     => '',
			'updated'     => [],
			'activated'   => [],
			'layout_sync' => [],
			'errors'      => [],
		];

		// 1. Vider le cache et récupérer versions.json
		Gigi_Versions::flush_cache();
		$remote = Gigi_Versions::fetch_remote();

		if ( empty( $remote ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message'  => 'Impossible de récupérer versions.json',
				'updated'  => [],
				'activated' => [],
				'errors'   => [ 'fetch_remote' ],
			], 500 );
		}

		// 2. Mettre à jour les transients (même logique que force-check)
		self::update_transients( $remote );

		// 3. Appliquer les mises à jour (thème + plugins)
		// En contexte REST, les includes admin ne sont pas chargés — requis pour l’upgrader.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$was_active = [];
		foreach ( self::GIGI_PLUGINS as $plugin_file ) {
			$was_active[ $plugin_file ] = is_plugin_active( $plugin_file );
		}

		$tp = get_site_transient( 'update_plugins' );
		$tt = get_site_transient( 'update_themes' );

		// Plugins Gigi
		foreach ( self::GIGI_PLUGINS as $plugin_file ) {
			if ( ! isset( $tp->response[ $plugin_file ] ) ) {
				continue;
			}
			$obj = $tp->response[ $plugin_file ];
			if ( empty( $obj->package ) ) {
				continue;
			}
			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$done = $upgrader->upgrade( $plugin_file, [ 'clear_update_cache' => false ] );
			if ( true === $done ) {
				$result['updated'][] = 'plugin:' . $plugin_file;

				$activation = self::ensure_plugin_active( $plugin_file );
				if ( true === $activation ) {
					if ( ! $was_active[ $plugin_file ] ) {
						$result['activated'][] = $plugin_file;
					}
				} else {
					$result['errors'][] = 'activate:' . $plugin_file . ' — ' . $activation;
				}
			} elseif ( is_wp_error( $done ) ) {
				$result['errors'][] = 'plugin:' . $plugin_file . ' — ' . $done->get_error_message();
			}
		}

		// Thème Gigi
		if ( isset( $tt->response['gigi-theme']['package'] ) && '' !== $tt->response['gigi-theme']['package'] ) {
			$upgrader = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
			$done = $upgrader->upgrade( 'gigi-theme', [ 'clear_update_cache' => false ] );
			if ( true === $done ) {
				$result['updated'][] = 'theme:gigi-theme';
			} elseif ( is_wp_error( $done ) ) {
				$result['errors'][] = 'theme:gigi-theme — ' . $done->get_error_message();
			}
		}

		// Migrations pages (nav marques) — sans reset des template parts live.
		$result['layout_sync'] = Gigi_Layout_Sync::after_package_update();

		if ( ! empty( $result['errors'] ) ) {
			$result['success'] = false;
			$result['message'] = implode( ' ; ', $result['errors'] );
		} else {
			$result['message'] = count( $result['updated'] ) > 0
				? 'Mises à jour appliquées : ' . implode( ', ', $result['updated'] )
				: 'Aucune mise à jour à appliquer (déjà à jour).';
		}

		// Vider le cache des mises à jour pour refléter l’état réel
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );

		// Toujours garantir les plugins Gigi actifs (MAJ précédente ou même requête sans le nouveau code chargé).
		self::finalize_gigi_plugins_active( $result );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Met à jour les transients update_plugins et update_themes (copie de la logique admin_init force-check).
	 */
	private static function update_transients( array $remote ): void {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$tp = get_site_transient( 'update_plugins' );
		if ( ! is_object( $tp ) ) {
			$tp = new stdClass();
		}
		if ( ! isset( $tp->response ) ) {
			$tp->response = [];
		}
		if ( ! isset( $tp->no_update ) ) {
			$tp->no_update = [];
		}
		if ( ! isset( $tp->checked ) ) {
			$tp->checked = [];
		}

		foreach ( [
			'gigi-checker/gigi-checker.php' => 'gigi-checker',
			'gigi-blocks/gigi-blocks.php'   => 'gigi-blocks',
		] as $plugin_file => $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $plugin_file;
			if ( ! file_exists( $path ) ) {
				continue;
			}
			$data            = get_plugin_data( $path );
			$current_version = $data['Version'] ?? '0.0.0';
			$r               = $remote[ $slug ] ?? null;
			$tp->checked[ $plugin_file ] = $current_version;

			if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
				unset( $tp->no_update[ $plugin_file ] );
				$tp->response[ $plugin_file ] = (object) [
					'id'           => 'gigi/' . $slug,
					'slug'         => $slug,
					'plugin'       => $plugin_file,
					'new_version'  => $r['version'],
					'url'          => 'https://hippocampe.studio',
					'package'      => $r['zip_url'],
					'icons'        => [],
					'banners'      => [],
					'tested'       => $r['tested']       ?? '6.7',
					'requires_php' => $r['requires_php'] ?? '8.1',
					'requires'     => $r['requires']     ?? '6.4',
				];
			} elseif ( $r ) {
				unset( $tp->response[ $plugin_file ] );
				$tp->no_update[ $plugin_file ] = (object) [
					'id'          => 'gigi/' . $slug,
					'slug'        => $slug,
					'plugin'      => $plugin_file,
					'new_version' => $current_version,
					'url'         => 'https://hippocampe.studio',
					'package'     => '',
					'icons'       => [],
					'banners'     => [],
				];
			}
		}
		set_site_transient( 'update_plugins', $tp );

		$tt = get_site_transient( 'update_themes' );
		if ( ! is_object( $tt ) ) {
			$tt = new stdClass();
		}
		if ( ! isset( $tt->response ) ) {
			$tt->response = [];
		}
		if ( ! isset( $tt->no_update ) ) {
			$tt->no_update = [];
		}
		if ( ! isset( $tt->checked ) ) {
			$tt->checked = [];
		}

		$theme           = wp_get_theme( 'gigi-theme' );
		$current_version = $theme->get( 'Version' );
		$r               = $remote['gigi-theme'] ?? null;
		$tt->checked['gigi-theme'] = $current_version;

		if ( $r && version_compare( $current_version, $r['version'], '<' ) ) {
			unset( $tt->no_update['gigi-theme'] );
			$tt->response['gigi-theme'] = [
				'theme'        => 'gigi-theme',
				'new_version'  => $r['version'],
				'url'          => 'https://hippocampe.studio',
				'package'      => $r['zip_url'],
				'requires'     => $r['requires']     ?? '6.4',
				'requires_php' => $r['requires_php'] ?? '8.1',
			];
		} elseif ( $r ) {
			unset( $tt->response['gigi-theme'] );
			$tt->no_update['gigi-theme'] = [
				'theme'       => 'gigi-theme',
				'new_version' => $current_version,
				'url'         => 'https://hippocampe.studio',
				'package'     => '',
			];
		}
		set_site_transient( 'update_themes', $tt );
	}

	public static function get_secret_option_name(): string {
		return self::OPTION_SECRET;
	}

	/**
	 * Réactive un plugin après MAJ via REST (contexte sans utilisateur admin).
	 *
	 * @return true|string true si actif, sinon message d’erreur.
	 */
	private static function ensure_plugin_active( string $plugin_file ): bool|string {
		if ( is_plugin_active( $plugin_file ) ) {
			return true;
		}

		if ( ! file_exists( WP_PLUGIN_DIR . '/' . $plugin_file ) ) {
			return 'fichier plugin introuvable';
		}

		$prev_user = get_current_user_id();
		$admin_id  = self::get_admin_user_id();
		if ( $admin_id > 0 ) {
			wp_set_current_user( $admin_id );
		}

		$result = activate_plugin( $plugin_file, '', false, true );

		if ( $prev_user > 0 ) {
			wp_set_current_user( $prev_user );
		} else {
			wp_set_current_user( 0 );
		}

		if ( is_wp_error( $result ) ) {
			$active = (array) get_option( 'active_plugins', [] );
			if ( ! in_array( $plugin_file, $active, true ) ) {
				$active[] = $plugin_file;
				sort( $active );
				update_option( 'active_plugins', $active );
			}
			if ( is_plugin_active( $plugin_file ) ) {
				return true;
			}
			return $result->get_error_message();
		}

		return true;
	}

	private static function get_admin_user_id(): int {
		$admins = get_users( [
			'role'   => 'administrator',
			'number' => 1,
			'fields' => 'ID',
		] );
		return ! empty( $admins ) ? (int) $admins[0] : 0;
	}

	/**
	 * Réactive les plugins Gigi si désactivés (ex. après MAJ sur une requête précédente).
	 */
	private static function finalize_gigi_plugins_active( array &$result ): void {
		foreach ( self::GIGI_PLUGINS as $plugin_file ) {
			if ( ! file_exists( WP_PLUGIN_DIR . '/' . $plugin_file ) ) {
				continue;
			}
			if ( is_plugin_active( $plugin_file ) ) {
				continue;
			}
			$activation = self::ensure_plugin_active( $plugin_file );
			if ( true === $activation ) {
				$result['activated'][] = $plugin_file;
			} else {
				$result['errors'][] = 'activate:' . $plugin_file . ' — ' . $activation;
				$result['success']  = false;
			}
		}
	}
}
