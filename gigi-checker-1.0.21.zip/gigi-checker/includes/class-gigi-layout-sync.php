<?php
/**
 * Gigi_Layout_Sync — réapplique les template parts de layout depuis les fichiers du thème.
 *
 * WordPress enregistre en base une copie dès qu’un template part est modifié dans
 * l’éditeur de site. Cette copie masque le fichier du thème, même après une MAJ ZIP.
 * Ce module supprime ces surcharges pour les composants listés dans sync-manifest.php.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Layout_Sync {

	private const THEME_SLUG = 'gigi-theme';

	public static function register(): void {
		add_action( 'upgrader_process_complete', [ self::class, 'on_upgrader_complete' ], 20, 2 );
	}

	/**
	 * @return array{template_parts: array<string, array<string, mixed>>, patterns: array<string, array<string, mixed>>}|null
	 */
	public static function get_manifest(): ?array {
		$path = get_theme_root() . '/' . self::THEME_SLUG . '/sync-manifest.php';

		if ( ! is_readable( $path ) ) {
			return null;
		}

		$manifest = require $path;

		return is_array( $manifest ) ? $manifest : null;
	}

	/**
	 * @return array<string, array{slug: string, label: string, source: string, customized: bool}>
	 */
	public static function get_status(): array {
		$manifest = self::get_manifest();
		$status   = [];

		if ( null === $manifest ) {
			return $status;
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}

			$template = self::get_template_part( $slug );
			$source   = $template->source ?? 'missing';

			$status[ $slug ] = [
				'slug'        => $slug,
				'label'       => $config['label'] ?? $slug,
				'source'      => $source,
				'customized'  => 'custom' === $source,
			];
		}

		return $status;
	}

	/**
	 * Après MAJ package : migrations de contenu uniquement.
	 * Ne réinitialise PAS les template parts (le live publié / édité est conservé).
	 *
	 * @return array{reset: string[], already_synced: string[], missing: string[], errors: string[], repaired_nav_marques: list<array{id: int, title: string}>, migrated_nav_marques: list<array{id: int, title: string}>}
	 */
	public static function after_package_update(): array {
		return [
			'reset'                => [],
			'already_synced'       => [],
			'missing'              => [],
			'errors'               => [],
			'repaired_nav_marques' => self::repair_corrupted_nav_marques_migrations(),
			'migrated_nav_marques' => self::migrate_navigation_marques_copies(),
		];
	}

	/**
	 * Remet tous les parts sync à l’état d’usine (fichier thème), puis migrations pages.
	 *
	 * @return array{reset: string[], already_synced: string[], missing: string[], errors: string[], repaired_nav_marques: list<array{id: int, title: string}>, migrated_nav_marques: list<array{id: int, title: string}>}
	 */
	public static function sync_all(): array {
		$report = [
			'reset'                => [],
			'already_synced'       => [],
			'missing'              => [],
			'errors'               => [],
			'repaired_nav_marques' => [],
			'migrated_nav_marques' => [],
		];

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			$report['errors'][] = 'sync-manifest.php introuvable dans gigi-theme';
			return $report;
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}

			$result = self::reset_template_part( $slug );

			if ( 'reset' === $result ) {
				$report['reset'][] = $slug;
			} elseif ( 'already_synced' === $result ) {
				$report['already_synced'][] = $slug;
			} elseif ( 'missing' === $result ) {
				$report['missing'][] = $slug;
			} else {
				$report['errors'][] = $slug . ' (' . $result . ')';
			}
		}

		$report['repaired_nav_marques'] = self::repair_corrupted_nav_marques_migrations();
		$report['migrated_nav_marques'] = self::migrate_navigation_marques_copies();

		return $report;
	}

	/**
	 * Remet un seul template part à l’usine (supprime la copie DB).
	 *
	 * @return 'reset'|'already_synced'|'missing'|'delete_failed'|'no_wp_id'|'not_sync'
	 */
	public static function reset_to_factory( string $slug ): string {
		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			return 'missing';
		}
		$config = $manifest['template_parts'][ $slug ] ?? null;
		if ( ! is_array( $config ) || empty( $config['sync'] ) ) {
			return 'not_sync';
		}

		return self::reset_template_part( $slug );
	}

	/**
	 * Contenu fichier usine (parts/*.html).
	 */
	public static function get_factory_content( string $slug ): ?string {
		$manifest = self::get_manifest();
		$config   = ( null !== $manifest ) ? ( $manifest['template_parts'][ $slug ] ?? [] ) : [];
		$relative = (string) ( $config['factory'] ?? ( 'parts/' . $slug . '.html' ) );
		$path     = get_theme_root() . '/' . self::THEME_SLUG . '/' . ltrim( $relative, '/' );

		if ( ! is_readable( $path ) ) {
			return null;
		}

		$content = file_get_contents( $path );

		return is_string( $content ) ? $content : null;
	}

	public static function get_template_part_public( string $slug ): ?WP_Block_Template {
		return self::get_template_part( $slug );
	}

	public static function clear_template_cache_public( string $slug ): void {
		self::clear_template_cache( $slug );
	}

	/**
	 * Restaure depuis une révision saine les pages dont la migration 1.0.19
	 * a détruit les wrappers HTML des blocs (cover, columns, groups…).
	 *
	 * @return list<array{id: int, title: string}>
	 */
	public static function repair_corrupted_nav_marques_migrations(): array {
		$repaired = [];

		$query = new WP_Query( [
			'post_type'              => [ 'page', 'post' ],
			'post_status'            => [ 'publish', 'draft', 'private', 'future' ],
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		] );

		foreach ( $query->posts as $post ) {
			$content = (string) $post->post_content;
			if ( ! self::content_references_nav_marques( $content ) ) {
				continue;
			}
			if ( ! self::content_has_flattened_blocks( $content ) ) {
				continue;
			}

			$healthy = self::find_pre_migration_revision_content( (int) $post->ID );
			if ( null === $healthy ) {
				continue;
			}

			$saved = wp_update_post( [
				'ID'           => (int) $post->ID,
				'post_content' => $healthy,
			], true );

			if ( ! is_wp_error( $saved ) ) {
				$repaired[] = [
					'id'    => (int) $post->ID,
					'title' => get_the_title( $post ),
				];
			}
		}

		wp_reset_postdata();

		return $repaired;
	}

	/**
	 * Remplace dans les pages/articles l’ancienne composition « Navigation Marques »
	 * (blocs copiés) par une référence au template part live.
	 *
	 * Utilise parse/serialize sans toucher aux wrappers HTML des blocs parents
	 * (contrairement à 1.0.19 qui vidait innerContent).
	 *
	 * @return list<array{id: int, title: string}>
	 */
	public static function migrate_navigation_marques_copies(): array {
		$migrated = [];

		$query = new WP_Query( [
			'post_type'              => [ 'page', 'post' ],
			'post_status'            => [ 'publish', 'draft', 'private', 'future' ],
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		] );

		foreach ( $query->posts as $post ) {
			$content = (string) $post->post_content;
			if ( ! str_contains( $content, 'gigi-navigation-marques' ) ) {
				continue;
			}
			if ( self::content_has_nav_marques_template_part( $content ) ) {
				continue;
			}

			$blocks  = parse_blocks( $content );
			$changed = false;
			$blocks  = self::replace_nav_marques_blocks( $blocks, $changed );

			if ( ! $changed ) {
				continue;
			}

			$updated = serialize_blocks( $blocks );
			$saved   = wp_update_post( [
				'ID'           => (int) $post->ID,
				'post_content' => $updated,
			], true );

			if ( ! is_wp_error( $saved ) ) {
				$migrated[] = [
					'id'    => (int) $post->ID,
					'title' => get_the_title( $post ),
				];
			}
		}

		wp_reset_postdata();

		return $migrated;
	}

	/**
	 * @param array<int, array<string, mixed>> $blocks
	 * @return array<int, array<string, mixed>>
	 */
	private static function replace_nav_marques_blocks( array $blocks, bool &$changed ): array {
		$out = [];

		foreach ( $blocks as $block ) {
			$class = (string) ( $block['attrs']['className'] ?? '' );
			$name  = (string) ( $block['attrs']['metadata']['name'] ?? '' );
			$pname = (string) ( $block['attrs']['metadata']['patternName'] ?? '' );

			$is_nav_marques = (
				( $block['blockName'] ?? '' ) === 'core/group'
				&& (
					str_contains( $class, 'gigi-navigation-marques' )
					|| str_contains( $pname, 'gigi-navigation-marques' )
					|| str_contains( $name, 'Navigation Marques' )
				)
			);

			if ( $is_nav_marques ) {
				$changed = true;
				$out[]   = [
					'blockName'    => 'core/template-part',
					'attrs'        => [
						'slug'  => 'navigation-marques',
						'theme' => self::THEME_SLUG,
						'area'  => 'uncategorized',
					],
					'innerBlocks'  => [],
					'innerHTML'    => '',
					'innerContent' => [],
				];
				continue;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$block['innerBlocks'] = self::replace_nav_marques_blocks( $block['innerBlocks'], $changed );
			}

			$out[] = $block;
		}

		return $out;
	}

	private static function content_has_nav_marques_template_part( string $content ): bool {
		return (bool) preg_match(
			'/<!--\s*wp:template-part\s+\{[^}]*"slug"\s*:\s*"navigation-marques"/',
			$content
		);
	}

	private static function content_references_nav_marques( string $content ): bool {
		return str_contains( $content, 'gigi-navigation-marques' )
			|| self::content_has_nav_marques_template_part( $content );
	}

	/**
	 * Détecte le contenu aplati par serialize_blocks après wipe de innerContent
	 * (commentaires de blocs sans divs wrappers).
	 */
	private static function content_has_flattened_blocks( string $content ): bool {
		$checks = [
			[ '/<!--\s*wp:columns\b/', '/<div[^>]*\bwp-block-columns\b/' ],
			[ '/<!--\s*wp:cover\b/', '/<(?:div|section)[^>]*\bwp-block-cover\b/' ],
			[ '/<!--\s*wp:group\b/', '/<div[^>]*\bwp-block-group\b/' ],
			[ '/<!--\s*wp:buttons\b/', '/<div[^>]*\bwp-block-buttons\b/' ],
			[ '/<!--\s*wp:column\b/', '/<div[^>]*\bwp-block-column\b/' ],
		];

		foreach ( $checks as [ $comment_pattern, $html_pattern ] ) {
			if ( preg_match( $comment_pattern, $content ) && ! preg_match( $html_pattern, $content ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Trouve une révision antérieure à la migration cassée.
	 */
	private static function find_pre_migration_revision_content( int $post_id ): ?string {
		$revisions = wp_get_post_revisions( $post_id, [
			'posts_per_page' => 30,
			'check_enabled'  => false,
		] );

		foreach ( $revisions as $revision ) {
			$candidate = (string) $revision->post_content;
			if ( ! str_contains( $candidate, 'gigi-navigation-marques' ) ) {
				continue;
			}
			if ( self::content_has_nav_marques_template_part( $candidate ) ) {
				continue;
			}
			if ( self::content_has_flattened_blocks( $candidate ) ) {
				continue;
			}
			if ( ! str_contains( $candidate, 'wp-block-group' ) ) {
				continue;
			}

			return $candidate;
		}

		return null;
	}

	/**
	 * Compte les contenus qui ont encore l’ancienne composition copiée.
	 */
	public static function count_navigation_marques_copies(): int {
		$query = new WP_Query( [
			'post_type'              => [ 'page', 'post' ],
			'post_status'            => [ 'publish', 'draft', 'private', 'future' ],
			'posts_per_page'         => -1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		] );

		$count = 0;
		foreach ( $query->posts as $post_id ) {
			$content = (string) get_post_field( 'post_content', $post_id );
			if ( ! str_contains( $content, 'gigi-navigation-marques' ) ) {
				continue;
			}
			if ( self::content_has_nav_marques_template_part( $content ) ) {
				continue;
			}
			$count++;
		}

		return $count;
	}

	public static function on_upgrader_complete( $upgrader, array $options ): void {
		if ( ( $options['action'] ?? '' ) !== 'update' || ( $options['type'] ?? '' ) !== 'theme' ) {
			return;
		}

		$themes = $options['themes'] ?? [];
		if ( ! in_array( self::THEME_SLUG, $themes, true ) ) {
			return;
		}

		// Migrations de contenu uniquement — ne pas écraser le layout live (édité / publié).
		self::after_package_update();
	}

	private static function get_template_part( string $slug ): ?WP_Block_Template {
		if ( ! function_exists( 'get_block_template' ) ) {
			return null;
		}

		$template = get_block_template( self::THEME_SLUG . '//' . $slug, 'wp_template_part' );

		return $template instanceof WP_Block_Template ? $template : null;
	}

	/**
	 * @return 'reset'|'already_synced'|'missing'|'delete_failed'|'no_wp_id'
	 */
	private static function reset_template_part( string $slug ): string {
		$template = self::get_template_part( $slug );

		if ( ! $template ) {
			return 'missing';
		}

		if ( 'theme' === $template->source ) {
			return 'already_synced';
		}

		if ( empty( $template->wp_id ) ) {
			return 'no_wp_id';
		}

		$deleted = wp_delete_post( (int) $template->wp_id, true );

		if ( ! $deleted ) {
			return 'delete_failed';
		}

		self::clear_template_cache( $slug );

		return 'reset';
	}

	private static function clear_template_cache( string $slug ): void {
		if ( function_exists( 'clean_theme_cache' ) ) {
			clean_theme_cache( self::THEME_SLUG );
		}

		wp_cache_delete( 'wp_template_part_' . $slug . '_' . self::THEME_SLUG, 'block_templates' );
		wp_cache_delete( 'wp_template_part_' . self::THEME_SLUG . '//' . $slug, 'block_templates' );
	}
}
