<?php
/**
 * Gigi_Layout_Pull — reçoit le layout publié par le maître et l’applique en base.
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Layout_Pull {

	public const OPTION_LAST_PULL = 'gigi_layout_last_pull';

	public static function register(): void {
		add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
	}

	public static function register_routes(): void {
		register_rest_route( 'gigi-checker/v1', '/layout', [
			'methods'             => 'POST',
			'permission_callback' => [ Gigi_Remote_Sync::class, 'check_secret' ],
			'callback'            => [ self::class, 'handle_pull' ],
		] );
	}

	public static function handle_pull( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = [];
		}

		$parts = $body['parts'] ?? null;
		if ( ! is_array( $parts ) || empty( $parts ) ) {
			return new WP_REST_Response( [
				'success' => false,
				'message' => 'Payload invalide : parts manquant.',
				'applied' => [],
				'skipped' => [],
				'errors'  => [ 'parts' ],
			], 400 );
		}

		$result = self::apply_parts(
			$parts,
			(string) ( $body['source'] ?? '' ),
			(string) ( $body['published_at'] ?? gmdate( 'c' ) )
		);

		$status = 200;

		return new WP_REST_Response( [
			'success' => empty( $result['errors'] ),
			'message' => empty( $result['errors'] )
				? sprintf( 'Layout appliqué : %s', implode( ', ', $result['applied'] ) )
				: 'Layout partiellement appliqué.',
			'applied' => $result['applied'],
			'skipped' => $result['skipped'],
			'errors'  => $result['errors'],
		], $status );
	}

	/**
	 * @param array<string, mixed> $parts
	 * @return array{applied: string[], skipped: string[], errors: string[]}
	 */
	public static function apply_parts( array $parts, string $source = '', string $published_at = '' ): array {
		$applied = [];
		$skipped = [];
		$errors  = [];

		$allowed = self::allowed_slugs();

		foreach ( $parts as $slug => $part ) {
			$slug = sanitize_key( (string) $slug );
			if ( '' === $slug || ! isset( $allowed[ $slug ] ) ) {
				$skipped[] = $slug ?: '(vide)';
				continue;
			}

			if ( ! is_array( $part ) ) {
				$errors[] = $slug . ' (format invalide)';
				continue;
			}

			$content = (string) ( $part['content'] ?? '' );
			if ( '' === trim( $content ) ) {
				$errors[] = $slug . ' (contenu vide)';
				continue;
			}

			$title = sanitize_text_field( (string) ( $part['title'] ?? $allowed[ $slug ]['label'] ?? $slug ) );
			$area  = sanitize_key( (string) ( $part['area'] ?? $allowed[ $slug ]['area'] ?? 'uncategorized' ) );

			$done = self::upsert_template_part( $slug, $title, $area, $content );
			if ( is_wp_error( $done ) ) {
				$errors[] = $slug . ' — ' . $done->get_error_message();
				continue;
			}

			$applied[] = $slug;
		}

		if ( $applied ) {
			update_option(
				self::OPTION_LAST_PULL,
				[
					'at'     => $published_at ?: gmdate( 'c' ),
					'source' => $source,
					'parts'  => $applied,
				],
				false
			);
		}

		return compact( 'applied', 'skipped', 'errors' );
	}

	/**
	 * @return array<string, array{label: string, area: string}>
	 */
	private static function allowed_slugs(): array {
		$manifest = Gigi_Layout_Sync::get_manifest();
		$out      = [];

		if ( null === $manifest ) {
			return $out;
		}

		foreach ( $manifest['template_parts'] ?? [] as $slug => $config ) {
			if ( empty( $config['sync'] ) ) {
				continue;
			}
			$out[ $slug ] = [
				'label' => (string) ( $config['label'] ?? $slug ),
				'area'  => (string) ( $config['area'] ?? 'uncategorized' ),
			];
		}

		return $out;
	}

	/**
	 * @return true|WP_Error
	 */
	private static function upsert_template_part( string $slug, string $title, string $area, string $content ) {
		if ( ! post_type_exists( 'wp_template_part' ) ) {
			return new WP_Error( 'no_template_part', 'Type wp_template_part indisponible.' );
		}

		$theme = 'gigi-theme';
		$existing = Gigi_Layout_Sync::get_template_part_public( $slug );

		if ( $existing && 'custom' === ( $existing->source ?? '' ) && ! empty( $existing->wp_id ) ) {
			$saved = wp_update_post( [
				'ID'           => (int) $existing->wp_id,
				'post_title'   => $title,
				'post_content' => $content,
				'post_status'  => 'publish',
			], true );

			if ( is_wp_error( $saved ) ) {
				return $saved;
			}

			wp_set_object_terms( (int) $existing->wp_id, $area, 'wp_template_part_area' );
			Gigi_Layout_Sync::clear_template_cache_public( $slug );

			return true;
		}

		$post_id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
			'post_type'    => 'wp_template_part',
			'post_name'    => $slug,
		], true );

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		wp_set_object_terms( (int) $post_id, $theme, 'wp_theme' );
		wp_set_object_terms( (int) $post_id, $area, 'wp_template_part_area' );
		Gigi_Layout_Sync::clear_template_cache_public( $slug );

		return true;
	}
}
