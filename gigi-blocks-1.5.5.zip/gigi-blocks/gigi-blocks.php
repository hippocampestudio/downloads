<?php
/**
 * Plugin Name: Gigi Blocks
 * Plugin URI:  https://bitbucket.org/antibo/gigi
 * Description: Blocs Gutenberg personnalisés pour les sites du groupe Gigi.
 * Version:     1.5.5
 * Author:      Hippocampe Studio
 * Author URI:  https://hippocampe.studio
 * License:     Proprietary
 * Text Domain: gigi-blocks
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_BLOCKS_VERSION', '1.5.5' );
define( 'GIGI_BLOCKS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GIGI_BLOCKS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Enregistre tous les blocs présents dans le dossier build/.
 * Chaque bloc doit avoir son propre block.json.
 */
add_action( 'init', function () {
	$blocks_dir = GIGI_BLOCKS_DIR . 'build/';

	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}

	foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
} );

/**
 * Charge les assets frontend du slider à la première occurrence du bloc rendu.
 * render_block est plus fiable que wp_enqueue_scripts + has_block() :
 * il détecte le bloc même dans les template parts (header, footer).
 */
add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/slider' ) {
		return $content;
	}

	wp_enqueue_style(
		'gigi-slider',
		GIGI_BLOCKS_URL . 'assets/slider.css',
		[],
		GIGI_BLOCKS_VERSION
	);
	wp_enqueue_script(
		'gigi-slider',
		GIGI_BLOCKS_URL . 'assets/slider.js',
		[],
		GIGI_BLOCKS_VERSION,
		true
	);

	return $content;
}, 10, 2 );

/**
 * Strate : injecte TOUTES les CSS custom properties côté frontend.
 *
 * Reconstruit les variables depuis les attributs du bloc pour garantir
 * leur présence dans le HTML rendu (le save.js peut ne pas les sérialiser
 * selon la version de WordPress). Redirige également le padding du wrapper
 * vers la colonne de contenu.
 */
add_filter( 'render_block', function ( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'gigi/strate' ) {
		return $content;
	}

	$attrs = $block['attrs'] ?? [];
	$vars  = '';

	$media_width = (int) ( $attrs['mediaWidth'] ?? 50 );
	if ( $media_width !== 50 ) {
		$vars .= "--gigi-strate-media-width:{$media_width}%;";
	}

	$pos_x = (int) ( $attrs['imagePositionX'] ?? 50 );
	$pos_y = (int) ( $attrs['imagePositionY'] ?? 50 );
	if ( $pos_x !== 50 || $pos_y !== 50 ) {
		$vars .= "--gigi-strate-img-pos:{$pos_x}% {$pos_y}%;";
	}

	$zoom = (int) ( $attrs['imageZoom'] ?? 100 );
	if ( $zoom !== 100 ) {
		$scale = round( $zoom / 100, 2 );
		$vars .= "--gigi-strate-img-zoom:{$scale};";
	}

	$gap = (int) ( $attrs['columnsGap'] ?? 0 );
	if ( $gap > 0 ) {
		$vars .= "--gigi-strate-gap:{$gap}px;";
	}

	$color_map = [
		'buttonBgColor'      => 'btn-bg',
		'buttonTextColor'    => 'btn-color',
		'buttonHoverBgColor' => 'btn-hover-bg',
	];
	foreach ( $color_map as $attr => $var ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$vars .= "--gigi-strate-{$var}:{$attrs[ $attr ]};";
		}
	}

	$font_map = [
		'titleFontSize'  => 'title-size',
		'textFontSize'   => 'text-size',
		'buttonFontSize' => 'btn-size',
	];
	foreach ( $font_map as $attr => $var ) {
		if ( ! empty( $attrs[ $attr ] ) ) {
			$val = $attrs[ $attr ];
			if ( preg_match( '/^[a-z-]+$/i', $val ) ) {
				$val = "var(--wp--preset--font-size--{$val})";
			}
			$vars .= "--gigi-strate-{$var}:{$val};";
		}
	}

	$padding = $attrs['style']['spacing']['padding'] ?? [];
	if ( ! empty( $padding ) ) {
		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $dir ) {
			if ( empty( $padding[ $dir ] ) ) {
				continue;
			}
			$val = $padding[ $dir ];
			if ( str_starts_with( $val, 'var:' ) ) {
				$parts = explode( '|', substr( $val, 4 ) );
				$val   = 'var(--wp--preset--' . implode( '--', $parts ) . ')';
			}
			$vars .= "--gigi-strate-pad-{$dir}:{$val};";
		}
		$vars .= 'padding:0 !important;';
	}

	if ( ! $vars ) {
		return $content;
	}

	if ( str_contains( $content, 'style="' ) ) {
		$content = preg_replace( '/style="/', 'style="' . $vars, $content, 1 );
	} else {
		$content = preg_replace( '/<div\s/', '<div style="' . rtrim( $vars, ';' ) . '" ', $content, 1 );
	}

	return $content;
}, 10, 2 );

/**
 * Catégorie de blocs personnalisée "Gigi" dans l'éditeur.
 */
add_filter( 'block_categories_all', function ( array $categories ): array {
	array_unshift( $categories, [
		'slug'  => 'gigi',
		'title' => 'Gigi',
		'icon'  => null,
	] );
	return $categories;
} );
