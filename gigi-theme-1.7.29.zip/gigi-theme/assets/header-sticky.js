( function () {
	const header = document
		.querySelector( '.gigi-header-sticky' )
		?.closest( 'header.wp-block-template-part' );

	if ( ! header ) {
		return;
	}

	const onScroll = () => {
		header.classList.toggle( 'is-stuck', window.scrollY > 0 );
	};

	onScroll();
	window.addEventListener( 'scroll', onScroll, { passive: true } );
} )();
