<?php
/**
 * Gigi_Admin_Bar — menus « SITES GIGI » et « ADMINS GIGI » dans la barre d’admin WP.
 *
 * Placés juste après le logo WordPress (priorité basse).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Admin_Bar {

	private const ADMIN_PATH = 'bo-securise';

	public static function register(): void {
		// Priorité 15 : juste après le logo WP (10), avant le nom du site (20).
		add_action( 'admin_bar_menu', [ self::class, 'add_nodes' ], 15 );
	}

	/**
	 * @param WP_Admin_Bar $bar
	 */
	public static function add_nodes( $bar ): void {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		$sites = Gigi_Fleet::get_sites_for_editor();
		if ( empty( $sites ) ) {
			return;
		}

		$current = Gigi_Fleet::get_current_site_url();

		$bar->add_node(
			[
				'id'    => 'gigi-sites',
				'title' => 'SITES GIGI',
				'href'  => false,
				'meta'  => [
					'title' => 'Sites publics Gigi',
				],
			]
		);

		$bar->add_node(
			[
				'id'    => 'gigi-admins',
				'title' => 'ADMINS GIGI',
				'href'  => false,
				'meta'  => [
					'title' => 'Administrations des sites Gigi',
				],
			]
		);

		foreach ( $sites as $index => $site ) {
			$label = $site['label'];
			if ( Gigi_Fleet::urls_match( $site['url'], $current ) ) {
				$label = '• ' . $label;
			}

			$public_url = trailingslashit( $site['url'] );
			$admin_url  = $public_url . self::ADMIN_PATH . '/';

			$bar->add_node(
				[
					'id'     => 'gigi-sites-' . $index,
					'parent' => 'gigi-sites',
					'title'  => $label,
					'href'   => esc_url( $public_url ),
					'meta'   => [
						'target' => '_blank',
					],
				]
			);

			$bar->add_node(
				[
					'id'     => 'gigi-admins-' . $index,
					'parent' => 'gigi-admins',
					'title'  => $label,
					'href'   => esc_url( $admin_url ),
				]
			);
		}
	}
}
