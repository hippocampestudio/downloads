<?php
/**
 * Manifeste des composants de layout synchronisés.
 *
 * - factory : fichier thème = état d’usine (jamais modifié par l’éditeur de site).
 * - sync    : éligible à la publication maître → satellites + reset usine.
 *
 * L’éditeur de site crée une copie en base (live). Les fichiers parts/ restent l’usine.
 */

defined( 'ABSPATH' ) || exit;

return [
	'template_parts' => [
		'header-multisite' => [
			'label'   => 'En-tête multisite',
			'area'    => 'header',
			'factory' => 'parts/header-multisite.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'footer-multisite' => [
			'label'   => 'Pied de page multisite',
			'area'    => 'footer',
			'factory' => 'parts/footer-multisite.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'navigation-mobile' => [
			'label'   => 'Navigation mobile',
			'area'    => 'navigation-overlay',
			'factory' => 'parts/navigation-mobile.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'navigation-marques' => [
			'label'   => 'Navigation Marques',
			'area'    => 'uncategorized',
			'factory' => 'parts/navigation-marques.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'header-protected' => [
			'label'   => 'En-tête pages protégées',
			'area'    => 'header',
			'factory' => 'parts/header-protected.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'footer-protected' => [
			'label'   => 'Pied de page pages protégées',
			'area'    => 'footer',
			'factory' => 'parts/footer-protected.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
		'password-protected' => [
			'label'   => 'Contenu protégé par mot de passe',
			'area'    => 'uncategorized',
			'factory' => 'parts/password-protected.html',
			'sync'    => true,
			'layer'   => 'layout',
		],
	],
];
