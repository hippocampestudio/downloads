<?php
/**
 * Gigi Theme — functions.php
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_THEME_VERSION', '1.7.23' );

/**
 * Enqueue styles & scripts
 */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'gigi-theme-style',
		get_stylesheet_uri(),
		[],
		GIGI_THEME_VERSION
	);
} );

/**
 * Add theme support features
 */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );

	remove_theme_support( 'core-block-patterns' );

	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', [
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	] );

	load_theme_textdomain( 'gigi-theme', get_template_directory() . '/languages' );

	register_block_pattern_category( 'gigi', [
		'label'       => 'Gigi',
		'description' => 'Compositions de blocs GIGI.',
	] );
} );

/**
 * Supprime toutes les compositions qui ne viennent pas du thème Gigi ou du client.
 * Priorité 20 = après l'enregistrement par WP core (priority 9) et les plugins (priority 10).
 * Sont conservées :
 *   - les compositions du thème  (name commence par "gigi-theme/")
 *   - les compositions personnalisées du client (source = "custom", stockées en DB)
 */
add_action( 'init', function (): void {
	if ( ! class_exists( 'WP_Block_Patterns_Registry' ) ) {
		return;
	}

	$all = WP_Block_Patterns_Registry::get_instance()->get_all_registered();

	foreach ( $all as $pattern ) {
		$name   = $pattern['name']   ?? '';
		$source = $pattern['source'] ?? '';

		if ( str_starts_with( $name, 'gigi-theme/' ) || 'custom' === $source ) {
			continue;
		}

		unregister_block_pattern( $name );
	}
}, 20 );

/**
 * Navigation header-multisite : classe sur le lien de la page courante.
 */
add_filter( 'render_block', 'gigi_header_nav_mark_current_link', 10, 2 );

function gigi_header_nav_mark_current_link( string $content, array $block ): string {
	if ( ( $block['blockName'] ?? '' ) !== 'core/navigation' ) {
		return $content;
	}

	$class_name = $block['attrs']['className'] ?? '';
	if ( ! str_contains( $class_name, 'gigi-header-nav' ) ) {
		return $content;
	}

	$current = gigi_normalize_nav_url( gigi_get_current_request_url() );
	if ( '' === $current ) {
		return $content;
	}

	$processor = new WP_HTML_Tag_Processor( $content );
	while ( $processor->next_tag( 'A' ) ) {
		$href = $processor->get_attribute( 'href' );
		if ( ! $href || gigi_normalize_nav_url( $href ) !== $current ) {
			continue;
		}

		$link_class = $processor->get_attribute( 'class' ) ?? '';
		if ( ! str_contains( $link_class, 'gigi-nav-current' ) ) {
			$processor->set_attribute( 'class', trim( $link_class . ' gigi-nav-current' ) );
		}
	}

	return $processor->get_updated_html();
}

function gigi_get_current_request_url(): string {
	if ( is_singular() ) {
		return (string) get_permalink();
	}

	if ( is_front_page() ) {
		return (string) home_url( '/' );
	}

	global $wp;

	$request = $wp->request ?? '';
	if ( '' !== $request ) {
		return (string) home_url( '/' . $request );
	}

	return (string) home_url( '/' );
}

function gigi_normalize_nav_url( string $url ): string {
	$url = preg_replace( '/[#?].*$/', '', $url );
	$parts = wp_parse_url( $url );

	if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
		return untrailingslashit( strtolower( $url ) );
	}

	$scheme = strtolower( $parts['scheme'] ?? 'https' );
	$host   = strtolower( $parts['host'] );
	$path   = isset( $parts['path'] ) ? strtolower( untrailingslashit( $parts['path'] ) ) : '';

	return $scheme . '://' . $host . $path;
}

/**
 * Template « Contenu protégé » — hiérarchie + type éditeur de site (WP 7.0 / FSE).
 */
add_filter( 'default_template_types', function ( array $types ): array {
	$types['password-protected'] = [
		'title'       => __( 'Contenu protégé', 'gigi-theme' ),
		'description' => __( 'Affiché lorsqu\'une page ou un article requiert un mot de passe.', 'gigi-theme' ),
	];
	return $types;
} );

add_filter( 'page_template_hierarchy', 'gigi_password_protected_template_hierarchy' );
add_filter( 'single_template_hierarchy', 'gigi_password_protected_template_hierarchy' );

function gigi_password_protected_template_hierarchy( array $templates ): array {
	if ( is_singular() && post_password_required() ) {
		array_unshift( $templates, 'password-protected' );
	}
	return $templates;
}

/**
 * Formulaire mot de passe aux couleurs Gigi (classes bouton theme.json).
 */
add_filter( 'the_password_form', 'gigi_the_password_form', 10, 3 );

function gigi_the_password_form( string $output, $post, string $invalid_password ): string {
	$post       = get_post( $post );
	$field_id   = 'pwbox-' . ( $post ? (string) $post->ID : (string) wp_rand() );
	$action     = esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) );
	$redirect   = '';
	$aria       = '';
	$form_class = 'post-password-form gigi-password-form';

	if ( $post && $post->ID ) {
		$redirect = sprintf(
			'<input type="hidden" name="redirect_to" value="%s" />',
			esc_attr( get_permalink( $post->ID ) )
		);
	}

	if ( $invalid_password ) {
		$form_class  .= ' password-form-error';
		$aria         = ' aria-describedby="error-' . esc_attr( $field_id ) . '"';
		$invalid_html = sprintf(
			'<div class="post-password-form-invalid-password" role="alert"><p id="error-%1$s">%2$s</p></div>',
			esc_attr( $field_id ),
			esc_html( $invalid_password )
		);
	} else {
		$invalid_html = '';
	}

	return sprintf(
		'<form action="%1$s" class="%2$s" method="post">%3$s%4$s
		<p class="gigi-password-form__message">%5$s</p>
		<p class="gigi-password-form__field"><label for="%6$s">%7$s</label>
		<input name="post_password" id="%6$s" type="password" spellcheck="false" required size="20"%8$s /></p>
		<p class="gigi-password-form__submit"><input type="submit" name="Submit" class="wp-block-button__link wp-element-button" value="%9$s" /></p>
		</form>',
		$action,
		esc_attr( $form_class ),
		$redirect,
		$invalid_html,
		esc_html__( 'Ce contenu est protégé par mot de passe. Saisissez-le ci-dessous pour y accéder.', 'gigi-theme' ),
		esc_attr( $field_id ),
		esc_html__( 'Mot de passe', 'gigi-theme' ),
		$aria,
		esc_attr_x( 'Valider', 'post password form', 'gigi-theme' )
	);
}

/**
 * Autorise l'upload de fichiers SVG dans la médiathèque.
 */
add_filter( 'upload_mimes', function ( array $mimes ): array {
	$mimes['svg']  = 'image/svg+xml';
	$mimes['svgz'] = 'image/svg+xml';
	return $mimes;
} );

add_action( 'admin_head', function (): void {
	echo '<style>.attachment-266x266 img,.thumbnail img,.media-icon img[src$=".svg"]{width:100%!important;height:auto!important}</style>';
} );

add_filter( 'wp_handle_upload_prefilter', function ( array $file ): array {
	if ( isset( $file['type'] ) && 'image/svg+xml' === $file['type'] ) {
		$svg = file_get_contents( $file['tmp_name'] );
		if ( false !== $svg && false !== stripos( $svg, '<script' ) ) {
			$file['error'] = 'Le SVG contient des scripts et a été bloqué par sécurité.';
		}
	}
	return $file;
} );
