<?php
/**
 * Gigi_Status_Page — page d'état dans l'admin WP (Outils → Gigi Checker).
 */

defined( 'ABSPATH' ) || exit;

class Gigi_Status_Page {

	public static function register(): void {
		add_management_page(
			'Gigi Checker — État',
			'Gigi Checker',
			'update_plugins',
			'gigi-checker-status',
			[ self::class, 'render' ]
		);

		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
	}

	public static function enqueue_assets( string $hook ): void {
		if ( 'tools_page_gigi-checker-status' !== $hook ) {
			return;
		}

		$base = plugin_dir_url( GIGI_CHECKER_FILE ) . 'assets/';
		wp_enqueue_style(
			'gigi-fleet-admin',
			$base . 'fleet-admin.css',
			[],
			GIGI_CHECKER_VERSION
		);
		wp_enqueue_script(
			'gigi-fleet-admin',
			$base . 'fleet-admin.js',
			[],
			GIGI_CHECKER_VERSION,
			true
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'gigi-checker' ) );
		}

		// ---- Sauvegarde de l'URL personnalisée -------------------------
		if (
			isset( $_POST['gigi_versions_url'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_url' )
		) {
			$new_url = sanitize_url( trim( wp_unslash( $_POST['gigi_versions_url'] ) ) );
			Gigi_Versions::save_url( $new_url );
			Gigi_Versions::flush_cache();
			echo '<div class="notice notice-success is-dismissible"><p>URL mise à jour. Le cache a été vidé.</p></div>';
		}

		// ---- Sauvegarde du secret de sync à distance -------------------
		if (
			isset( $_POST['gigi_sync_secret'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_sync_secret' )
		) {
			$secret = sanitize_text_field( wp_unslash( $_POST['gigi_sync_secret'] ) );
			update_option( Gigi_Remote_Sync::get_secret_option_name(), $secret );
			echo '<div class="notice notice-success is-dismissible"><p>Secret de synchronisation enregistré.</p></div>';
		}

		// ---- Flotte (maître + liste des sites) --------------------------
		if (
			isset( $_POST['gigi_save_fleet'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_save_fleet' )
		) {
			$is_master = ! empty( $_POST['gigi_is_master'] );
			Gigi_Fleet::set_is_master( $is_master );
			if ( $is_master && isset( $_POST['gigi_fleet_sites'] ) && is_array( $_POST['gigi_fleet_sites'] ) ) {
				$raw   = wp_unslash( $_POST['gigi_fleet_sites'] );
				$sites = [];
				foreach ( $raw as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$sites[] = [
						'label' => sanitize_text_field( (string) ( $row['label'] ?? '' ) ),
						'url'   => sanitize_text_field( (string) ( $row['url'] ?? '' ) ),
					];
				}
				Gigi_Fleet::save_sites( $sites );
			}
			echo '<div class="notice notice-success is-dismissible"><p>Configuration de la flotte enregistrée.</p></div>';
		}

		// ---- Sync flotte depuis le maître ------------------------------
		$fleet_sync_results = null;
		if (
			isset( $_POST['gigi_fleet_sync'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_fleet_sync' )
		) {
			if ( ! Gigi_Fleet::is_master() ) {
				echo '<div class="notice notice-error is-dismissible"><p>Seul le site maître peut synchroniser la flotte.</p></div>';
			} else {
				// Appliquer d’abord localement (thème + layout).
				$local_request  = new WP_REST_Request( 'POST', '/gigi-checker/v1/sync' );
				$local_response = Gigi_Remote_Sync::sync_and_apply( $local_request );
				$fleet_sync_results = [
					'local'  => $local_response->get_data(),
					'remote' => Gigi_Fleet::sync_all_remote(),
				];
			}
		}

		// ---- Resync des template parts de layout ---------------------
		if (
			isset( $_POST['gigi_layout_sync'], $_POST['_wpnonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gigi_layout_sync' )
		) {
			$layout_report = Gigi_Layout_Sync::sync_all();
			$reset_count   = count( $layout_report['reset'] );
			if ( $reset_count > 0 ) {
				printf(
					'<div class="notice notice-success is-dismissible"><p>Layout commun rétabli : %d élément(s) local(aux) effacé(s) — le thème reprend la main (%s).</p></div>',
					$reset_count,
					esc_html( implode( ', ', $layout_report['reset'] ) )
				);
			} else {
				echo '<div class="notice notice-info is-dismissible"><p>Aucun élément modifié localement — le layout vient déjà du thème commun.</p></div>';
			}
		}

		// ---- Fetch frais (ignore le cache) -----------------------------
		$remote      = Gigi_Versions::fetch_remote();
		$last_error  = Gigi_Versions::get_last_error();
		$current_url = Gigi_Versions::get_url();
		$slugs       = [ 'gigi-theme', 'gigi-checker', 'gigi-blocks' ];

		echo '<div class="wrap">';
		echo '<h1>Gigi Checker — État</h1>';

		// ---- Connexion au repo distant ----------------------------------
		echo '<h2>Connexion</h2>';
		if ( empty( $remote ) && $last_error ) {
			echo '<div class="notice notice-error inline"><p>';
			echo '<strong>❌ Échec de connexion</strong><br>';
			printf( 'URL : <code>%s</code><br>', esc_html( $current_url ) );
			printf( 'Erreur : <code>%s</code>', esc_html( $last_error['message'] ) );
			if ( ! empty( $last_error['code'] ) && 'http_error' !== $last_error['type'] ) {
				printf( ' (<code>%s</code>)', esc_html( (string) $last_error['code'] ) );
			}
			echo '</p></div>';
		} elseif ( empty( $remote ) ) {
			echo '<div class="notice notice-error inline"><p>';
			printf( '❌ Impossible de récupérer <code>%s</code>.', esc_html( $current_url ) );
			echo '</p></div>';
		} else {
			echo '<div class="notice notice-success inline"><p>';
			printf( '✅ Connexion OK — <code>%s</code>', esc_html( $current_url ) );
			echo '</p></div>';
		}

		// ---- Configuration de l'URL ------------------------------------
		echo '<h2>URL du fichier versions.json</h2>';
		echo '<p><strong>Par défaut</strong> : Bitbucket puis GitHub automatiquement si Bitbucket est bloqué.</p>';
		echo '<ul style="list-style:disc;margin-left:1.5em">';
		echo '<li><code>' . esc_html( GIGI_VERSIONS_URL ) . '</code> (prioritaire)</li>';
		echo '<li><code>' . esc_html( GIGI_VERSIONS_URL_FALLBACK ) . '</code> (secours)</li>';
		echo '</ul>';
		echo '<p class="description"><strong>À éviter</strong> : <code>cdn.jsdelivr.net/.../versions.json</code> — le CDN met ce fichier en cache très longtemps (versions obsolètes). Les ZIP en <code>gigi-theme-X.X.X.zip</code> sur jsDelivr vont bien.</p>';
		echo '<form method="post">';
		wp_nonce_field( 'gigi_save_url' );
		printf(
			'<input type="url" name="gigi_versions_url" value="%s" class="regular-text" style="width:500px;max-width:100%%">',
			esc_attr( $current_url )
		);
		echo ' <button type="submit" class="button button-primary">Enregistrer et tester</button>';
		echo '</form>';

		// ---- Synchronisation à distance (script update-all-sites) -------
		echo '<h2>Synchronisation à distance</h2>';
		echo '<p>Secret partagé entre tous les sites (requis pour la sync flotte et le script <code>update-all-sites.sh</code>).</p>';
		$sync_secret = get_option( Gigi_Remote_Sync::get_secret_option_name(), '' );
		echo '<form method="post">';
		wp_nonce_field( 'gigi_save_sync_secret' );
		echo '<input type="password" name="gigi_sync_secret" value="' . esc_attr( $sync_secret ) . '" class="regular-text" style="width:300px" placeholder="Secret partagé (vide = désactivé)" autocomplete="off"> ';
		echo '<button type="submit" class="button button-primary">Enregistrer</button>';
		echo '</form>';

		// ---- Flotte multi-sites ----------------------------------------
		echo '<h2>Flotte multi-sites</h2>';
		$is_master     = Gigi_Fleet::is_master();
		$fleet_sites   = Gigi_Fleet::get_sites();
		$editor_sites  = Gigi_Fleet::get_sites_for_editor();
		$current_url   = Gigi_Fleet::get_current_site_url();
		$current_label = wp_parse_url( home_url(), PHP_URL_HOST );
		$current_label = is_string( $current_label ) ? $current_label : 'Ce site';

		echo '<div class="gigi-fleet-box">';
		echo '<p>Le site <strong>maître</strong> gère la liste des sites et peut lancer une mise à jour sur toute la flotte. '
			. 'Les autres sites (satellites) n’ont besoin que du <strong>même secret</strong> ci-dessus.</p>';

		echo '<form method="post" id="gigi-fleet-form">';
		wp_nonce_field( 'gigi_save_fleet' );
		echo '<input type="hidden" name="gigi_save_fleet" value="1">';

		echo '<label class="gigi-fleet-master-toggle">';
		echo '<input type="checkbox" name="gigi_is_master" id="gigi_is_master" value="1"' . checked( $is_master, true, false ) . '>';
		echo '<span><strong>Ce site est le maître de la flotte</strong>';
		echo '<span class="description">Cochez uniquement sur un site (ex. gigi-evenements.fr). Décochez sur les satellites.</span></span>';
		echo '</label>';

		printf(
			'<div id="gigi-fleet-master-panel"%s>',
			$is_master ? '' : ' hidden'
		);

		if ( ! $is_master && empty( $fleet_sites ) ) {
			echo '<p class="description" style="margin-top:0">Cochez la case ci-dessus pour afficher et éditer la liste des sites.</p>';
		}

		echo '<table class="widefat striped gigi-fleet-table">';
		echo '<thead><tr>';
		echo '<th class="gigi-fleet-col-label">Nom du site</th>';
		echo '<th class="gigi-fleet-col-url">URL</th>';
		echo '<th class="gigi-fleet-col-role">Rôle</th>';
		echo '<th class="gigi-fleet-col-actions"><span class="screen-reader-text">Actions</span></th>';
		echo '</tr></thead>';
		printf(
			'<tbody id="gigi-fleet-rows" data-current-url="%s" data-current-label="%s">',
			esc_attr( $current_url ),
			esc_attr( $current_label )
		);

		foreach ( $editor_sites as $i => $site ) {
			$is_current = Gigi_Fleet::urls_match( $site['url'], $current_url );
			printf(
				'<tr class="gigi-fleet-row%s">',
				$is_current ? ' gigi-fleet-row--current' : ''
			);
			printf(
				'<td><input type="text" class="regular-text" data-name="label" name="gigi_fleet_sites[%d][label]" value="%s" placeholder="Ex. Gigi Événements"></td>',
				(int) $i,
				esc_attr( $site['label'] )
			);
			printf(
				'<td><input type="url" class="regular-text" data-name="url" name="gigi_fleet_sites[%d][url]" value="%s" placeholder="https://www.exemple.fr"></td>',
				(int) $i,
				esc_attr( $site['url'] )
			);
			echo '<td class="gigi-fleet-role">';
			if ( $is_current ) {
				echo '<span class="gigi-fleet-badge gigi-fleet-badge--master">Maître (ce site)</span>';
			} else {
				echo '<span class="gigi-fleet-badge">Satellite</span>';
			}
			echo '</td>';
			echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		echo '<div class="gigi-fleet-actions">';
		echo '<button type="button" class="button" id="gigi-fleet-add">+ Ajouter un site</button>';
		echo '<button type="button" class="button" id="gigi-fleet-add-current">Ajouter ce site</button>';
		echo '</div>';
		echo '<p class="description">Le site dont l’URL correspond à ce WordPress est marqué « Maître (ce site) ». Incluez-le dans la liste.</p>';

		echo '</div>'; // #gigi-fleet-master-panel

		if ( ! $is_master && ! empty( $fleet_sites ) ) {
			echo '<p class="gigi-fleet-satellite-note">Ce site est un <strong>satellite</strong>. La liste de la flotte se configure sur le site maître.</p>';
		}

		echo '<div class="gigi-fleet-save-row">';
		echo '<button type="submit" class="button button-primary">Enregistrer la flotte</button>';
		echo '</div>';
		echo '</form>';

		// Template JS pour nouvelles lignes.
		echo '<template id="gigi-fleet-row-template">';
		echo '<tr class="gigi-fleet-row">';
		echo '<td><input type="text" class="regular-text" data-name="label" value="" placeholder="Ex. Gigi Événements"></td>';
		echo '<td><input type="url" class="regular-text" data-name="url" value="" placeholder="https://www.exemple.fr"></td>';
		echo '<td class="gigi-fleet-role"><span class="gigi-fleet-badge">Satellite</span></td>';
		echo '<td class="gigi-fleet-col-actions"><button type="button" class="button-link button-link-delete gigi-fleet-remove">Supprimer</button></td>';
		echo '</tr>';
		echo '</template>';

		echo '</div>'; // .gigi-fleet-box

		if ( $is_master ) {
			if ( empty( $fleet_sites ) ) {
				echo '<div class="notice notice-warning inline gigi-fleet-sync-box"><p>Enregistrez d’abord la liste des sites pour pouvoir synchroniser la flotte.</p></div>';
			} else {
				$remote_count = count( Gigi_Fleet::get_remote_sites() );
				echo '<div class="gigi-fleet-sync-box">';
				echo '<form method="post">';
				wp_nonce_field( 'gigi_fleet_sync' );
				echo '<input type="hidden" name="gigi_fleet_sync" value="1">';
				printf(
					'<button type="submit" class="button button-primary">Mettre à jour toute la flotte (%d satellite%s)</button>',
					$remote_count,
					1 === $remote_count ? '' : 's'
				);
				echo '<p class="description">Met à jour ce site, puis chaque satellite via le secret partagé.</p>';
				echo '</form>';
				echo '</div>';
			}
		}

		if ( is_array( $fleet_sync_results ) ) {
			echo '<h3>Résultat de la sync flotte</h3>';
			$local = $fleet_sync_results['local'] ?? [];
			printf(
				'<p><strong>Local</strong> : %s</p>',
				esc_html( is_array( $local ) ? (string) ( $local['message'] ?? wp_json_encode( $local ) ) : '' )
			);
			echo '<table class="widefat striped" style="max-width:900px">';
			echo '<thead><tr><th>Satellite</th><th>HTTP</th><th>Résultat</th></tr></thead><tbody>';
			foreach ( $fleet_sync_results['remote'] ?? [] as $row ) {
				if ( ! empty( $row['error'] ) && '' === ( $row['url'] ?? '' ) ) {
					printf(
						'<tr><td colspan="3" style="color:#d63638">%s</td></tr>',
						esc_html( $row['error'] )
					);
					continue;
				}
				$ok    = ! empty( $row['ok'] );
				$color = $ok ? 'green' : '#d63638';
				$msg   = $row['error'] ?? '';
				if ( ! $msg && is_array( $row['body'] ?? null ) ) {
					$msg = (string) ( $row['body']['message'] ?? wp_json_encode( $row['body'] ) );
				} elseif ( ! $msg && is_string( $row['body'] ?? null ) ) {
					$msg = $row['body'];
				}
				printf(
					'<tr><td><strong>%s</strong><br><small><code>%s</code></small></td><td>%d</td><td style="color:%s">%s %s</td></tr>',
					esc_html( $row['label'] ?? '' ),
					esc_html( $row['url'] ?? '' ),
					(int) ( $row['http_code'] ?? 0 ),
					esc_attr( $color ),
					$ok ? '✅' : '❌',
					esc_html( (string) $msg )
				);
			}
			echo '</tbody></table>';
		}

		// ---- Layout synchronisé (template parts) -----------------------
		echo '<h2>Éléments de layout communs</h2>';
		echo '<p>Certains éléments (en-tête, pied de page, menu mobile, pages protégées…) sont <strong>identiques sur tous les sites Gigi</strong>. '
			. 'Ils sont fournis par le thème et mis à jour lors d’un déploiement.</p>';
		echo '<p><strong>Attention :</strong> si on les modifie dans <em>Apparence → Éditeur</em> sur un site, WordPress crée une version locale de cet élément. '
			. 'Cette version locale <strong>remplace</strong> celle du thème : les prochaines mises à jour du thème ne s’appliqueront plus à cet élément sur ce site.</p>';
		echo '<p>Le tableau ci-dessous indique, pour chaque élément, s’il vient encore du thème (à jour avec les autres sites) '
			. 'ou d’une modification locale. Le bouton ou une mise à jour du thème <strong>efface les versions locales</strong> '
			. 'pour revenir au layout commun — les changements faits uniquement dans l’éditeur de site seront perdus.</p>';

		$layout_status = Gigi_Layout_Sync::get_status();
		if ( empty( $layout_status ) ) {
			echo '<p><em>Impossible de lire la liste des éléments — mettez à jour gigi-theme et gigi-checker.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:900px">';
			echo '<thead><tr><th>Élément</th><th>Version utilisée</th><th>Conséquence</th></tr></thead><tbody>';
			foreach ( $layout_status as $item ) {
				if ( $item['customized'] ) {
					$source_label = 'Modification locale (éditeur de site)';
					$state        = '⚠️ Hors sync — sera écrasée à la prochaine MAJ / resync';
					$color        = '#d63638';
				} else {
					$source_label = 'Thème commun (tous les sites)';
					$state        = '✅ Aligné avec les autres sites';
					$color        = 'green';
				}
				printf(
					'<tr><td><strong>%s</strong><br><small style="color:#666"><code>%s</code></small></td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
					esc_html( $item['label'] ),
					esc_html( $item['slug'] ),
					esc_html( $source_label ),
					esc_attr( $color ),
					esc_html( $state )
				);
			}
			echo '</tbody></table>';
			echo '<form method="post" style="margin-top:1em">';
			wp_nonce_field( 'gigi_layout_sync' );
			echo '<input type="hidden" name="gigi_layout_sync" value="1">';
			echo '<button type="submit" class="button">Revenir au layout commun maintenant</button>';
			echo '<p class="description">Supprime les modifications locales listées en rouge et réapplique la version du thème.</p>';
			echo '</form>';
		}

		// ---- Tableau des versions --------------------------------------
		echo '<h2>Versions</h2>';

		if ( empty( $remote ) ) {
			echo '<p><em>Impossible d\'afficher les versions — le fichier versions.json est inaccessible.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:800px">';
			echo '<thead><tr><th>Composant</th><th>Installé</th><th>Disponible</th><th>État</th></tr></thead><tbody>';

			foreach ( $slugs as $slug ) {
				$remote_data    = $remote[ $slug ] ?? null;
				$remote_version = $remote_data['version'] ?? '—';

				if ( 'gigi-theme' === $slug ) {
					$theme           = wp_get_theme( $slug );
					$installed       = $theme->exists() ? $theme->get( 'Version' ) : '(non trouvé)';
					$component_label = $theme->exists() ? $theme->get( 'Name' ) : $slug;
				} else {
					$plugin_path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
					if ( file_exists( $plugin_path ) ) {
						if ( ! function_exists( 'get_plugin_data' ) ) {
							require_once ABSPATH . 'wp-admin/includes/plugin.php';
						}
						$data            = get_plugin_data( $plugin_path );
						$installed       = $data['Version'];
						$component_label = $data['Name'];
					} else {
						$installed       = '(non trouvé)';
						$component_label = $slug;
					}
				}

				if ( '—' === $remote_version ) {
					$status = '⚠️ Absent du versions.json';
					$color  = 'orange';
				} elseif ( '(non trouvé)' === $installed ) {
					$status = '⚠️ Plugin/thème non installé';
					$color  = 'orange';
				} elseif ( version_compare( $installed, $remote_version, '<' ) ) {
					$status = '🔄 Mise à jour disponible';
					$color  = '#0073aa';
				} else {
					$status = '✅ À jour';
					$color  = 'green';
				}

				printf(
					'<tr><td><strong>%s</strong><br><small style="color:#666">%s</small></td><td>%s</td><td>%s</td><td style="color:%s"><strong>%s</strong></td></tr>',
					esc_html( $component_label ),
					esc_html( $slug ),
					esc_html( $installed ),
					esc_html( $remote_version ),
					esc_attr( $color ),
					esc_html( $status )
				);
			}

			echo '</tbody></table>';
		}

		// ---- Cache WordPress -------------------------------------------
		echo '<h2>Cache WordPress</h2>';
		$t_plugins = get_site_transient( 'update_plugins' );
		$t_themes  = get_site_transient( 'update_themes' );

		echo '<table class="widefat striped" style="max-width:800px">';
		echo '<thead><tr><th>Transient</th><th>Contenu Gigi</th><th>Dernière vérification</th></tr></thead><tbody>';

		foreach ( [ 'gigi-checker/gigi-checker.php', 'gigi-blocks/gigi-blocks.php' ] as $key ) {
			$slug_short = explode( '/', $key )[0];
			if ( isset( $t_plugins->response[ $key ] ) ) {
				$info = 'response → v' . $t_plugins->response[ $key ]->new_version;
			} elseif ( isset( $t_plugins->no_update[ $key ] ) ) {
				$info = 'no_update → v' . $t_plugins->no_update[ $key ]->new_version;
			} else {
				$info = '⚠️ Absent';
			}
			$last = isset( $t_plugins->last_checked ) ? date( 'd/m/Y H:i:s', $t_plugins->last_checked ) : '—';
			printf( '<tr><td>update_plugins</td><td><code>%s</code> : %s</td><td>%s</td></tr>',
				esc_html( $slug_short ), esc_html( $info ), esc_html( $last ) );
		}

		if ( isset( $t_themes->response['gigi-theme'] ) ) {
			$t_info = 'response → v' . $t_themes->response['gigi-theme']['new_version'];
		} elseif ( isset( $t_themes->no_update['gigi-theme'] ) ) {
			$t_info = 'no_update → v' . ( $t_themes->no_update['gigi-theme']['new_version'] ?? '?' );
		} else {
			$t_info = '⚠️ Absent';
		}
		$last_t = isset( $t_themes->last_checked ) ? date( 'd/m/Y H:i:s', $t_themes->last_checked ) : '—';
		printf( '<tr><td>update_themes</td><td><code>gigi-theme</code> : %s</td><td>%s</td></tr>',
			esc_html( $t_info ), esc_html( $last_t ) );

		echo '</tbody></table>';

		// ---- Actions ---------------------------------------------------
		echo '<p style="margin-top:1.5em">';
		$flush_url = wp_nonce_url(
			add_query_arg( 'gigi-force-check', '1', admin_url( 'plugins.php' ) ),
			'gigi_force_check'
		);
		printf( '<a href="%s" class="button button-primary">Vider le cache et vérifier</a>',
			esc_url( $flush_url ) );
		echo '</p>';

		echo '</div>';
	}
}
