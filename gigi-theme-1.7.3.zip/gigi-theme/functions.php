<?php
/**
 * Gigi Theme — functions.php
 */

defined( 'ABSPATH' ) || exit;

define( 'GIGI_THEME_VERSION', '1.7.3' );

/**
 * Enqueue styles & scripts
 */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'gigi-theme-style',
		get_stylesheet_uri(),
		[],
		GIGI_THEME_VERSION
	);
} );

/**
 * Add theme support features
 */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );

	remove_theme_support( 'core-block-patterns' );

	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', [
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	] );

	load_theme_textdomain( 'gigi-theme', get_template_directory() . '/languages' );

	register_block_pattern_category( 'gigi', [
		'label'       => 'Gigi',
		'description' => 'Compositions de blocs GIGI.',
	] );
} );

/**
 * Supprime toutes les compositions qui ne viennent pas du thème Gigi ou du client.
 * Priorité 20 = après l'enregistrement par WP core (priority 9) et les plugins (priority 10).
 * Sont conservées :
 *   - les compositions du thème  (name commence par "gigi-theme/")
 *   - les compositions personnalisées du client (source = "custom", stockées en DB)
 */
add_action( 'init', function (): void {
	if ( ! class_exists( 'WP_Block_Patterns_Registry' ) ) {
		return;
	}

	$all = WP_Block_Patterns_Registry::get_instance()->get_all_registered();

	foreach ( $all as $pattern ) {
		$name   = $pattern['name']   ?? '';
		$source = $pattern['source'] ?? '';

		if ( str_starts_with( $name, 'gigi-theme/' ) || 'custom' === $source ) {
			continue;
		}

		unregister_block_pattern( $name );
	}
}, 20 );

/**
 * Autorise l'upload de fichiers SVG dans la médiathèque.
 */
add_filter( 'upload_mimes', function ( array $mimes ): array {
	$mimes['svg']  = 'image/svg+xml';
	$mimes['svgz'] = 'image/svg+xml';
	return $mimes;
} );

add_action( 'admin_head', function (): void {
	echo '<style>.attachment-266x266 img,.thumbnail img,.media-icon img[src$=".svg"]{width:100%!important;height:auto!important}</style>';
} );

add_filter( 'wp_handle_upload_prefilter', function ( array $file ): array {
	if ( isset( $file['type'] ) && 'image/svg+xml' === $file['type'] ) {
		$svg = file_get_contents( $file['tmp_name'] );
		if ( false !== $svg && false !== stripos( $svg, '<script' ) ) {
			$file['error'] = 'Le SVG contient des scripts et a été bloqué par sécurité.';
		}
	}
	return $file;
} );
